package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.common.domain.CurrencyBuilder;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Set;
import java.util.TreeSet;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AllConfiguredPairsAndTenorsItemNameProviderTest {

    @Mock
    private CurrencyPairService currencyPairService;

    @Test
    public void includesAllRequiredTenors() throws Exception {
        when(currencyPairService.findAllAutoPriced()).thenReturn(Lists.newArrayList(new CurrencyPair(CurrencyBuilder.AUD, CurrencyBuilder.EUR)));
        final AllConfiguredPairsAndTenorsItemNameProvider provider = new AllConfiguredPairsAndTenorsItemNameProvider(currencyPairService);
        final Set<String> items = new TreeSet<String>(provider.getItems());
        Assert.assertEquals(Sets.newTreeSet(Sets.newHashSet(
                // There are no TODAY, TOM, SPOT, or BROKEN requests, otherwise should be all tenors.
                "AUDEURON=D3", "AUDEURTN=D3", "AUDEURSN=D3", "AUDEUR1W=D3", "AUDEUR2W=D3", "AUDEUR3W=D3", "AUDEUR1M=D3", "AUDEUR2M=D3", "AUDEUR3M=D3", "AUDEUR4M=D3", "AUDEUR5M=D3", "AUDEUR6M=D3", "AUDEUR7M=D3", "AUDEUR8M=D3", "AUDEUR9M=D3", "AUDEUR10M=D3", "AUDEUR11M=D3", "AUDEUR12M=D3", "AUDEUR15M=D3", "AUDEUR18M=D3", "AUDEUR21M=D3", "AUDEUR2Y=D3", "AUDEUR3Y=D3", "AUDEURJANE=D3", "AUDEURFEBB=D3", "AUDEURFEBE=D3", "AUDEURMARB=D3", "AUDEURAPRE=D3", "AUDEURMAYB=D3", "AUDEURMAYE=D3", "AUDEURJUNB=D3", "AUDEURJUNE=D3", "AUDEURJULB=D3", "AUDEURJULE=D3", "AUDEURAUGB=D3", "AUDEURAUGE=D3", "AUDEURSEPB=D3", "AUDEURSEPE=D3", "AUDEUROCTB=D3", "AUDEUROCTE=D3", "AUDEURNOVB=D3", "AUDEURNOVE=D3", "AUDEURDECB=D3", "AUDEURIMM1=D3", "AUDEURIMM2=D3", "AUDEURIMM3=D3", "AUDEURIMM4=D3", "AUDEURSOY=D3", "AUDEUREOY=D3", "AUDEURSFY=D3", "AUDEUREFY=D3"
        )), items);
    }

    @Test
    public void removesUsd() throws Exception {
        when(currencyPairService.findAllAutoPriced()).thenReturn(Lists.newArrayList(new CurrencyPair(CurrencyBuilder.AUD, CurrencyBuilder.USD)));
        final AllConfiguredPairsAndTenorsItemNameProvider provider = new AllConfiguredPairsAndTenorsItemNameProvider(currencyPairService);

        final Set<String> items = new TreeSet<String>(provider.getItems());
        Assert.assertEquals(Sets.newTreeSet(Sets.newHashSet(
                "AUDON=D3", "AUDTN=D3", "AUDSN=D3", "AUD1W=D3", "AUD2W=D3", "AUD3W=D3", "AUD1M=D3", "AUD2M=D3", "AUD3M=D3", "AUD4M=D3", "AUD5M=D3", "AUD6M=D3", "AUD7M=D3", "AUD8M=D3", "AUD9M=D3", "AUD10M=D3", "AUD11M=D3", "AUD12M=D3", "AUD15M=D3", "AUD18M=D3", "AUD21M=D3", "AUD2Y=D3", "AUD3Y=D3", "AUDJANE=D3", "AUDFEBB=D3", "AUDFEBE=D3", "AUDMARB=D3", "AUDAPRE=D3", "AUDMAYB=D3", "AUDMAYE=D3", "AUDJUNB=D3", "AUDJUNE=D3", "AUDJULB=D3", "AUDJULE=D3", "AUDAUGB=D3", "AUDAUGE=D3", "AUDSEPB=D3", "AUDSEPE=D3", "AUDOCTB=D3", "AUDOCTE=D3", "AUDNOVB=D3", "AUDNOVE=D3", "AUDDECB=D3", "AUDIMM1=D3", "AUDIMM2=D3", "AUDIMM3=D3", "AUDIMM4=D3", "AUDSOY=D3", "AUDEOY=D3", "AUDSFY=D3", "AUDEFY=D3"
        )), items);
    }

    @Test
    public void addsSG2Currency() throws Exception {
        when(currencyPairService.findAllAutoPriced()).thenReturn(Lists.newArrayList(new CurrencyPair(CurrencyBuilder.AUD, CurrencyBuilder.SGD)));
        final AllConfiguredPairsAndTenorsItemNameProvider provider = new AllConfiguredPairsAndTenorsItemNameProvider(currencyPairService);

        final Set<String> items = new TreeSet<String>(provider.getItems());
        Assert.assertEquals(Sets.newTreeSet(Sets.newHashSet(
                "AUDSGDON=D3", "AUDSGDTN=D3", "AUDSGDSN=D3", "AUDSGD1W=D3", "AUDSGD2W=D3", "AUDSGD3W=D3", "AUDSGD1M=D3", "AUDSGD2M=D3", "AUDSGD3M=D3", "AUDSGD4M=D3", "AUDSGD5M=D3", "AUDSGD6M=D3", "AUDSGD7M=D3", "AUDSGD8M=D3", "AUDSGD9M=D3", "AUDSGD10M=D3", "AUDSGD11M=D3", "AUDSGD12M=D3", "AUDSGD15M=D3", "AUDSGD18M=D3", "AUDSGD21M=D3", "AUDSGD2Y=D3", "AUDSGD3Y=D3", "AUDSGDJANE=D3", "AUDSGDFEBB=D3", "AUDSGDFEBE=D3", "AUDSGDMARB=D3", "AUDSGDAPRE=D3", "AUDSGDMAYB=D3", "AUDSGDMAYE=D3", "AUDSGDJUNB=D3", "AUDSGDJUNE=D3", "AUDSGDJULB=D3", "AUDSGDJULE=D3", "AUDSGDAUGB=D3", "AUDSGDAUGE=D3", "AUDSGDSEPB=D3", "AUDSGDSEPE=D3", "AUDSGDOCTB=D3", "AUDSGDOCTE=D3", "AUDSGDNOVB=D3", "AUDSGDNOVE=D3", "AUDSGDDECB=D3", "AUDSGDIMM1=D3", "AUDSGDIMM2=D3", "AUDSGDIMM3=D3", "AUDSGDIMM4=D3", "AUDSGDSOY=D3", "AUDSGDEOY=D3", "AUDSGDSFY=D3", "AUDSGDEFY=D3",
                "AUDSG2ON=D3", "AUDSG2TN=D3", "AUDSG2SN=D3", "AUDSG21W=D3", "AUDSG22W=D3", "AUDSG23W=D3", "AUDSG21M=D3", "AUDSG22M=D3", "AUDSG23M=D3", "AUDSG24M=D3", "AUDSG25M=D3", "AUDSG26M=D3", "AUDSG27M=D3", "AUDSG28M=D3", "AUDSG29M=D3", "AUDSG210M=D3", "AUDSG211M=D3", "AUDSG212M=D3", "AUDSG215M=D3", "AUDSG218M=D3", "AUDSG221M=D3", "AUDSG22Y=D3", "AUDSG23Y=D3", "AUDSG2JANE=D3", "AUDSG2FEBB=D3", "AUDSG2FEBE=D3", "AUDSG2MARB=D3", "AUDSG2APRE=D3", "AUDSG2MAYB=D3", "AUDSG2MAYE=D3", "AUDSG2JUNB=D3", "AUDSG2JUNE=D3", "AUDSG2JULB=D3", "AUDSG2JULE=D3", "AUDSG2AUGB=D3", "AUDSG2AUGE=D3", "AUDSG2SEPB=D3", "AUDSG2SEPE=D3", "AUDSG2OCTB=D3", "AUDSG2OCTE=D3", "AUDSG2NOVB=D3", "AUDSG2NOVE=D3", "AUDSG2DECB=D3", "AUDSG2IMM1=D3", "AUDSG2IMM2=D3", "AUDSG2IMM3=D3", "AUDSG2IMM4=D3", "AUDSG2SOY=D3", "AUDSG2EOY=D3", "AUDSG2SFY=D3", "AUDSG2EFY=D3"
        )), items);
    }

    @Test
    public void includesSpotTenorForNDFCurrencyPair() {
        when(currencyPairService.findAllAutoPriced()).thenReturn(Lists.newArrayList(new CurrencyPair(CurrencyBuilder.USD, CurrencyBuilder.KR1)));
        final AllConfiguredPairsAndTenorsItemNameProvider provider = new AllConfiguredPairsAndTenorsItemNameProvider(currencyPairService);
        final Set<String> items = new TreeSet<String>(provider.getItems());
        Assert.assertEquals(Sets.newTreeSet(Sets.newHashSet(
                // There are no TODAY, TOM, or BROKEN requests, otherwise should be all tenors.
                "KR1ON=D3", "KR1TN=D3", "KR1SN=D3", "KR11W=D3", "KR12W=D3", "KR13W=D3", "KR11M=D3", "KR12M=D3", "KR13M=D3", "KR14M=D3", "KR15M=D3", "KR16M=D3", "KR17M=D3", "KR18M=D3", "KR19M=D3", "KR1=D3", "KR110M=D3", "KR111M=D3", "KR112M=D3", "KR115M=D3", "KR118M=D3", "KR121M=D3", "KR12Y=D3", "KR13Y=D3", "KR1JANE=D3", "KR1FEBB=D3", "KR1FEBE=D3", "KR1MARB=D3", "KR1APRE=D3", "KR1MAYB=D3", "KR1MAYE=D3", "KR1JUNB=D3", "KR1JUNE=D3", "KR1JULB=D3", "KR1JULE=D3", "KR1AUGB=D3", "KR1AUGE=D3", "KR1SEPB=D3", "KR1SEPE=D3", "KR1OCTB=D3", "KR1OCTE=D3", "KR1NOVB=D3", "KR1NOVE=D3", "KR1DECB=D3", "KR1IMM1=D3", "KR1IMM2=D3", "KR1IMM3=D3", "KR1IMM4=D3", "KR1SOY=D3", "KR1EOY=D3", "KR1SFY=D3", "KR1EFY=D3"
        )), items);
    }

}