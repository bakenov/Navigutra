package com.anz.markets.efx.fox.codec.pojo;

import java.util.EnumSet;
import java.util.Objects;

import com.anz.markets.efx.fox.codec.api.VenueCategory;
import com.anz.markets.efx.fox.codec.api.VenueConfigHandler;
import com.anz.markets.efx.fox.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.VenueConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class VenueConfigAsserter {
    private final VenueConfig message;

    public VenueConfigAsserter(final VenueConfig message) {
        this.message = Objects.requireNonNull(message);
    }

    public static VenueConfigAsserter expect(final VenueConfig message) {
        return new VenueConfigAsserter(message);
    }

    public static VenueConfigAsserter expect(final MessageHeader header, final VenueConfig.Body body) {
        return new VenueConfigAsserter(SorMessage.venueConfig(header, body));
    }

    public VenueConfig message() {
        return message;
    }

    public VenueConfig.Body body() {
        return message.body;
    }

    public VenueConfigHandler assertingVenueConfigHandler() {
        return body -> {
            assertEquals("enabled not as expected", body().enabled, body.enabled());
            assertEquals("venue not as expected", body().venue, body.venue());
            assertEquals("compId not as expected", body().compId, body.compId().decodeStringOrNull());
            assertEquals("venueCategories not as expected", body().venueCategories, body.venueCategories().decodeTo(EnumSet.noneOf(VenueCategory.class)));
        };
    }

    public void assertSorMessage(final SorMessage sorMessage) {
        assertTrue("sorMessage should be a VenueConfig", sorMessage instanceof VenueConfig);
        assertVenueConfig((VenueConfig) sorMessage);
    }

    public void assertVenueConfig(final VenueConfig venueConfig) {
        assertBody(venueConfig.body);
    }

    public void assertBody(final VenueConfig.Body body) {
        assertEquals("enabled not as expected", body().enabled, body.enabled);
        assertEquals("venue not as expected", body().venue, body.venue);
        assertEquals("compId not as expected", body().compId, body.compId);
        assertEquals("venueCategories not as expected", body().venueCategories, body.venueCategories);
    }
}
