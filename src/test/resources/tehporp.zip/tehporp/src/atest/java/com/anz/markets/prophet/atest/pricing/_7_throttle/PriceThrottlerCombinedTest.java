package com.anz.markets.prophet.atest.pricing._7_throttle;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.common.collect.Lists;
import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.PRICING_4_8_2, Ref.PRICING_4_8_3})
public class PriceThrottlerCombinedTest extends BaseAcceptanceSpecification {

    @Test
    @RestartBeforeTest(reason="clear prices")
    @DisplayName("scenario1")
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
    public void scenario1() {
        int normalLimit = 1;
        int normalPeriodMS = 100;
        double normalDeltaFractionOfSpread = 0.125;   // 0.125 * 0.00008(USDCHF base spread) = 0.00001
        int overrideLimit = 2;
        int overridePeriodMS = 80;
        double overrideDeltaFractionOfMid = 0.00002; // 0.00002 * USDCHF MID(~1.00000) = 0.00002

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.ANY, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00008));
        }
        then:
        {   // normalDeltaFractionOfSpread = 0.125, base spread = 0.8 pip, min movement = 0.125*0.8 = 0.1 pip
            // Mid movement of 0.00001 == min movement => price published(NORMAL FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(30);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00004, 0.00008));
        }
        then:
        {   // overridePriceDeltaFractionOfMid = 0.00002, last mid = 1.00001 => min movement = 0.00002 * 1.00001 = 0.0000200002
            // Mid movement of 0.00003 > min movement => price queued(OVERRIDE FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00004));
            prophet.clearOutputBuffer();
        }

        when:
        // increment time to meet override period and send marketdata
        {
            prophet.incrementTime(10);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00004));
        }
    }

    @Test
    @DisplayName("scenario2")
    @Requirement(value = {Requirement.Ref.PRICING_AXPROPHET_1134})
    public void scenario2() {
        int normalLimit = 1;
        int normalPeriodMS = 100;
        double normalDeltaFractionOfSpread = 0.12;   // 0.12 * 0.00008(USDCHF base spread) = 0.0000096
        int overrideLimit = 2;
        int overridePeriodMS = 80;
        double overrideDeltaFractionOfMid = 0.00002; // 0.00002 * USDCHF MID(~1.00000) = 0.00002

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.ANY, Currency.USD, Currency.CHF, 5, 5, normalDeltaFractionOfSpread,
                                    5, 5, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(100);
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00001, 0.00008));
        }
        then:
        {   // normalDeltaFractionOfSpread = 0.125, base spread = 0.8 pip, min movement = 0.125*0.8 = 0.1 pip
            // Mid movement of 0.00001 == min movement => price published(NORMAL FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00001));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(30); // @t130
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00002, 0.00008));
        }
        then:
        {   // normalDeltaFractionOfSpread = 0.12, base spread = 0.8 pip, min movement = 0.12*0.8 = 0.096 pip
            // Mid movement of 0.1 pip > min movement => price QUEUED(NORMAL FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00002));
            prophet.clearOutputBuffer();
        }

        when:
        // increment time to meet override period and send market data
        {
            prophet.incrementTime(10); // @t140
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00004, 0.00008));
        }
        then:
        {   // overridePriceDeltaFractionOfMid = 0.00002, last PUBLISHED mid = 1.00001 => min movement = 0.00002 * 1.00001 = 0.0000200002
            // Mid movement from last PUBLISHABLE price = 0.00003 > min movement => price published(OVERRIDE FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, atLeast(1), isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00004));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(60); // @t200
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        // since nothing in queue, expect no USDCHF price
        {
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCHF, Market.WSP_A));
        }
    }

    @Test
    @DisplayName("scenario3")
    public void scenario3() {
        int normalLimit = 1;
        int normalPeriodMS = 100;
        double normalDeltaFractionOfSpread = 0.1;   // 0.10 * 0.00008(USDCHF base spread) = 0.000008
        int overrideLimit = 2;
        int overridePeriodMS = 80;
        double overrideDeltaFractionOfMid = 0.00002; // 0.00002 * USDCHF MID(~1.00000) = 0.00002

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(40); // @t40
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.99997, 0.00008));
        }
        then:
        {   // overridePriceDeltaFractionOfMid = 0.00002, last mid = 1.0000 => min movement = 0.00002 * 1.0000 = 0.00002
            // Mid movement from last PUBLISHABLE price = 0.00003 > min movement => price published(OVERRIDE FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99997));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(30); // @t70
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.99998, 0.00008));
        }
        then:
        {   // normalDeltaFractionOfSpread = 0.1, base spread = 0.8 pip, min movement = 0.1*0.8 = 0.08 pip
            // Mid movement from last PUBLISHABLE price ~ 0.1pip  > normal min movement => price QUEUED(NORMAL FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99998));
            prophet.clearOutputBuffer();
        }

        when:
        // increment time to meet override period and send other ccy market data
        {
            prophet.incrementTime(10); // @t80
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.512, 0.004));
        }
        then:
        {   // since we are in normal throttle period, do not expect queued price to be sent
            prophet.notExpect(ClientPrice.class, isClientPriceInstrumentAndMkt(Instrument.USDCHF, Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        // increment time to meet normal period and send other ccy market data
        {
            prophet.incrementTime(60); // @t140
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 88.513, 0.004));
        }
        then:
        {   // expect queued price(normal frequency) to be published
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A, Instrument.USDCHF)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99998));
        }
    }

    @Test
    @DisplayName("scenario4")
    public void scenario4() {
        int normalLimit = 1;
        int normalPeriodMS = 100;
        double normalDeltaFractionOfSpread = 0.126;   // 0.126 * 0.00008(USDCHF base spread) = 0.1008 pip
        int overrideLimit = 2;
        int overridePeriodMS = 80;
        double overrideDeltaFractionOfMid = 0.00002; // 0.00002 * USDCHF MID(~1.00000) = 0.00002

        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setClientPriceThrottleConfigs(Lists.newArrayList(
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.CHF, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_A, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_B, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_C, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid),
                            clientPriceConfigOverrideThrottle(Market.WSP_Z, Currency.USD, Currency.JPY, normalLimit, normalPeriodMS, normalDeltaFractionOfSpread,
                                    overrideLimit, overridePeriodMS, overrideDeltaFractionOfMid)
                    ))
                    .setSyntheticWideningFactors(Collections.emptyList())
            );
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));

        }
        then:
        {
            prophet.expect(ClientPrice.class, exactly(1), isPublishable(Market.WSP_A));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(40); // @t40
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.99997, 0.00008));
        }
        then:
        {   // overridePriceDeltaFractionOfMid = 0.00002, last mid = 1.0000 => min movement = 0.00002 * 1.0000 = 0.00002
            // Mid movement from last PUBLISHABLE price = 0.00003 > min movement => price published(OVERRIDE FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99997));
            prophet.clearOutputBuffer();
        }

        when:
        {
            prophet.incrementTime(30); // @t70
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 0.99999, 0.00008));
        }
        then:
        {   // normalDeltaFractionOfSpread = 0.1, base spread = 0.8 pip, min movement = 0.1*0.8 = 0.08 pip
            // Mid movement from last PUBLISHABLE price ~ 0.2pip  > normal min movement => price QUEUED(NORMAL FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isThrottled(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(0.99999));
            prophet.clearOutputBuffer();
        }

        when:
        // increment time to meet override period
        {
            prophet.incrementTime(10); // @t80
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDCHF, 1.00000, 0.00008));
        }
        then:
        {   // overridePriceDeltaFractionOfMid = 0.00002, last PUBLISHABLE mid = 0.99997 => min movement = 0.00002 * 0.99997 = 0.1999 pip
            // Mid movement from last PUBLISHABLE price = 0.00003 > min movement => price published(OVERRIDE FREQUENCY)
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isPublishable(Market.WSP_A)).getFirst();
            assertThat(clientPrice.getMidRate(), isRoundedTo(1.00000));
        }
    }

    private ClientPriceThrottleConfigImpl clientPriceConfigOverrideThrottle(final Market market, Currency baseCurrency, Currency termsCurrency,
                                                                            int normalLimit, int normalPeriodMS,
                                                                            double normalDeltaFractionOfSpread,
                                                                            int overrideLimit, int overridePeriodMS,
                                                                            double overrideDeltaFractionOfMid) {
        return new ClientPriceThrottleConfigImpl(market, baseCurrency, termsCurrency)
                .setNoActivityHeartbeatFrequencyMs(DONT_CARE_LARGE_LONG)
                .setLimit(normalLimit)
                .setTimePeriod(normalPeriodMS)
                .setMinimumPriceDeltaFractionOfSpread(normalDeltaFractionOfSpread)
                .setOverrideLimit(overrideLimit)
                .setOverrideTimePeriod(overridePeriodMS)
                .setOverrideMinimumPriceDeltaFractionOfMid(overrideDeltaFractionOfMid);
    }
}
