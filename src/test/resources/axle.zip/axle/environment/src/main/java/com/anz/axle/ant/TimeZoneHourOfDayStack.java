package com.anz.axle.ant;

import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

public class TimeZoneHourOfDayStack {
    private static final Logger LOG = Logger.getLogger(TimeZoneHourOfDayStack.class);

    private String fromTimezoneName;
    private DateTimeZone fromTimezone;
    private String toTimezoneName;
    private DateTimeZone toTimezone;

    public TimeZoneHourOfDayStack(String fromTimezoneName, String fromTimezoneId, String toTimezoneName, String toTimezoneId) {
        this.fromTimezoneName = fromTimezoneName;
        this.fromTimezone = DateTimeZone.forID(fromTimezoneId);
        this.toTimezoneName = toTimezoneName;
        this.toTimezone = DateTimeZone.forID(toTimezoneId);
    }

    public String getFromTimezoneName() {
        return fromTimezoneName;
    }

    public String getToTimezoneName() {
        return toTimezoneName;
    }

    public Map<String, String> getShiftedHourOfDayValuesForBaseTime(DateTime baseTime) {
        Map<String, String> retval = new LinkedHashMap<String, String>();

        DateTime fromDateTime = baseTime.withZone(fromTimezone).withYear(baseTime.getYear())
                .withMonthOfYear(baseTime.getMonthOfYear()).withDayOfMonth(baseTime.getDayOfMonth());

        LOG.debug(String.format("Generating shifted hour-of-day values for [%s] in reference to [%s-%s-%s] with [%s] timezone",
                fromTimezoneName, fromDateTime.getYear(), fromDateTime.getMonthOfYear(), fromDateTime.getDayOfMonth(),
                toTimezoneName));

        for (int hour = 0; hour < 24; hour++) {
            String key = String.format("tzc_%s_%s_to_%s", hour, fromTimezoneName, toTimezoneName);
            String value = null;

            try {
                try {
                    value = String.format("%02d", fromDateTime.withHourOfDay(hour).withZone(toTimezone).hourOfDay().get());
                } catch (Exception ex) {
                    value = String.format("%02d", fromDateTime.plusDays(1).withHourOfDay(hour).withZone(toTimezone).hourOfDay()
                            .get());

                    LOG.error(String.format("Calculation of [tzc_%s_%s_to_%s] has resulted in [%s]. "
                            + "The value has been adjusted to [%s]. " + "Ensure system behaves correctly!", hour, fromTimezoneName,
                            toTimezoneName, ex, value));
                }
            } catch (Exception ex) {
                LOG.error(String.format("Calculation of [tzc_%s_%s_to_%s] has resulted in [%s]. "
                        + "The property has been omitted from the configuration. " + "Ensure system behaves correctly!", hour,
                        fromTimezoneName, toTimezoneName, ex));
            }

            if (value != null) {
                retval.put(key, value);
            }
        }

        return retval;
    }

    @Override
    public String toString() {
        return String.format("TimeZoneHourOfDayStack [%s -> %s]", fromTimezoneName, toTimezoneName);
    }

}
