package com.anz.markets.efx.fox.firewall.api;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;

public interface RuleMatcher extends Comparable<RuleMatcher>{
    boolean match(String region,
                  String desk,
                  String targetStrategyName,
                  String portfolio,
                  String username,
                  String venue,
                  SecurityType securityType,
                  Tenor tenor,
                  String symbol);
}
