package com.anz.markets.prophet.chime.regulator;

import com.anz.markets.prophet.domain.time.OneSecond;

import java.util.function.BiPredicate;
import java.util.function.Consumer;


/**
 * To summarise a data stream into a regular update frequency
 */
public class TemporalChimer<T> {
    private final BiPredicate<T, T> acceptFunction;
    private final Consumer<T> consumer;
    private T existing;

    public TemporalChimer(final T initialValue, final BiPredicate<T, T> acceptFunction, final Consumer<T> consumer) {
        this.acceptFunction = acceptFunction;
        this.consumer = consumer;
        this.existing = initialValue;
    }

    public Consumer<T> consumer() {
        return received -> {
            if (acceptFunction.test(existing, received)) {
                existing = received;
            }
        };
    }

    public Consumer<OneSecond> consumerOfOneSecond() {
        return sec -> {
            if (existing != null) {
                consumer.accept(existing);
            }
        };
    }

}

