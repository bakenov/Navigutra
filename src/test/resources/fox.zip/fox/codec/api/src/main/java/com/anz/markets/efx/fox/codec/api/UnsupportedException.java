package com.anz.markets.efx.fox.codec.api;

import java.util.Objects;
import java.util.function.Supplier;

public class UnsupportedException extends RuntimeException {
    public UnsupportedException(final String message) {
        super(message);
    }
    public UnsupportedException(final Class<?> type) {
        super(type.getSimpleName() + " is not supported");
    }

    static <T> Supplier<T> supplierThrowingUnsupported(final String message) {
        Objects.requireNonNull(message);
        return () -> {
            throw new UnsupportedException(message);
        };
    }

    static <T> Supplier<T> supplierThrowingUnsupported(final Class<T> type) {
        return supplierThrowingUnsupported(type.getSimpleName() + " is not supported");
    }
}