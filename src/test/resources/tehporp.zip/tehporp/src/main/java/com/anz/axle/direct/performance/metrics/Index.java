package com.anz.axle.direct.performance.metrics;

// Sourced from the excellent com.anz.axle.direct.performance.metrics (SPDEE)

public enum Index {
    DecimalThreeDigits {
        public int toBucket(long value) {
            int offset = 0;
    /*          Quickly reduce initial scale using repeated division.
                This must leave a value that triggers a short-cut below since
                we need apply half-up rounding. */
            while (value > 100000000) {
                offset += 4500;
                value /= 100000;
            }
    /*          Short-cut remaining calculations to one division, including half-up rounding.*/
            if (value > 10000000) {
                offset += 4500;
                return offset + (int) (value + 50000) / 100000;
            }
            if (value > 1000000) {
                offset += 3600;
                return offset + (int) (value + 5000) / 10000;
            }
            if (value > 100000) {
                offset += 2700;
                return offset + (int) (value + 500) / 1000;
            }
            if (value > 10000) {
                offset += 1800;
                return offset + (int) (value + 50) / 100;
            }
            if (value > 1000) {
                offset += 900;
                return offset + (int) (value + 5) / 10;
            }
            return offset + (int) value;
        }

        public long fromBucket(int bucket) {
            long multiplier = 1;
            while (bucket > 5500) {
                multiplier *= 1000000;
                bucket -= 5400;
            }
            if (bucket > 4600) {
                multiplier *= 100000;
                bucket -= 4500;
            } else if (bucket > 3700) {
                multiplier *= 10000;
                bucket -= 3600;
            } else if (bucket > 2800) {
                multiplier *= 1000;
                bucket -= 2700;
            } else if (bucket > 1900) {
                multiplier *= 100;
                bucket -= 1800;
            } else if (bucket > 1000) {
                multiplier *= 10;
                bucket -= 900;
            }
            return multiplier * bucket;
        }
    };

    public abstract int toBucket(final long value);

    public abstract long fromBucket(final int bucket);

}
