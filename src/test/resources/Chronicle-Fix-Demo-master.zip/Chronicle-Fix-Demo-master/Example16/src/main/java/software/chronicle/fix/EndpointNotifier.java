package software.chronicle.fix;

import net.openhft.chronicle.wire.Marshallable;
import net.openhft.chronicle.wire.Wires;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.sessioncode.messages.Reject;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.generated.code.fields.ExecType;
import software.chronicle.generated.code.messages.ExecutionReport;
import software.chronicle.generated.code.messages.MessageNotifier;
import software.chronicle.generated.code.messages.NewOrderSingle;

import java.util.concurrent.CountDownLatch;

import static software.chronicle.generated.code.messages.ExecutionReport.newExecutionReport;

public class EndpointNotifier implements MessageNotifier, Marshallable {
    private static Logger LOGGER = LoggerFactory.getLogger(EndpointNotifier.class);

    CountDownLatch loggedIn = new CountDownLatch(1);
    ExecutionReport executionReport;

    @Override
    public void onNewOrderSingle(FixSessionHandler session, NewOrderSingle newOrderSingle) {
        if (executionReport == null)
            executionReport = newExecutionReport(Wires.acquireBytes(), session.context());
        else
            executionReport.reset();
        executionReport.clOrdID(newOrderSingle.clOrdID());
        executionReport.side('1');
        executionReport.avgPx(12.0);
        executionReport.execType(ExecType.NEW);
        session.sendMessage(executionReport);
    }

    @Override
    public void onLogon(FixSessionHandler session, software.chronicle.fix.sessioncode.messages.Logon logon) {
        loggedIn.countDown();
    }

    @Override
    public void onReject(FixSessionHandler session, Reject reject) {
        LOGGER.error("Reject {}", reject);
    }
}
