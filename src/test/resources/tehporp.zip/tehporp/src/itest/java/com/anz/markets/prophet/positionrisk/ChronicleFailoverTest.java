package com.anz.markets.prophet.positionrisk;

import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;

import java.io.IOException;

@RunWith(Parameterized.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ChronicleFailoverTest extends ChronicleFailoverTestBase {

    private static String sameQueueNameForAllTests;
    private static Context contextBefore;
    private static TestTimeSource fixTimeSource;

    @BeforeClass
    public static void beforeClass() throws IOException {
        sameQueueNameForAllTests = FileUtil.tmpFile(ChronicleFailoverTest.class.getSimpleName());
        contextBefore = Context.context();
        fixTimeSource = new TestTimeSource(0);
        Context.set(new Context(fixTimeSource));
    }

    @AfterClass
    public static void afterClass() {
        Context.set(contextBefore);
    }

    private void reset() {
        id = 0;
    }

    @Test
    public void failover() {
        reset();

        fixTimeSource.setMillis(0);

        doFailover(0, 0);
    }

    @Test
    public void failoverAfterRestart() {
        fixTimeSource.setMillis(1000);

        doFailover(4, 11);
    }

    @NotNull
    @Override
    protected String queueFileNameForTest(final String postfix) {
        return sameQueueNameForAllTests + postfix;
    }
}
