package com.anz.axle.lg.adapter.apama.transport;

import java.util.function.Consumer;

import com.apama.event.Event;
import com.apama.event.IEventListener;

class EventListener implements IEventListener {
    private final Consumer<Event> eventConsumer;

    public EventListener(final Consumer<Event> eventConsumer) {
        this.eventConsumer = eventConsumer;
    }

    @Override
    public void handleEvent(final Event event) {
        eventConsumer.accept(event);
    }

    @Override
    public void handleEvents(final Event[] events) {
        for (int i = 0; i < events.length; i++) {
            eventConsumer.accept(events[i]);
        }
    }
}
