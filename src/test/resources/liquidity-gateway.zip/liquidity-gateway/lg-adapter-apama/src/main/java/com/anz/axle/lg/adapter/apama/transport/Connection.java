package com.anz.axle.lg.adapter.apama.transport;

import java.util.function.Consumer;

import com.apama.event.Event;
import com.apama.event.parser.EventType;

public interface Connection extends AutoCloseable {
    @Override
    void close();
    Subscription openSubscription(EventType eventType, Consumer<Event> eventConsumer);

    ConnectionConfig connectionConfig();
}
