package com.anz.markets.efx.ngaro.sbe;

import org.agrona.MutableDirectBuffer;

public interface MutableSbeMessage extends SbeMessage {
    @Override
    MutableDirectBuffer buffer();
    /** @param length message length including header */
    void messageLength(int length);
}
