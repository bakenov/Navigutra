package com.anz.axle.lg.adapter.lmax.acceptance;

import quickfix.SessionID;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.quickfix.FixMessageSender;

public interface AcceptanceContext extends SharedAcceptanceContext {
    FixMessageSender fixMessageSender();
    SessionID pricingSessionId();
}
