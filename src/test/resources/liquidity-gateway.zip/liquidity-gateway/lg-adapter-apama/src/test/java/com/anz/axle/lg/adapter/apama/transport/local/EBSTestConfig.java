package com.anz.axle.lg.adapter.apama.transport.local;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.apama.config.instance.EBSConfig;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Sink;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;

@Configuration
@Import(EBSConfig.class)
public class EBSTestConfig {
    @Bean
    public LocalApamaTransport apamaTransport() {
        return new LocalApamaTransport();
    }

    @Bean
    public Consumer<String> eventStringConsumer(final LocalApamaTransport localApamaTransport) {
        return localApamaTransport.eventStringConsumer();
    }

    @Bean
    Queue<PricingMessage> messageQueue() {
        return new ConcurrentLinkedQueue<>();
    }

    @Bean
    Transport transport(final Queue<PricingMessage> messageQueue) {
        return StubbedTransport.builder().sinks(topic -> Sink.create((buf, off, len) ->
                PricingMessage.decode(new SbeMessageForReading().wrap(buf, off, len), new SbePricingDecoders()),
                messageQueue::add)).build();
    }

}
