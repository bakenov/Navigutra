package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.adapters.rmds.AbstractTest;
import com.anz.axle.adapters.rmds.ItemBuilder;
import com.anz.axle.common.domain.CurrencyBuilder;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.anz.axle.datafabric.client.config.GeneralConfigDAO;
import com.anz.axle.datafabric.domain.trading.GeneralConfig;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.ForwardPointsQuotePageKey;
import com.anz.axle.pricing.Quote;
import com.anz.axle.pricing.QuoteBuilder;
import com.anz.axle.pricing.QuotePageType;
import com.anz.axle.pricing.QuoteState;
import com.anz.axle.spdee.dealing.QuotePriceType;
import com.anz.markets.adapters.trep.Item;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ForwardPointSubscriberTest extends AbstractTest {
    @Autowired
    private ForwardPointSubscriber subscriber;

    @Autowired
    private GeneralConfigDAO generalConfigDAO;

    @Autowired
    private CurrencyPairService currencyPairService;

    @Before
    public void setup() {
        currencyPairService.save(new CurrencyPair(CurrencyBuilder.AUD, CurrencyBuilder.USD));
        currencyPairService.save(new CurrencyPair(CurrencyBuilder.USD, CurrencyBuilder.KR1));
    }

    @Test
    public void testLocalDateHandlesReutersFormat() {
        DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMM yyyy");
        assertNotNull(formatter.parseLocalDate("16 MAY 2013"));
        assertEquals(new LocalDate(2013, 5, 16), formatter.parseLocalDate("16 MAY 2013"));

        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfigDAO.remove(generalConfig.getKey());
    }

    @Test
    public void shouldSaveToDatafabricOnUpdate1() {
        Item item = new ItemBuilder("AUD2M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();


        // under test
        subscriber.onUpdate(item);

        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.TWO_MONTH.getKey()));

        assertThat(page.getSymbol(), is("AUD/USD"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.TWO_MONTH));
        assertThat(page.getTenorDate(), is(new LocalDate(2013, 7, 17)));
        assertThat(page.getReferenceSpotDate(), is(new LocalDate(2013, 5, 17)));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.STREAMABLE));
        assertThat(page.getVersion() > 0, is(true));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));

        final Quote expectedQuote = new QuoteBuilder()
                .withBidPrice(new Decimal("-42.65"))
                .withAskPrice(new Decimal("-42.35"))
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build();
        assertQuote(page.getQuotes().get(0), expectedQuote);
    }

    @Test
    public void shouldSaveToDatafabricOnUpdate2() {
        Item item = new ItemBuilder("AUD3M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-64.2")
                .withField("BID", "-64.7")
                .withField("GEN_TEXT16", "INDIC")
                .withField("MATUR_DATE", "19 AUG 2013")
                .withField("TIMACT", "02:42")
                .build();


        // under test
        subscriber.onUpdate(item);

        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.THREE_MONTH.getKey()));

        assertThat(page.getSymbol(), is("AUD/USD"));
        assertThat(page.getSource(), is("D3"));
        assertThat(page.getTenor(), is(Tenor.THREE_MONTH));
        assertThat(page.getTenorDate(), is(new LocalDate(2013, 8, 19)));
        assertThat(page.getReferenceSpotDate(), is(new LocalDate(2013, 5, 17)));
        assertThat(page.getConfigVersion(), is(-1L));
        assertThat(page.getState(), is(QuoteState.INDICATIVE));
        assertThat(page.getVersion() > 0, is(true));
        assertThat(page.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page.getQuotes().size(), is(1));
        assertQuote(page.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(new Decimal("-64.7"))
                .withAskPrice(new Decimal("-64.2"))
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.INDICATIVE)
                .build());
    }

    @Test
    public void shouldSaveToDatafabricOnUpdateWithTwoEntries() {
        Item item = new ItemBuilder("AUD12M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();


        // under test
        subscriber.onUpdate(item);

        ForwardPointsQuotePage page12M = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.TWELVE_MONTH.getKey()));

        assertThat(page12M.getSymbol(), is("AUD/USD"));
        assertThat(page12M.getSource(), is("D3"));
        assertThat(page12M.getTenor(), is(Tenor.TWELVE_MONTH));
        assertThat(page12M.getTenorDate(), is(new LocalDate(2013, 7, 17)));
        assertThat(page12M.getReferenceSpotDate(), is(new LocalDate(2013, 5, 17)));
        assertThat(page12M.getConfigVersion(), is(-1L));
        assertThat(page12M.getState(), is(QuoteState.STREAMABLE));
        assertThat(page12M.getVersion() > 0, is(true));
        assertThat(page12M.getQuotePageType(), is(QuotePageType.BANDED));
        assertThat(page12M.getQuotes().size(), is(1));
        assertQuote(page12M.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.valueOf("-42.65"))
                .withAskPrice(Decimal.valueOf("-42.35"))
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());
    }

    @Test
    public void synthesizes_spot_when_processing_non_spot_trep_update_and_configured_not_to_publish_trep_spot_quote() {
        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfig.setValue("false");
        generalConfigDAO.save(generalConfig);

        Item item = new ItemBuilder("AUD2M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();

        // under test
        subscriber.onUpdate(item);

        final ForwardPointsQuotePage twoMonthsQuotePage = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.TWO_MONTH.getKey()));
        assertNotNull(twoMonthsQuotePage);
        assertQuote(twoMonthsQuotePage.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.valueOf("-42.65"))
                .withAskPrice(Decimal.valueOf("-42.35"))
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());

        final ForwardPointsQuotePage spotQuotePage = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.SPOT.getKey()));
        assertQuote(spotQuotePage.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.ZERO)
                .withAskPrice(Decimal.ZERO)
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());
    }

    @Test
     public void publish_trep_spot_as_zero_forwardPoints_when_configured_to_publish_trep_spot_quotes() {
        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfig.setValue("true");
        generalConfigDAO.save(generalConfig);

        Item item = new ItemBuilder("AUDSPOT=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();

        // under test
        subscriber.onUpdate(item);
        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.SPOT.getKey()));
        assertThat(page.getTenor(), is(Tenor.SPOT));
        assertThat(page.getQuotes().size(), is(1));
        assertQuote(page.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.ZERO)
                .withAskPrice(Decimal.ZERO)
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());
    }

    @Test
    public void publish_trep_spot_as_zero_forwardPoints_AND_wholesaleSpot_when_configured_to_publish_trep_spot_quotes_and_process_nonDeliverable_currency() {

        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfig.setValue("true");
        generalConfigDAO.save(generalConfig);

        Item item = new ItemBuilder("KR1=D3")
                .withField("GV1_TEXT", "USDKR1")
                .withField("GV1_DATE", "17 JUL 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();

        // under test
        subscriber.onUpdate(item);
        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("USD/KR1", Tenor.SPOT.getKey()));
        assertThat(page.getTenor(), is(Tenor.SPOT));
        assertThat(page.getQuotes().size(), is(2));
        assertQuote(page.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.ZERO)
                .withAskPrice(Decimal.ZERO)
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());
        assertQuote(page.getQuotes().get(1), new QuoteBuilder()
                .withBidPrice(Decimal.valueOf("-42.65"))
                .withAskPrice(Decimal.valueOf("-42.35"))
                .withQuotePriceType(QuotePriceType.WHOLESALE_SPOT_PRICE)
                .withState(QuoteState.STREAMABLE)
                .build());
    }

    @Test
    public void synthesizes_spot_when_configured_to_publish_trep_spot_quotes_but_no_live_spot_has_been_received_yet() {
        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfig.setValue("true");
        generalConfigDAO.save(generalConfig);

        Item item = new ItemBuilder("AUD2M=D3")
                .withField("GV1_TEXT", "AUDUSD")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build();

        // under test
        subscriber.onUpdate(item);
        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("AUD/USD", Tenor.SPOT.getKey()));
        assertThat(page.getQuotes().size(), is(1));
        assertQuote(page.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.ZERO)
                .withAskPrice(Decimal.ZERO)
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());
    }

    @Test
    public void should_not_synthesize_spot_when_configured_to_publish_trep_spot_quotes_and_trep_spot_has_been_received_before() {
        final GeneralConfig generalConfig = generalConfigDAO.findByKeyOrCreate(GeneralConfig.Key.PUBLISH_TREP_SPOT_FORWARD_POINT);
        generalConfig.setValue("true");
        generalConfigDAO.save(generalConfig);

        subscriber.onUpdate(new ItemBuilder("KR1=D3")
                .withField("GV1_TEXT", "USDKR1")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-42.35")
                .withField("BID", "-42.65")
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 MAY 2013")
                .withField("TIMACT", "02:42")
                .build());

        // under test
        subscriber.onUpdate(new ItemBuilder("KR12M=D3")
                .withField("GV1_TEXT", "USDKR1")
                .withField("GV1_DATE", "17 MAY 2013")
                .withField("ASK", "-30.35") // should not be published
                .withField("BID", "-30.65") // should not be published
                .withField("GEN_TEXT16", "LIVE")
                .withField("MATUR_DATE", "17 JUL 2013")
                .withField("TIMACT", "02:42")
                .build());
        ForwardPointsQuotePage page = forwardPointsQuotePageDAO.findByKey(new ForwardPointsQuotePageKey("USD/KR1", Tenor.SPOT.getKey()));

        assertThat(page.getQuotes().size(), is(2));

        assertQuote(page.getQuotes().get(0), new QuoteBuilder()
                .withBidPrice(Decimal.ZERO)
                .withAskPrice(Decimal.ZERO)
                .withQuotePriceType(QuotePriceType.FORWARD_POINTS)
                .withState(QuoteState.STREAMABLE)
                .build());

        assertQuote(page.getQuotes().get(1), new QuoteBuilder()
                .withBidPrice(Decimal.valueOf("-42.65"))
                .withAskPrice(Decimal.valueOf("-42.35"))
                .withQuotePriceType(QuotePriceType.WHOLESALE_SPOT_PRICE)
                .withState(QuoteState.STREAMABLE)
                .build());
    }


    private void assertQuote(final Quote actualQuote,
                             final Quote expectedQuote) {
        assertThat(actualQuote.getMaxQuantity(), nullValue());
        assertThat(actualQuote.getBidPrice(), is(expectedQuote.getBidPrice()));
        assertThat(actualQuote.getAskPrice(), is(expectedQuote.getAskPrice()));
        assertThat(actualQuote.getQuotePriceType(), is(expectedQuote.getQuotePriceType()));
        assertThat(actualQuote.getState(), is(expectedQuote.getState()));
    }
}
