package com.anz.markets.disco.data.kdb;

import com.anz.markets.disco.data.Signal;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.prophet.domain.marketdata.impl.InstrumentAndMarketEnablementFilter;
import com.anz.markets.prophet.kdb.KDBBatchPublisher;
import com.anz.markets.prophet.kdb.KDBPublisher;
import com.anz.markets.prophet.status.Context;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;

public class KDBSignalsBatchPublisher {

    public static final String TABLE_NAME = "discosignals";
    private static final String TABLE_COLS = "sssjjisfCppp";

    private final KDBBatchPublisher<Signal> publisher;

    private final boolean synchronous;
    private final InstrumentAndMarketEnablementFilter filter;
    private final String regionName;

    private Signals currentSignals;
    private int currentSignalIndex;

    public KDBSignalsBatchPublisher(final KDBPublisher kdbPublisher,
                                    final boolean synchronous,
                                    final InstrumentAndMarketEnablementFilter filter) {

        this.publisher = new KDBBatchPublisher(kdbPublisher, TABLE_NAME, TABLE_COLS, 100, 4, synchronous, signalDecoder);
        this.synchronous = synchronous;
        this.filter = filter;
        this.regionName = Context.context().region().kdbName();
    }

    @NotNull
    public Consumer<Signals> consumeSignals() {
        return signals -> {
            if (filter.allow(signals)) {
                process(signals);
            }
        };
    }

    @NotNull
    public Consumer consumerOfEvent() {
        return rateChime -> flush();
    }

    private final KDBBatchPublisher.ObjectDecoder<Signal> signalDecoder = new KDBBatchPublisher.ObjectDecoder<Signal>() {

        @Override
        public void populate(Signal s) {
            s(currentSignals.getInstrument().name());
            s(currentSignals.getMarket().name());
            s(regionName);
            j(Context.context().header().getEventId());
            j(currentSignals.getSignalsId());
            i(currentSignalIndex);  // Note: had problems using x for some reason - bug in KDB library?
            s(s.getSignalType().name());
            f(s.getValue());
            C(s.getConditionCode().toString().toCharArray());
            pNanos(currentSignals.getExternalEventTimeNS());
            pNanos(Context.context().timeSource().nowNanos());
            pNanos(Context.context().header().getFinishTimeStampNS());
        }
    };

    private void process(@NotNull final Signals signals) {
        this.currentSignals = signals;
        for (int i = 0; i < signals.getSize(); i++) {
            currentSignalIndex = i;
            publisher.addEvent(signals.getSignal(i));
        }
    }

    private void flush() {
        publisher.publish();
    }

    @Override
    public String toString() {
        return "KDBSignalsPublisher{" +
                "table=" + TABLE_NAME +
                ", synchronous=" + synchronous +
                ", filter=" + filter +
                '}';
    }
}