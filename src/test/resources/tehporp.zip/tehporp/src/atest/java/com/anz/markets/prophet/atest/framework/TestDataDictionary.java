package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.FilterEnabledConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourEntity;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PriceAndQty;
import com.anz.markets.prophet.domain.QuoteType;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;

import java.time.LocalDate;
import java.util.List;

public interface TestDataDictionary {

    MarketDataSnapshot marketDataSnapshot_pullPrice(Market market,
                                                    Instrument instrument);

    /**
     * @return market data for bla bla bla
     */
    MarketDataSnapshot marketDataSnapshot_001();

    MarketDataSnapshot marketDataSnapshot(Instrument instrument,
                                          double mid,
                                          double spread);

    MarketDataIncrement marketDataIncrementNew(final Market market, final Instrument instrument,
                                               final double price, final long externalSourceId);

    MarketDataSnapshot marketDataSnapshot(Instrument instrument,
                                          double mid);

    MarketDataSnapshot marketDataSnapshot(Market market,
                                          Instrument instrument,
                                          double mid,
                                          double spread);

    MarketDataSnapshot marketDataSnapshot(Market market,
                                          Instrument instrument,
                                          double mid);

    MarketDataSnapshot emptyMarketDataSnapshot(Market market, Instrument instrument);

    MarketDataSnapshot emptyMarketDataSnapshot(Instrument instrument);

    MarketDataSnapshot marketDataSnapshot(
            Market market,
            Instrument instrument,
            double mid,
            double spread,
            long triggerTimeMs);

    MarketDataSnapshot marketDataSnapshotWithBidOffer(final Instrument instrument,
                                                      final double bid,
                                                      final double offer);

    MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                      final Instrument instrument,
                                                      final double bid,
                                                      final double offer);

    MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                      final Instrument instrument,
                                                      final double bid,
                                                      final double bidQty,
                                                      final double offer,
                                                      final double offerQty);

    MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                      final Instrument instrument,
                                                      final double bid,
                                                      final double offer,
                                                      final long triggerTimeMs);

    MarketDataSnapshot marketDataSnapshotWithBidOffer(final Market market,
                                                      final Instrument instrument,
                                                      final double bid,
                                                      final double bidQty,
                                                      final double offer,
                                                      final double offerQty,
                                                      final long triggerTimeMs);

    MarketDataSnapshot marketDataSnapshotWithBidOffers(final Market market,
                                                       final Instrument instrument,
                                                       final List<PriceAndQty> bids,
                                                       final List<PriceAndQty> asks,
                                                       final long triggerTimeMs);

    MarketDataSnapshot marketDataSnapshotWithBidOffers(final Market market,
                                                       final Instrument instrument,
                                                       final List<PriceAndQty> bids,
                                                       final List<QuoteType> bidQuoteTypes,
                                                       final List<PriceAndQty> asks,
                                                       final List<QuoteType> offerQuoteTypes,
                                                       final long triggerTimeMs);

    MarketDataSnapshot marketDataSnapshotWithBidOfferOrderIds(Market market,
                                                              Instrument instrument,
                                                              List<PriceAndQty> bids,
                                                              List<String> bidOrderIds,
                                                              List<PriceAndQty> offers,
                                                              List<String> offerOrderIds,
                                                              long triggerTimeMs);


    MarketDataSnapshot marketDataSnapshotWithBidOfferOrderIds(Market market,
                                                              Instrument instrument,
                                                              List<PriceAndQty> bids,
                                                              List<String> bidOrderIds,
                                                              List<QuoteType> bidQuoteTypes,
                                                              List<PriceAndQty> offers,
                                                              List<String> offerOrderIds,
                                                              List<QuoteType> offerQuoteTypes,
                                                              long triggerTimeMs);

    MarketDataIncrement marketDataIncrementDelete(Market market,
                                                  Instrument instrument,
                                                  String orderId,
                                                  OrderSide orderSide,
                                                  long triggerTimeMs);

    /**
     * Skew a given market data on both side by given points.
     * This method provides a convenience way to mutate the existing market data.
     *
     * @param points            added to both bid and ask at all levels.
     * @param marketDataMessage
     * @return new skewed marketDataMessage
     */
    MarketDataSnapshot skew(double points,
                            MarketDataSnapshot marketDataMessage);

    /**
     * @return Base configuration with generally no specific pair configs. Useful as a foundation to overlay currency & instrument
     * specific config.
     */
    ConfigurationDataDefault configuration_pricing_base();

    HourChime hourChime(int hourOfDayInUtc);

    /**
     * @return Configuration for minimum viable config for pricing
     */
    ConfigurationDataDefault configuration_pricing_001();

    ConfigurationDataDefault configuration_hedging_001();

    EconNews econNews(long eventTimeStamp);

    /**
     * @param qty
     * @param price
     * @return Positions for ....
     */
    Trade client_trade_001(final double qty, double price);

    Trade client_trade_001(final Instrument instrument, final double qty, double price);

    Trade client_trade_001(final Instrument instrument, final double qty, double price, final String counterparty);

    Trade client_trade_002(final Instrument instrument,
                           final double qty,
                           final double price,
                           final CharSequence orderId);

    Trade hedge_trade_001(
            Portfolio portfolio,
            Instrument instrument,
            double qty,
            double price);

    Trade hedge_trade_002(
            Portfolio portfolio,
            Instrument instrument,
            double qty,
            double price,
            CharSequence orderId);

    ForwardPoint forwardPoint(Instrument instrument,
                              double bidPoints,
                              double offerPoints,
                              LocalDate referenceSpotDate,
                              LocalDate tenorDate, final Tenor tenor);


    Adjustment adjustment(Currency currency, double amount);

    Adjustment adjustment(Currency currency, double amount, double fillRate);

    Adjustments adjustments(final Adjustment... adjustmentList);

    OptimalPosition optimalPosition(final Instrument instrument,
                                double instrumentPositionNotional,
                                double notionalAmount,
                                double systemBaseAmount,
                                double gradientNotionalAmount,
                                double gradientSystemBaseAmount,
                                double gradient,
                                double rate);

    BiasPositionControl biasPosition(final Currency ccy, final double bias);

    ManualSkewControl manualSkew(final Currency ccy, final double skew);

    /**
     * Current time in ms from acceptance test timeSource. This timeSource is maintained by
     * ProphetServerEmbeddedImpl and is recreated when the prophet server is restarted
     */
    long now();

    List<FilterEnabledConfig> disableFilter(MarketDataFilterType filterType);

    List<FilterEnabledConfig> enableFilter(MarketDataFilterType filterType);

    HedgeControl enableHedger(Portfolio portfolio);

    HedgeControl disableHedger(Portfolio portfolio);

    OrderEvent hedgeOrderConfirmed(final NewOrder newOrder);

    // used for Suspicious Discrepancy firewall testing
    OrderEvent hedgeOrderConfirmed(final NewOrder newOrder, final double remainingAmount);

    OrderEvent hedgeOrderReject(final NewOrder newOrder);

    OrderEvent hedgeOrderAcknowledgeCancel(final NewOrder newOrder, final CancelOrder cancelOrder,
                                           final double filledQuantity, final double filledPrice);

    OrderEvent hedgeUnsolicitedOrderReject(final NewOrder newOrder, final double filledQuantity,
                                           final double filledPrice);

    OrderEvent hedgeOrderRejectCancel(final NewOrder newOrder, final CancelOrder cancelOrder);

    OperatingHourChime createOperatingHourChime(OperatingHourEntity entity, String specs);

    HedgerFirewallReset createHedgerFirewallReset(final Portfolio portfolio, final HedgeFirewallType hedgeFirewallType);

    VolatilityControl setManualGlobalVol(final double vol);

    VolatilityControl setManualCcyVol(final Currency currency, final double vol);

    VolatilityControl setManualMarketVol(final Market market, final double vol);

    HedgeCurrencyControl setHedgingPause (final Currency ccy, final boolean flag);

    SkewCurrencyControl setSkewingPause (final Currency ccy, final boolean flag);

    PricePauseControl setPricePauseControl(final boolean pricingEnabled, final Currency ccy, final Market... markets);

    MarketDataSnapshot marketDataSnapshotWithExternalSourceId(final Instrument instrument, final double mid, final double spread, final long externalSourceId);
}
