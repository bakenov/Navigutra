package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.codec.sbe.InstrumentConfigSbeDecoder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class InstrumentConfigCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(InstrumentConfigCommand.class);

    private final CommandContext commandContext;
    private final InstrumentConfigSbeDecoder instrumentConfigDecoder = new InstrumentConfigSbeDecoder();


    private final StringBuilder stringBuilder = new StringBuilder();

    public InstrumentConfigCommand(final CommandContext commandContext) {
        this.commandContext = Objects.requireNonNull(commandContext);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!instrumentConfigDecoder.wrap(message)) return false;
        logMessage();
        commandContext.eventApplier().decode(message);
        return true;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        instrumentConfigDecoder.appendTo(stringBuilder);
        LOGGER.info("Create or Update Instrument Command: {}", stringBuilder);
    }
}
