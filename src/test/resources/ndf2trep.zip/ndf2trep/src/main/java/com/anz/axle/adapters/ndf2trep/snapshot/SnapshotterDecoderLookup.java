package com.anz.axle.adapters.ndf2trep.snapshot;

import java.util.Collection;

import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface SnapshotterDecoderLookup {

    SnapshotterDecoderSupplier lookup(RequestKey requestKey);
    Collection<SnapshotterDecoderSupplier> snapshotterDecoderSuppliers();
}
