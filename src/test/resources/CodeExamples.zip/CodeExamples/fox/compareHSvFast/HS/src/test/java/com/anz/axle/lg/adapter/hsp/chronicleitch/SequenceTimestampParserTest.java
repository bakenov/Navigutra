package com.anz.axle.lg.adapter.hsp.chronicleitch;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;

import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SequenceTimestampParserTest {

    private static final int HH18_MM_SS_MMM = 181549841;
    private LocalDate localDate = LocalDate.now(ZoneId.of("UTC"));
    private SequenceTimestampParser parser;
    private PrecisionClock precisionClock;

    @Before
    public void setUp() throws Exception {
        precisionClock = mock(PrecisionClock.class);
        when(precisionClock.millis()).thenReturn(NanoClock.nanoClockUTC().millis());
        when(precisionClock.nanos()).thenReturn(1L);
        parser = new SequenceTimestampParser(precisionClock);
    }

    @Test
    public void sendingTimeNanosOrNow_now() throws Exception {
        final PrecisionClock clock = mock(PrecisionClock.class);
        when(clock.nanos()).thenReturn(1L);
        final long sendingTimeNanos = parser.sendingTimeNanosOrNow(null);
        assertThat(sendingTimeNanos , is(1L));
    }

    @Test
    public void testToUTC() throws Exception {
        testToUTC(201253841, 0, 12, 53);
        testToUTC(231253841, 3, 12, 53);
    }

    private void testToUTC(final long nyHHSSMMsss, final int expectedHour, final int expectedMin, final int expectedSec) throws Exception {
        final long sendingTimeNanos = parser.sendingTimeNanos(nyHHSSMMsss);
        final Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.setTimeInMillis(TimeUnit.NANOSECONDS.toMillis(sendingTimeNanos));
        System.out.println(LocalDateTime.ofInstant(Instant.ofEpochMilli(TimeUnit.NANOSECONDS.toMillis(sendingTimeNanos)),ZoneId.of("UTC")));

        assertThat(calendar.get(Calendar.HOUR), is(expectedHour));
        assertThat(calendar.get(Calendar.MINUTE), is(expectedMin));
        assertThat(calendar.get(Calendar.SECOND), is(expectedSec));
        assertThat(calendar.get(Calendar.MILLISECOND), is(841));
    }

    private LocalTime toLocalTime(final int hhMMSSmmm) {
        final int hh = (hhMMSSmmm/1000000_0);
        final int mm = (hhMMSSmmm/100000) - (hh*100);
        final int ss = (hhMMSSmmm/1000) - ((hh*10000) + (mm*100)) ;
        final int mmm = (hhMMSSmmm - ((hh*10000000) + (mm*100000) + (ss*1000)));

        return LocalTime.of(hh, mm, ss, (int)TimeUnit.MILLISECONDS.toNanos(mmm));
    }

    @Test
    public void sendingTimeNanos() throws Exception {
        final LocalTime localTime = toLocalTime(HH18_MM_SS_MMM);
        final LocalDateTime localDateTime = LocalDateTime.of(localDate, localTime);
        assertThat(localDateTime.toString(), is(localDate.toString()+"T"+localTime.toString()));
    }
}