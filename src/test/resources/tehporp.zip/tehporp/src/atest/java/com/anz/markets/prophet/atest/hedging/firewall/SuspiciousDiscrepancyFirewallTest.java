package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.HedgeOrderSide;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import org.hamcrest.Matchers;
import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.SUSPICIOUS_DISCREPANCY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@RestartBeforeTest(reason="after first test subsequent tests will fail. not sure why")
@Requirement({Requirement.Ref.HEDGING_FIREWALL_4_9_4})
public class SuspiciousDiscrepancyFirewallTest extends BaseAcceptanceSpecification {
    Portfolio portfolio = HEDGER_AGGRESSIVE;

    public void shouldTriggerWhenAckAmtDiffers() throws Exception {
        NewOrder newOrder;
        CancelOrder cancelOrder;

        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 999_999.0));
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(SUSPICIOUS_DISCREPANCY, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*does not match submitted qty.*"));

            prophet.expect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // min TTL
        }
        then:
        {
            cancelOrder = prophet.expect(CancelOrder.class, exactly(1)).getLast();
        }
        when:
        {
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(newOrder, cancelOrder, 0.0, 0.0));
        }
        then:
        {
            prophet.expect(HedgeStatus.class, hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldResetViaTurningOnHedger() throws Exception {
        setup:
        {
            setup();
        }
        given:
        {
            shouldTriggerWhenAckAmtDiffers();
        }
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(SUSPICIOUS_DISCREPANCY, NOT_BREACHED, portfolio));
        }
        and:
        {
            shouldTriggerWhenAckAmtDiffers();
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() throws Exception {
        setup:
        {
            setup();
        }
        given:
        {
            shouldTriggerWhenAckAmtDiffers();
        }
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, SUSPICIOUS_DISCREPANCY));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallStatus(SUSPICIOUS_DISCREPANCY, NOT_BREACHED, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }
    }

    @Test
    public void shouldNotTriggerWhenAckAmtEquals() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldNotTriggerWhenConfirmedAndCompletedAmtsEqualOriginal() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderFullFill(newOrder);
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    // Partially filled orders(which are CANCELLED) are not checked
    public void shouldNotTriggerWhenPartiallyCompleted() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 500_000, 0.9510);
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldTriggerWhenOverFilled() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderPartialFill(newOrder, 500_000, 0.9500);
            prophet.receiveHedgeOrderPartialFillOverFill(newOrder, 500_001, 1_000_001, 0.9500);
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(SUSPICIOUS_DISCREPANCY, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*is more than submitted qty.*"));

            prophet.expect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
            prophet.expect(HedgeStatus.class, hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    // Partially filled orders(which are CANCELLED) are not checked
    public void shouldNotTriggerWhenPartiallyFilledAtWorsePrice() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.9510));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
        }
        when:
        // BUY order partially filled at worse price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderCompletedWithPartialFill(newOrder, 500_000, 0.95101);
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldTriggerWhenSellCompletedAtWorsePrice() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, 5_000_000, 0.95100));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.SELL));
        }
        when:
        // filled at worse price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderFullFill(newOrder, newOrder.getPrice() - 0.00001);
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(SUSPICIOUS_DISCREPANCY, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*does not match submitted price.*"));

            prophet.expect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
            prophet.expect(HedgeStatus.class, hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldTriggerWhenBuyCompletedAtWorsePrice() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -5_000_000, 0.95100));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // filled at worse price (price is rounded half up to instrument precision)
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderFullFill(newOrder, newOrder.getPrice() + 0.000005);
        }
        then:
        // breached.
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(SUSPICIOUS_DISCREPANCY, portfolio)).getFirst();
            assertThat(status.getDescription().toString(), matches(".*does not match submitted price.*"));

            prophet.expect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
            prophet.expect(HedgeStatus.class, hedgeStatusIsOff(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldNotTriggerWhenBuyCompletedAtBetterPrice() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -5_000_000, 0.95100));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // filled at better price
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderFullFill(newOrder, newOrder.getPrice() - 0.00001);
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    @Test
    public void shouldNotTriggerWhenBuyCompletedAtWorsePriceButRoundedDown() throws Exception {
        NewOrder newOrder;
        setup:
        {
            setup();
        }
        when:
        {
            prophet.receive(tdd.client_trade_001(AUDUSD, -5_000_000, 0.95100));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1)); // wait for TWAP order window
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1000000.0));
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
        }
        when:
        // filled at works price but rounded half down to instrument precision
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder, 1_000_000.0));
            prophet.receiveHedgeOrderFullFill(newOrder, newOrder.getPrice() + 0.000004);
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class);
            prophet.notExpect(HedgeStatus.class, hedgeStatusIsPendingDisable(portfolio, HedgePortfolioStateTransition.DISABLE_BY_FIREWALL));
        }
    }

    public void setup() {
        setup:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.configuration_hedging_001());
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));

            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.9500, 0.00004));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.9500));
        }
    }

}
