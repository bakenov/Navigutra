package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.FatalError;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.ConfigurationData;
import com.anz.markets.prophet.domain.CovCorrAvgs;
import com.anz.markets.prophet.domain.EconNews;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.MidRate;
import com.anz.markets.prophet.domain.Trade;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.PreservesMessageVersion;
import com.anz.markets.prophet.domain.chronicle.RawBytes;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.collections.Predicates;
import com.anz.markets.prophet.domain.common.EndEvent;
import com.anz.markets.prophet.domain.common.TestMessage;
import com.anz.markets.prophet.domain.control.BiasPositionControl;
import com.anz.markets.prophet.domain.control.HedgeControl;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.HedgerFirewallReset;
import com.anz.markets.prophet.domain.control.ManualSkewControl;
import com.anz.markets.prophet.domain.control.PricePauseControl;
import com.anz.markets.prophet.domain.control.PricingFirewallReset;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.control.VolatilityControl;
import com.anz.markets.prophet.domain.forward.ForwardPoint;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.marketdata.MarketData;
import com.anz.markets.prophet.domain.order.Order;
import com.anz.markets.prophet.domain.order.OrderEvent;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.spot.SpotDate;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.OperatingHourChime;
import com.anz.markets.prophet.domain.time.SpotDateRollChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.positionrisk.Adjustment;
import com.anz.markets.prophet.positionrisk.Adjustments;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.risk.ValueAtRisk;
import com.anz.markets.prophet.risk.realvol.RealisedVolatility;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.SystemProperties;
import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.Excerpt;
import net.openhft.chronicle.ExcerptAppender;
import net.openhft.chronicle.IndexedChronicle;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.TestOnly;

import java.io.IOException;
import java.util.function.Consumer;
import java.util.function.Predicate;

import static com.anz.markets.prophet.util.ThreadUtils.sleep;

public class LegacyChroniclePersister implements ProphetPersister {
    public static final int EXCERPT_CAPACITY = 2 * 1024 * 1024; // current json file size is 330k
    private static final int LOG_EVERY = 10_000;
    private static final long WAIT_FOR_OTHER_CORE_TO_WRITE_MS = 1L;
    private static final Logger LOGGER = LogManager.getLogger(LegacyChroniclePersister.class);
    private final LegacyChroniclePersisterConfig config;
    private Chronicle chronicle;
    private ExcerptAppender appender;
    private long lastEventIdWritten;
    private boolean active;
    private int inactiveCount = 0;
    private int eventIdCount = 0;
    private final Writedown writedown;

    private String currentChroniclePath;

    public LegacyChroniclePersister(final LegacyChroniclePersisterConfig config, final boolean active) throws IOException {
        this(config, active, Predicates.alwaysTrue());
    }

    public LegacyChroniclePersister(final LegacyChroniclePersisterConfig config, final boolean active, final Predicate<MessageType> messageTypePredicate) throws IOException {
        LOGGER.info("Created persister for chronicle config={}, active={}", config, active);

        this.config = config;
        this.lastEventIdWritten = -1;
        this.active = active;
        this.writedown = new Writedown(messageTypePredicate);
        this.currentChroniclePath = config.chroniclePath();
        setActivationStatus();
    }

    private void accept(Trade trade) {
        write(MessageType.TRADE, (ProphetMarshallable) trade);
    }

    private void accept(MarketData marketData) {
        sinkMarketData().accept(marketData);
    }

    private void accept(@NotNull final ClientPrice clientPrice) {
        write(MessageType.CLIENT_PRICE, (ProphetMarshallable) clientPrice);
    }

    private void accept(@NotNull ValueAtRisk valueAtRisk) {
        write(MessageType.VALUE_AT_RISK, (ProphetMarshallable) valueAtRisk);
    }

    private void accept(@NotNull WholesaleBookFactors wholesaleBookFactors) {
        write(MessageType.WHOLESALE_BOOK_FACTORS, (ProphetMarshallable) wholesaleBookFactors);
    }

    private void acceptMidRate(MidRate midRate) {
        sinkMidRate().accept(midRate);
    }

    private void accept(Adjustment adjustment) {
        write(MessageType.ADJUSTMENT, (ProphetMarshallable) adjustment);
    }

    private void accept(OptimalPositions optimalPositions) {
        write(MessageType.OPTIMAL_POSITIONS, optimalPositions);
    }

    private void accept(Positions positions) {
        write(MessageType.POSITIONS, positions);
    }

    private void accept(OneSecond oneSecond) {
        write(MessageType.ONE_SECOND, oneSecond);
    }

    private void accept(TradingTimeZoneChime tradingTimeZoneChime) {
        write(MessageType.TIMEZONE_CHIME, tradingTimeZoneChime);
    }

    private void accept(HourChime hourChime) {
        write(MessageType.HOUR_CHIME, hourChime);
    }

    private void accept(EndOfWeekChime endOfWeekChime) {
        write(MessageType.END_OF_WEEK_CHIME, endOfWeekChime);
    }

    private void accept(Order order) {
        sinkOrder().accept(order);
    }

    private void accept(final RealisedVolatility realisedVolatility) {
        write(MessageType.REALISED_VOLATILITY, (ProphetMarshallable) realisedVolatility);
    }

    private void accept(HedgePauseSignal hedgePauseSignal) {
        write(MessageType.HEDGE_PAUSE_SIGNAL, (ProphetMarshallable) hedgePauseSignal);
    }

    private void accept(Activate activate) {
        write(MessageType.ACTIVATE, activate);
    }

    @Override
    public void processActivationMessage(final Activate activate) {
        if (config.activationAware().yes()) {
            boolean activeBefore = this.active;
            this.active = activate.getStatus().isActive();
            LOGGER.info("activate before {} now {}", activeBefore, activate.getStatus());
            if (this.active != activeBefore) {
                try {
                    setActivationStatus();
                } catch (Exception e) {
                    throw new FatalError(e);
                }
            }
        } else {
            LOGGER.warn("Ignoring activation message {}", activate);
        }
    }

    @NotGcFriendly("generates a single piece of garbage but is called very infrequently")
    private synchronized void setActivationStatus() throws IOException {
        if (active) {
            LOGGER.info("Opening chronicle {} {}", currentChroniclePath, config);
            chronicle = config.createChronicle(currentChroniclePath);
            LOGGER.info("Reactivating persister to chronicle {} lastIndex {}", chronicle.name(), chronicle.lastIndex());

            if (config.append().enabled() && chronicle.size() > 0L) {
                final Header activationHeader = new Header();
                final long eventId = Context.context().header().getEventId();
                try (final Excerpt excerpt = chronicle.createExcerpt()) {
                    // this will point us to the last item in the queue
                    excerpt.toEnd();
                    final ProphetBytes wrappedExcerpt = LegacyChronicleWrappers.wrap(excerpt);
                    MessageType messageType = ChronicleObjectReader.readHeader(wrappedExcerpt, activationHeader);
                    assert eventId != 0L;
                    int waitCount = 0;
                    // make sure that the chronicle.out is up to the eventId we were activated by
                    LOGGER.info("Looking for eventId {}", eventId);
                    while (activationHeader.getEventId() < eventId) {
                        excerpt.toEnd();
                        messageType = ChronicleObjectReader.readHeader(wrappedExcerpt, activationHeader);
                        if ((waitCount++ % LOG_EVERY) == 0) {
                            LOGGER.info("Waiting to catchup for activate {}", waitCount);
                        }
                        sleep(WAIT_FOR_OTHER_CORE_TO_WRITE_MS);
                    }
                    // how to detect the other core has actually closed its chronicle? For now, just wait
                    sleep(SystemProperties.ACTIVATE_PAUSE_MS);
                    lastEventIdWritten = activationHeader.getEventId();
                    // need to tell chronicle to update it last written index so appender points to end
                    ((IndexedChronicle) chronicle).findTheLastIndex();
                    appender = chronicle.createAppender();
                    GcFriendlyAssert.isTrue(appender.index() >= excerpt.index());
                    LOGGER.warn("Activated: last messageType {} lastWrittenIndex {} lastEventIdWritten {} appender last index {}",
                            messageType, excerpt.index(), lastEventIdWritten, appender.index());
                }
            } else {
                appender = chronicle.createAppender();
                LOGGER.warn("Activated: empty output chronicle or !append");
            }
        } else {
            if (this.appender == null) {
                LOGGER.warn("Deactivated");
            } else {
                this.appender.close();
                this.chronicle.close();
                LOGGER.warn("Deactivated: lastWrittenIndex {} lastEventIdWritten {}",
                        this.appender.lastWrittenIndex(), Context.context().header().getEventId());
            }
        }
    }

    private class Writedown {

        private final Predicate<MessageType> messageTypePredicate;

        private Writedown(final Predicate<MessageType> messageTypePredicate) {
            this.messageTypePredicate = messageTypePredicate;
        }

        protected void write(final ProphetMarshallable entity, final MessageType messageType) {
            if (messageTypePredicate.test(messageType)) {
                final Context context = Context.context();
                final Header header = context.header();
                if (header.getEventId() <= lastEventIdWritten) {
                    if ((eventIdCount++ % LOG_EVERY) == 0) {
                        LOGGER.info("Under eventId {}", eventIdCount);
                    }
                    return;
                }

                if (!active) {
                    if ((inactiveCount++ % LOG_EVERY) == 0) {
                        LOGGER.info("Inactive {}", inactiveCount);
                    }
                    return;
                }

                if (LOGGER.isTraceEnabled()) {
                    LOGGER.trace("Writing messageType {} index {}", messageType, appender.index());
                }
                // write to chronicle. Market data can be quite big so have given quite a high excerpt size
                appender.startExcerpt(EXCERPT_CAPACITY);
                appender.writeByte(messageType.getValue());
                config.beforeWrite().onEvent(context, messageType);
                final ProphetBytes wrappedAppender = LegacyChronicleWrappers.wrap(appender);
                if (entity instanceof PreservesMessageVersion) {
                    header.writeMarshallablePreserveMessageVersion(wrappedAppender, (PreservesMessageVersion) entity);
                } else {
                    header.writeMarshallable(wrappedAppender);
                }
                entity.writeMarshallable(wrappedAppender);
                appender.finish();
                config.afterWrite().onEvent(context, messageType);
            }
        }
    }

    // TODO: making this synchronized right now is a bit blunt, but Chronicle doco seems to advise this is the easiest
    // way, and we have 3+ input queues writing, and the timer task.
    @Override
    public synchronized void write(final MessageType messageType, final ProphetMarshallable entity) {
        writedown.write(entity, messageType);
    }


    // TODO: instead of having consumers for all different types, can we just Consume<Object> (so long
    // as it implements ProphetMarshallable) and then call work out what MessageType is from MessageTypeClassMap

    public Consumer<Trade> consumerTrade() {
        return this::accept;
    }

    public Consumer<MarketData> consumerMarketDataMessage() {
        return this::accept;
    }

    public Consumer<ClientPrice> consumerClientPrice() {
        return this::accept;
    }

    public Consumer<ValueAtRisk> consumerValueAtRisk() {
        return this::accept;
    }

    public Consumer<WholesaleBookFactors> consumerWholesaleBookFactors() {
        return this::accept;
    }

    public Consumer<MidRate> consumerMidRate() {
        return this::acceptMidRate;
    }

    public Consumer<Adjustment> consumerAdjustment() {
        return this::accept;
    }

    public Consumer<Adjustments> consumerAdjustments() {
        return adjustments -> write(MessageType.ADJUSTMENTS, (ProphetMarshallable) adjustments);
    }

    public Consumer<OptimalPositions> consumerOptimalPositions() {
        return this::accept;
    }

    public Consumer<Positions> consumerPosition() {
        return this::accept;
    }

    public Consumer<ProfitAndLoss> consumerProfitAndLoss() {
        return profitAndLoss -> {
            write(MessageType.PROFIT_AND_LOSS, (ProphetMarshallable) profitAndLoss);
        };
    }

    public Consumer<TradingTimeZoneChime> consumerTradingTimeZoneChime() {
        return this::accept;
    }

    public Consumer<OneSecond> consumerOneSecond() {
        return this::accept;
    }

    public Consumer<HourChime> consumerHourChime() {
        return this::accept;
    }

    public Consumer<EndOfWeekChime> consumerEndOfWeekChime() {
        return this::accept;
    }

    public Consumer<Activate> consumerActivate() {
        return this::accept;
    }

    public Consumer<Order> consumerOrder() {
        return this::accept;
    }

    public Consumer<RealisedVolatility> consumerRealisedVolatility() {
        return this::accept;
    }

    public Consumer<HedgePauseSignal> consumerDealVolumeSignal() {
        return this::accept;
    }

    public Consumer<ConfigurationData> consumerConfigurationData() {
        return configurationData -> {
            write(MessageType.CONFIGURATION, (ProphetMarshallable) configurationData);
        };
    }

    public Consumer<IndexedConfigurationData> consumerIndexedConfigurationData() {
        return indexedConfigurationData -> {
            write(MessageType.CONFIGURATION, (ProphetMarshallable) indexedConfigurationData.getConfigurationData());
        };
    }

    public Consumer<TestMessage> consumerTestMessage() {
        return testMessage -> write(MessageType.TEST, (ProphetMarshallable) testMessage);
    }

    public Consumer<EndEvent> consumerEndEvent() {
        return endEvent -> write(MessageType.END_EVENT, (ProphetMarshallable) endEvent);
    }

    public Consumer<SpotDate> consumerSpotDate() {
        return spotDate -> write(MessageType.SPOT_DATE, (ProphetMarshallable) spotDate);
    }

    public Consumer<ForwardPoint> consumerForwardPoint() {
        return forwardPoint -> write(MessageType.FORWARD_POINT, (ProphetMarshallable) forwardPoint);
    }

    public Consumer<VolatilityControl> consumerVolatilityControl() {
        return volatilityControl -> write(MessageType.VOLATILITY_CONTROL, (ProphetMarshallable) volatilityControl);
    }

    public Consumer<BiasPositionControl> consumerBiasPositionControl() {
        return biasPositionControl -> write(MessageType.BIAS_OFFSET_CONTROL, (ProphetMarshallable) biasPositionControl);
    }

    public Consumer<HedgeControl> consumerHedgeControl() {
        return hedgeControl -> write(MessageType.HEDGE_CONTROL, (ProphetMarshallable) hedgeControl);
    }

    public Consumer<HedgeCurrencyControl> consumerHedgeCurrencyControl() {
        return hedgeCurrencyControl -> write(MessageType.HEDGE_CURRENCY_CONTROL, (ProphetMarshallable) hedgeCurrencyControl);
    }

    public Consumer<HedgeStatus> consumerHedgeStatus() {
        return hedgeStatus -> write(MessageType.HEDGE_STATUS, (ProphetMarshallable) hedgeStatus);
    }

    public Consumer<RiskPath> consumerRiskPath() {
        return riskPath -> write(MessageType.RISK_PATH, (ProphetMarshallable) riskPath);
    }

    public Consumer<HedgeDecision> consumerHedgeDecision() {
        return hedgeDecision -> write(MessageType.HEDGE_DECISION, (ProphetMarshallable) hedgeDecision);
    }

    public Consumer<HedgeFirewallStatus> consumerHedgeFirewallStatus() {
        return hedgeFirewallStatus -> write(MessageType.HEDGE_FIREWALL_STATUS, (ProphetMarshallable) hedgeFirewallStatus);
    }

    public Consumer<EconNews> consumerEconNews() {
        return econNews -> write(MessageType.ECONNEWS, (ProphetMarshallable) econNews);
    }

    public Consumer<CovCorrAvgs> consumerCovCorrAvgs() {
        return covCorrAvgs -> write(MessageType.COV_CORR, (ProphetMarshallable) covCorrAvgs);
    }

    public Consumer<SkewCurrencyControl> consumerSkewCurrencyControl() {
        return skewCurrencyControl -> write(MessageType.SKEW_CURRENCY_CONTROL, (ProphetMarshallable) skewCurrencyControl);
    }

    public Consumer<ManualSkewControl> consumerManualSkewControl() {
        return manualSkewControl -> write(MessageType.MANUAL_SKEW_CONTROL, (ProphetMarshallable) manualSkewControl);
    }

    public Consumer<PricingFirewallReset> consumerPricingFirewallReset() {
        return firewallReset -> write(MessageType.PRICING_FIREWALL_RESET, (ProphetMarshallable) firewallReset);
    }

    public Consumer<HedgerFirewallReset> consumerHedgerFirewallReset() {
        return firewallReset -> write(MessageType.HEDGER_FIREWALL_RESET, (ProphetMarshallable) firewallReset);
    }

    public Consumer<OrderEvent> consumerOrderEvent() {
        return orderEvent -> write(MessageType.ORDER_EVENT, (ProphetMarshallable) orderEvent);
    }

    public Consumer<OperatingHourChime> consumerOperatingHourChime() {
        return operatingHourChime -> write(MessageType.OPERATING_HOUR_CHIME, operatingHourChime);
    }

    public Consumer<SpotDateRollChime> consumerSpotDateRollChime() {
        return spotDateRollChime -> write(MessageType.SPOT_DATE_ROLL_CHIME, spotDateRollChime);
    }

    public Consumer<PricePauseControl> consumerPricePauseControl() {
        return pricePauseControl -> write(MessageType.PRICE_PAUSE_CONTROL, (ProphetMarshallable) pricePauseControl);
    }

    public Consumer<RawBytes> consumeRawBytes() {
        return (rawBytes) -> {
            write(rawBytes.getMessageType(), rawBytes);
        };
    }

    @Override
    public synchronized void close() throws IOException {
        LOGGER.warn("Closing config {}", config);
        if (appender != null) {
            LOGGER.warn("Closing chronicle {}", chronicle.name());
            appender.close();
            appender = null;
        }
        if (chronicle != null) {
            chronicle.close();
            chronicle = null;
        }
        LOGGER.warn("Closed");
    }

    public enum OpenMode {
        APPEND,
        // use OVERWRITE for testing only
        OVERWRITE;
    }

    @Override
    public long firstIndex() {
        // TODO: check this is valid
        return 0;
    }

    public synchronized long getLastWrittenIndex() {
        return appender.lastWrittenIndex();
    }

    @TestOnly
    public String getCurrentChroniclePath() {
        return currentChroniclePath;
    }

    @TestOnly
    public Chronicle getChronicle() {
        return chronicle;
    }

    @TestOnly
    @Override
    public String toString() {
        return "LegacyChroniclePersister{" +
                "config=" + config +
                ", lastEventIdWritten=" + lastEventIdWritten +
                ", active=" + active +
                ", inactiveCount=" + inactiveCount +
                ", eventIdCount=" + eventIdCount +
                ", currentChroniclePath='" + currentChroniclePath + '\'' +
                '}';
    }
}