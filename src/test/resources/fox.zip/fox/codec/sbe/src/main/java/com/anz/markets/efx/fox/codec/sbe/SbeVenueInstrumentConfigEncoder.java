package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public final class SbeVenueInstrumentConfigEncoder implements VenueInstrumentConfigEncoder, VenueInstrumentConfigEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder venueInstrumentConfigEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();

    private EncodingOrder.VenueInstrumentConfig encodingOrder = EncodingOrder.VenueInstrumentConfig.INITIAL;

    SbeVenueInstrumentConfigEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                                    final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        venueInstrumentConfigEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.VenueInstrumentConfig.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        venueInstrumentConfigEncoder.buffer().setMemory(offset, venueInstrumentConfigEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public Body venue(final Venue venue) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.venue(Enums.venue(venue));
        return this;
    }

    @Override
    public Body instrumentId(final long instrumentId) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.instrumentId(instrumentId);
        return this;
    }

    @Override
    public Body priceIncrement(final double priceIncrement) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.priceIncrement(priceIncrement);
        return this;
    }

    @Override
    public Body sizeIncrement(final int sizeIncrement) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.sizeIncrement(sizeIncrement);
        return this;
    }

    @Override
    public Body clipSizeMultiple(final int clipSizeMultiple) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.clipSizeMultiple(clipSizeMultiple);
        return this;
    }

    @Override
    public Body maxAllowedParentOrderQty(final double maxAllowedParentOrderQty) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.maxAllowedParentOrderQty(maxAllowedParentOrderQty);
        return this;
    }

    @Override
    public Body minClipSize(final int minClipSize) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.minClipSize(minClipSize);
        return this;
    }

    @Override
    public Body maxClipSize(final int maxClipSize) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.maxClipSize(maxClipSize);
        return this;
    }

    @Override
    public Body staleDataTimeout(final int staleDataTimeout) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.staleDataTimeout(staleDataTimeout);
        return this;
    }

    @Override
    public Body priority(final int priority) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.priority(priority);
        return this;
    }

    @Override
    public Body proportion(final int proportion) {
        encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
        venueInstrumentConfigEncoder.proportion((short) proportion);
        return this;
    }

    @Override
    public Trailer enabled(final boolean enabled) {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.VenueInstrumentConfig.TRAILER);
        venueInstrumentConfigEncoder.enabled(enabled ? YesNo.YES : YesNo.NO);
        return messageEncoder;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.TRAILER);
                message.messageLength(headerLength + venueInstrumentConfigEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.VenueInstrumentConfig.INITIAL;
                headerEncoder.wrap(null, 0);
                venueInstrumentConfigEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
