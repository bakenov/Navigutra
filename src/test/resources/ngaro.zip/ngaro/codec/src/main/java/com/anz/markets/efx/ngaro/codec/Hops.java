package com.anz.markets.efx.ngaro.codec;

/**
 * Defines elements to encode and decode message hops.  Hops are touch points of the message, e.g. components
 * which the message has visited on its route.
 */
public interface Hops {

    /**
     * Defines {@link MessageEncoder} steps for hop encoding. It is assumed that hops are the last element in a
     * message which is reflected by the fact that {@link Next#hopsComplete()} returns {@link MessageEncoder.Trailer}.
     *
     * @param <T> the type of the next encoder step after hops
     */
    interface Encoder<T> {
        /**
         * Hops step that allows completing the hops element or adding another hop entry.
         *
         * @param <T> the type of the next encoder step after hops
         */
        interface Next<T> {
            Body<T> next();
            T hopsComplete();
        }

        /**
         * Hops step that allows implementing a hop entry, completing it and adding another hop entry.
         *
         * @param <T> the type of the next encoder step after hops
         */
        interface Body<T> extends Next<T> {
            StringEncoder<Body<T>> hopCompId();
            Body<T> hopMessageId(long messageId);
            Body<T> hopReceivingTime(long nanosSinceEpoch);
            Body<T> hopSendingTime(long nanosSinceEpoch);
        }

        Next<T> hopsStart(int maxEntries);
        T hopsEmpty();
    }

    /**
     * An interface that is implemented by a {@link MessageDecoder.Handler decoder handler} for a message which
     * contains hops.  Hops are touch points of the message, e.g. components which the message has visited on its
     * route.
     */
    interface Handler {
        /**
         * Method that is called to indicate the start of hops decoding.
         * <p>
         * The default implementation is NO-OP as most implementors don't need to handle this.
         *
         * @param maxHopsCount the maximum number of hops that are about to be decoded, may be an over estimate but
         *                     never less than the actual number of hops
         */
        default void onHopsStart(final int maxHopsCount) {
            //no op
        }

        /**
         * Method that is called to decode the elements of a single hop.
         *
         * @param hop provides access to hop elements
         * @param hopsIndex the zero based index of the current hop
         * @param maxHopsCount the maximum number of hops in total, may be an over estimate but never less than the
         *                     actual number of hops
         */
        default void onHops_Body(final Body hop, final int hopsIndex, final int maxHopsCount) {
            //no op
        }

        /**
         * Method that is called to indicate the end of hops decoding.
         * <p>
         * The default implementation is NO-OP as most implementors don't need to handle this.
         *
         * @param hopsCount the actual number of hops that have just been decoded
         */
        default void onHopsComplete(final int hopsCount) {
            //no op
        }

        /**
         * The elements of a hop entry.
         */
        interface Body {
            /** @return component ID decoder for this hop*/
            StringDecoder hopCompId();
            /** @return message ID on this hop*/
            long hopMessageId();
            /** @return receiving time on this op, in nano seconds since epoch*/
            long hopReceivingTime();
            /** @return sending time on this op, in nano seconds since epoch*/
            long hopSendingTime();
        }
    }

    /**
     * Allows introspection of hops encoding notifying a {@link Handler} about the encoded hops elements.
     */
    interface EncoderIntrospector {
        /**
         * Returns a new encoder that forwards to the specified encoder and notifies the introspection handler about
         * encoded hops elements.
         *
         * @param encoder the encoder to be introspected
         *
         * @return the encoder to use instead of the specified encoder to enable introspection
         */
        <T> Encoder<T> introspect(Encoder<T> encoder);

        /**
         * Creates a new introspector notifying all encoded hop elements to the given handler.
         *
         * @param introspectionHandler  handler to be called for encoded hops elements
         * @return a new introspector notifying the given handler
         */
        static EncoderIntrospector create(final Handler introspectionHandler) {
            return new HopsEncoderIntrospector(introspectionHandler);
        }
    }

}
