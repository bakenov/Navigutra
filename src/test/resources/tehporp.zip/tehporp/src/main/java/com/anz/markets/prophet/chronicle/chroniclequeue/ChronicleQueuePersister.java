package com.anz.markets.prophet.chronicle.chroniclequeue;

import com.anz.markets.prophet.annotation.NotGcFriendly;
import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.FatalError;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.chronicle.api.ProphetPersister;
import com.anz.markets.prophet.chronicle.config.PersisterConfig;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.domain.chronicle.Header;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.chronicle.PreservesMessageVersion;
import com.anz.markets.prophet.domain.syscontrol.Activate;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.SystemProperties;
import com.anz.markets.prophet.util.ThreadUtils;
import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.ExcerptTailer;
import net.openhft.chronicle.queue.TailerDirection;
import net.openhft.chronicle.queue.impl.single.SingleChronicleQueue;
import net.openhft.chronicle.wire.DocumentContext;
import org.jetbrains.annotations.TestOnly;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.enterprise.queue.AsyncBufferedAppender;

import static com.anz.markets.prophet.util.ThreadUtils.sleep;

public class ChronicleQueuePersister implements ProphetPersister {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleQueuePersister.class);
    private static final int LOG_EVERY = 10_000;
    private static final long WAIT_FOR_OTHER_CORE_TO_WRITE_MS = 1L;
    private static final long DUMMY_RING_BUFFER_INDEX = -1;

    private final SingleChronicleQueue chronicleQueue;
    private final PersisterConfig config;
    private final String queuePath;
    private ExcerptAppender appender;

    private boolean active;
    private long lastEventIdWritten = -1;
    private long skippedDueToInactive = 0;
    private long skippedDueToOldEventIdCount = 0;

    private volatile Thread lastThread;
    private volatile boolean closing = false, writeInProgress = false;

    public ChronicleQueuePersister(final String queuePath, final PersisterConfig persisterConfig) {
        this.queuePath = queuePath;
        this.chronicleQueue = ChronicleQueueFactory.createQueue(queuePath, false, persisterConfig.ringBuffer(), persisterConfig.eventLoop());
        this.config = persisterConfig;
        this.active = config.active();
        setActivationStatus();
    }

    @Override
    public void write(final MessageType messageType, final ProphetMarshallable entity)  {
        if (chronicleQueue.isClosed()) {
            LOGGER.error("Queue closed! Message will NOT be written to the queue. [chronicleQueue={}, messageType={}, entity={}]", chronicleQueue.fileAbsolutePath(), messageType, entity);
            return;
        }

        if (config.messageTypePredicate().test(messageType)) {
            final Context context = Context.context();
            final Header header = context.header();

            if (header.getEventId() <= lastEventIdWritten) {
                if ((skippedDueToOldEventIdCount++ % LOG_EVERY) == 0) {
                    LOGGER.info("Under eventId {}", skippedDueToOldEventIdCount);
                }
                return;
            }

            if (!active) {
                if ((skippedDueToInactive++ % LOG_EVERY) == 0) {
                    LOGGER.info("Inactive {}", skippedDueToInactive);
                }
                return;
            }

            // If writer thread switches (i.e. in StarfishIn), acquire appender first before writing.
            final Thread currentThread = Thread.currentThread();
            if (currentThread != lastThread) {
                // todo: not sure if this optimisation saves us anything
                lastThread = currentThread;
                // todo: Check if this is jittery, especially in StarfishIn, where the writing thread switches a lot
                appender = chronicleQueue.acquireAppender();
            }

            if (LOGGER.isTraceEnabled()) {
                LOGGER.trace("Writing messageType {} eventId {}", messageType, header.getEventId());
            }

            if (closing) { return; }

            writeInProgress = true;
            DocumentContext dc = null;
            try {
                dc = appender.writingDocument();
                config.beforeWrite().onEvent(context, messageType);
                final ProphetBytes wrappedAppender = ChronicleQueueWrappers.wrapWriter(dc);
                wrappedAppender.writeByte(messageType.getValue());
                if (entity instanceof PreservesMessageVersion) {
                    header.writeMarshallablePreserveMessageVersion(wrappedAppender, (PreservesMessageVersion) entity);
                } else {
                    header.writeMarshallable(wrappedAppender);
                }
                entity.writeMarshallable(wrappedAppender);
                config.afterWrite().onEvent(context, messageType);

            } catch (Throwable t) {
                // As recommended by the doco @ https://github.com/OpenHFT/Chronicle-Queue/blob/master/README.adoc#exceptions-thrown-with-a-writingdocument
                if (dc != null) { dc.rollbackOnClose(); }
                Jvm.rethrow(t);
            } finally {
                if (dc != null) { dc.close(); }
                writeInProgress = false;
            }
        }
    }

    @Override
    public void close() {
        closing = true;
        LOGGER.warn("Closing chronicle '{}' config '{}'", chronicleQueue.fileAbsolutePath(), config);
        int maxIterations = 10;
        while (writeInProgress && maxIterations-- > 0) {
            ThreadUtils.sleep(500L);
            LOGGER.info("Waiting to finish write in progress.");
        }
        chronicleQueue.close();
        LOGGER.warn("Closed");
    }

    @Override
    public void processActivationMessage(final Activate activate) {
        if (config.activationAware().yes()) {
            boolean activeBefore = this.active;
            this.active = activate.getStatus().isActive();
            LOGGER.info("activate before {} now {}", activeBefore, activate.getStatus());
            if (this.active != activeBefore) {
                try {
                    setActivationStatus();
                } catch (Exception e) {
                    throw new FatalError(e);
                }
            }
        } else {
            LOGGER.warn("Ignoring activation message {}", activate);
        }
    }

    @NotGcFriendly("generates a single piece of garbage but is called very infrequently")
    private void setActivationStatus() {
        if (active) {
            // this makes use of a non ring-buffered queue - at the time of writing, the RB does not support the full API
            final SingleChronicleQueue chronicleQueueNoRB = ChronicleQueueFactory.createQueue(queuePath, false, RingBuffer.NO_RING);
            LOGGER.info("Opening chronicle {} {}", chronicleQueueNoRB.fileAbsolutePath(), config);
            ExcerptTailer tailer = chronicleQueueNoRB.createTailer().toEnd();
            final long lastIndex = tailer.index();
            LOGGER.info("Reactivating persister to chronicle {} lastIndex {}", chronicleQueueNoRB.fileAbsolutePath(), Long.toHexString(lastIndex));
            // lastIndex == 0 if queue is empty
            if (config.append().enabled() && lastIndex > 0) {
                // make sure that RB drainer is running
                appender = chronicleQueue.acquireAppender();

                final long sequence = chronicleQueueNoRB.rollCycle().toSequenceNumber(lastIndex);
                if (sequence == -1) {
                    LOGGER.warn("Troubleshoot: sequence is -1, will. Tailer is {}", tailer);
                }
                final Header activationHeader = new Header();
                final long eventId = Context.context().header().getEventId();
                MessageType messageType = null;
                // we have gone to the end of the queue, which puts us just past the last item, so now set
                // tailer direction BACKWARD so that the next read will read the last item in the queue
                tailer.direction(TailerDirection.BACKWARD);
                try (final DocumentContext dc = tailer.readingDocument()) {
                    // I saw this !present once, not sure why
                    if (dc.isPresent()) {
                        final ProphetBytes wrappedExcerpt = ChronicleQueueWrappers.wrapReader(dc);
                        messageType = ChronicleObjectReader.readHeader(wrappedExcerpt, activationHeader);
                    } else {
                        LOGGER.warn("Troubleshoot: dc was no present lastIndex {} tailer {}", Long.toHexString(lastIndex), tailer);
                    }
                }

                tailer.direction(TailerDirection.FORWARD);
                int waitCount = 0;
                // make sure that the chronicle.out is up to the eventId we were activated by
                LOGGER.info("Looking for eventId {}", eventId);
                while (activationHeader.getEventId() < eventId) {
                    try (final DocumentContext dc = tailer.readingDocument()) {
                        if (dc.isPresent()) {
                            final ProphetBytes wrappedExcerpt = ChronicleQueueWrappers.wrapReader(dc);
                            messageType = ChronicleObjectReader.readHeader(wrappedExcerpt, activationHeader);
                        } else {
                            sleep(WAIT_FOR_OTHER_CORE_TO_WRITE_MS);
                        }
                        if ((waitCount++ % LOG_EVERY) == 0) {
                            LOGGER.info("Waiting to catchup for activate {}", waitCount);
                        }
                    }
                }
                // how to detect the other core has actually closed its chronicle? For now, just wait
                sleep(SystemProperties.ACTIVATE_PAUSE_MS);
                lastEventIdWritten = activationHeader.getEventId();
                LOGGER.warn("Activated: last messageType {} lastWrittenIndex {} lastEventIdWritten {}",
                        messageType, Long.toHexString(tailer.index()), lastEventIdWritten);
            } else {
                LOGGER.warn("Activated: empty output chronicle or !append");
            }
        } else {
            if (this.appender == null) {
                LOGGER.warn("Deactivated");
            } else {
                LOGGER.warn("Deactivated: lastWrittenIndex {} lastEventIdWritten {}", Long.toHexString(lastIndexAppended()), Context.context().header().getEventId());
            }
        }
    }

    private long lastIndexAppended() {
        if (appender instanceof AsyncBufferedAppender) {
            return ChronicleQueuePersister.DUMMY_RING_BUFFER_INDEX;
        }
        try {
            return appender.lastIndexAppended();
        } catch (IllegalStateException t) {
            // e.g. java.lang.IllegalStateException: nothing has been appended, so there is no last index
            LOGGER.debug("lastIndexAppended", t);
            return ChronicleQueuePersister.DUMMY_RING_BUFFER_INDEX;
        }
    }

    @Override
    public long firstIndex() {
        return chronicleQueue.firstIndex();
    }

    @Override
    public long getLastWrittenIndex() {
        return lastIndexAppended();
    }

    @TestOnly
    @Override
    public String toString() {
        return "ChronicleQueuePersister{" +
                "config=" + config +
                ", active=" + active +
                ", lastEventIdWritten=" + lastEventIdWritten +
                '}';
    }
}
