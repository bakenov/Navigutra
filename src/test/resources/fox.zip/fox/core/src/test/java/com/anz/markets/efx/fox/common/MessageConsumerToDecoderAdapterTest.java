package com.anz.markets.efx.fox.common;

import java.nio.ByteBuffer;

import org.agrona.DirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.common.MessageConsumerToDecoderAdapter;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MessageConsumerToDecoderAdapterTest {
    @Mock
    private MessageDecoder<SbeMessage> messageDecoder;
    private ByteBuffer byteBuffer;
    private DirectBuffer directBuffer;
    @Captor
    private ArgumentCaptor<SbeMessage> sbeMessageArgumentCaptor;

    private MessageConsumerToDecoderAdapter messageConsumerToDecoderAdapter;

    @BeforeEach
    void setUp() {
        byteBuffer = ByteBuffer.allocate(100);
        directBuffer = new UnsafeBuffer(byteBuffer);
        messageConsumerToDecoderAdapter = new MessageConsumerToDecoderAdapter(messageDecoder);
    }

    @Test
    void accept() {
        //when
        messageConsumerToDecoderAdapter.accept(directBuffer, 50, 50);

        //then
        verify(messageDecoder).decode(sbeMessageArgumentCaptor.capture());
        assertThat(sbeMessageArgumentCaptor.getValue().buffer().byteBuffer()).isEqualTo(byteBuffer);
        assertThat(sbeMessageArgumentCaptor.getValue().buffer().capacity()).isEqualTo(50);
        assertThat(sbeMessageArgumentCaptor.getValue().messageLength()).isEqualTo(50);
    }
}