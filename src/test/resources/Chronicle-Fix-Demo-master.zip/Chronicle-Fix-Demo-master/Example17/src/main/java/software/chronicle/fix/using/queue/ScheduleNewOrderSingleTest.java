package software.chronicle.fix.using.queue;

import net.openhft.chronicle.core.Jvm;
import net.openhft.chronicle.core.io.Closeable;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.core.onoes.Slf4jExceptionHandler;
import net.openhft.chronicle.core.pool.ClassAliasPool;
import net.openhft.chronicle.core.time.SetTimeProvider;
import net.openhft.chronicle.network.AlwaysStartOnPrimaryConnectionStrategy;
import net.openhft.chronicle.network.TCPRegistry;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import software.chronicle.fix.business.logic.BusinessLogicImpl;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.FixInstance;
import software.chronicle.fix.staticcode.LoggingMode;
import software.chronicle.fix.staticcode.msgseq.VanillaMsgSequenceHandle;
import software.chronicle.generated.code.generators.MessageGenerator;
import software.chronicle.generated.code.parsers.MessageParser;

import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static software.chronicle.fix.cfg.ConnectionType.initiator;

public class ScheduleNewOrderSingleTest {
    static {
        ClassAliasPool.CLASS_ALIASES.addAlias(ClientMessageNotifier.class,
                ServerMessageNotifier.class,
                FixEngineCfg.class,
                MessageParser.class,
                LoggingMode.class,
                MessageGenerator.class,
                VanillaMsgSequenceHandle.class,
                AlwaysStartOnPrimaryConnectionStrategy.class,
                TimeUnit.class);
        Jvm.setExceptionHandlers(Slf4jExceptionHandler.FATAL, Slf4jExceptionHandler.WARN, null);
    }

    public static void main( String[] args ) throws Exception {
        String version = System.getProperty("java.version");
        if( !version.startsWith("1.8.") )
        {
            System.out.println( "This example requires Java 8" );
            System.exit(1);
        }

        new ScheduleNewOrderSingleTest().sendTestExecutionReportTest();
    }

    public void sendTestExecutionReportTest() throws Exception {

        IOTools.deleteDirWithFiles("fix-to-business-logic", 10);
        IOTools.deleteDirWithFiles("business-logic-to-fix", 10);

        final FixEngineCfg fixEngineCfg = Marshallable.fromFile("fix-config.yaml");

        SetTimeProvider timeProvider = new SetTimeProvider(1451902315496000000L); //controlled time
        fixEngineCfg.fixSessionCfgs().forEach(cfg -> cfg.timeProvider(timeProvider));

        final FixSessionCfg initiatorFixConfig = fixEngineCfg.fixSessionCfgs().stream().filter(cfg -> cfg.connectionType() == initiator).findFirst().orElseThrow(IllegalStateException::new);

        final software.chronicle.fix.using.queue.ClientMessageNotifier cmn = initiatorFixConfig.messageNotifier();
        cmn.triggerTimeNanos(1451902315496456789L); //time to be advanced in ClientMessageNotifier.onLogon()

        TCPRegistry.reset();
        TCPRegistry.createServerSocketChannelFor("host.port");

        // this could be run in its own process
        Executors.newSingleThreadExecutor().submit(BusinessLogicImpl::new);

        try (final Closeable ignored = FixInstance.fixEngineMain(1, fixEngineCfg)) {

            EventGroup clientEventGroup = new EventGroup(true, Pauser.balanced(), true);
            clientEventGroup.addHandler(cmn);
            try (final Closeable ignored2 = fixEngineCfg.createInstance(2, clientEventGroup)) {

                String executionReport = cmn.queue().poll(500, TimeUnit.SECONDS);

                assert executionReport.equals("!software.chronicle.generated.code.messages.datamodel.DefaultExecutionReport {\n" +
                        "  senderCompID: SERVER,\n" +
                        "  targetCompID: CLIENT,\n" +
                        "  msgSeqNum: 2,\n" +
                        "  sendingTime: 1451902315496,\n" +
                        "  clOrdID: CL_ORD_ID,\n" +
                        "  ordStatus: \"0\",\n" +
                        "  side: \"1\",\n" +
                        "  avgPx: 12.0,\n" +
                        "  transactTime: 1451902315496\n" +
                        "}\n");

                System.out.println();
            }

        }

        System.exit(0);
    }
}

