package com.anz.markets.efx.fox.firewall.metric;

import java.util.function.ToLongFunction;

import com.anz.markets.efx.fox.codec.api.FirewallConfigDecoder;

public class LocalOrSharedTimePeriodMetricKeyFactory implements ToLongFunction<FirewallConfigDecoder> {
    @Override
    public long applyAsLong(final FirewallConfigDecoder firewallConfig) {
        final FirewallConfigDecoder.Body body = firewallConfig.body();

        final boolean local = body.local();
        if (local) {
            return -body.ruleId();
        } else {
            return MetricPeriod.toMillis(firewallConfig);
        }
    }
}
