package com.anz.markets.prophet.chime;


import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.time.EndOfWeekChime;
import com.anz.markets.prophet.domain.time.HourChime;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;

import java.util.function.Consumer;

@ManagedResource
public class ChimeConsumerMBean {

    private int hourOfDayInUTC;
    private TradingTimeZone tradingTimeZone;
    private DateTime endOfWeekLastTriggeredAt;

    @ManagedAttribute
    public TradingTimeZone getCurrentTradingTimeZone() {
        return tradingTimeZone;
    }

    @ManagedAttribute
    public int getHourOfDayInUTC() {
        return hourOfDayInUTC;
    }

    @ManagedAttribute
    public DateTime getEndOfWeekLastTriggeredAt() {
        return endOfWeekLastTriggeredAt;
    }

    public Consumer<TradingTimeZoneChime> consumerOfTradingTimeZoneChime() {
        return tradingTimeZoneChime -> tradingTimeZone = tradingTimeZoneChime.getTradingTimeZone();
    }

    public Consumer<HourChime> consumerOfHourChime() {
        return hourChime -> hourOfDayInUTC = hourChime.getHourOfDayUTC();
    }

    public Consumer<EndOfWeekChime> consumerOfEndOfWeekChime() {
        return hourChime -> endOfWeekLastTriggeredAt = new DateTime(DateTimeZone.UTC);
    }

}
