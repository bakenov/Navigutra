package com.anz.markets.prophet.atest.pricing._1a_pre_order_book_cleansing;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.LiquidityFilterConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.PriceAndQtyImpl;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataFilterType;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.Arrays;


import static com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl.getLiquidityFilterConfigs;
import static com.anz.markets.prophet.domain.marketdata.impl.FilterDecision.PASS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LiquidityFilterTest extends BaseAcceptanceSpecification {
    /**
     *  AXPROPHET-642 initial requirement
     *  AXPROPHET-1031:
     *  Liquidity filter to be moved out of marketdata filtering into a pre-orderbook filtering phase
     *  Liquidity filter to NOT apply to WSP_R book
     *  (i.e reference agg book has same set of filters applied as primary agg book APART from liquidity filter)
     */

    @Test
    public void bidSideBeyondMaxDistance() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 500_000),
                            new PriceAndQtyImpl(0.75025, 2_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 4_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75024));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
        }
    }

    @Test
    public void offerSideBeyondMaxDistance() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 2_000_000),
                            new PriceAndQtyImpl(0.75029, 2_000_000),
                            new PriceAndQtyImpl(0.75028, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 1_999_999),
                            new PriceAndQtyImpl(0.75056, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            // Also, this filter can NEVER "FAIL"
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75056));
        }
    }

    @Test
    public void bothSidesEqualsMaxDistance() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 500_000),
                            new PriceAndQtyImpl(0.75026, 2_000_000),
                            new PriceAndQtyImpl(0.75025, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 4_000_000),
                            new PriceAndQtyImpl(0.75055, 3_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
        }
    }

    @Test
    public void oneSideNotEnoughLiquidity() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 2_000_000),
                            new PriceAndQtyImpl(0.75029, 2_000_000),
                            new PriceAndQtyImpl(0.75028, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75055, 1_000_000),
                            new PriceAndQtyImpl(0.75056, 999_999)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75056));
        }
    }

    @Test
    public void handleMultipleStackWithSamePrice() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 2_000_000),
                            new PriceAndQtyImpl(0.75029, 2_000_000),
                            new PriceAndQtyImpl(0.75028, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000),
                            new PriceAndQtyImpl(0.75056, 1_000_001),
                            new PriceAndQtyImpl(0.75056, 1_999_999)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75056));
        }
    }

    @Test
    @DisplayName("Verify correct conversion of JPY pip to points of config when using ANY in instrument config")
    public void verifyUseOfAnyInstrumentInConfig() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(Arrays.asList(
                            new LiquidityFilterConfigImpl(TradingTimeZone.GLOBAL, Region.ANY, Market.ANY, Instrument.ANY, 3_000_000, 0.5)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.RFX, Instrument.USDJPY,
                    Arrays.asList(new PriceAndQtyImpl(88.030, 2_000_000),
                            new PriceAndQtyImpl(88.029, 500_000),
                            new PriceAndQtyImpl(88.024, 600_000)),
                    Arrays.asList(new PriceAndQtyImpl(88.050, 1_000_000),
                            new PriceAndQtyImpl(88.055, 2_000_000),
                            new PriceAndQtyImpl(88.056, 2_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(88.024));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(88.050));
        }
    }

    @Test
    public void liquidityFilterDisabled() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(10_000_000, 1.5))
                    .setFilterEnabledConfigs(union(
                            tdd.disableFilter(MarketDataFilterType.MARKET_LIQUIDITY)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 2_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
        }
    }

    @Test
    public void liquidityFilterDisabledViaConfig() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(Arrays.asList(
                            new LiquidityFilterConfigImpl(TradingTimeZone.GLOBAL, Region.ANY, Market.ANY, Instrument.ANY, 3_000_000, 0.5),
                            new LiquidityFilterConfigImpl(TradingTimeZone.GLOBAL, Region.ANY, Market.CNX, Instrument.AUDUSD, 0.0, 0.0)
                    ))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 2_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 1_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_U)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.RFX, Instrument.USDCAD,
                    Arrays.asList(new PriceAndQtyImpl(1.37530, 2_000_000),
                            new PriceAndQtyImpl(1.37529, 2_000_000),
                            new PriceAndQtyImpl(1.37528, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(1.37550, 1_000_000),
                            new PriceAndQtyImpl(1.37555, 2_000_000),
                            new PriceAndQtyImpl(1.37556, 3_000_000)),
                    tdd.now()));
        }
        then:
        {
            // Note that only levels which pass filtering are written to chronicle (also excluded is filter mask for each level)
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.RFX)).getLast();
            assertThat(snapshot.getFilterOutcome(), is(PASS));
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(1.37530));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(1.37550));
        }
    }

    @Test
    // do not apply liquidityFilter to Reference Agg book
    public void doNotApplyFilterToWSP_R() {
        setup:
        {
            prophet.receive(tdd.configuration_pricing_base()
                    .setLiquidityFilterConfigs(getLiquidityFilterConfigs(3_000_000, 0.5))
            );
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffers(Market.CNX, Instrument.AUDUSD,
                    Arrays.asList(new PriceAndQtyImpl(0.75030, 500_000),
                            new PriceAndQtyImpl(0.75026, 2_000_000),
                            new PriceAndQtyImpl(0.75024, 4_000_000)),
                    Arrays.asList(new PriceAndQtyImpl(0.75050, 2_000_000),
                            new PriceAndQtyImpl(0.75056, 3_000_000)),
                    tdd.now()));
        }
        then:
        {
            final FilteredMarketDataSnapshot snapshot = prophet.expect(FilteredMarketDataSnapshot.class, exactly(1), isMarket(Market.WSP_R)).getLast();
            assertThat(snapshot.getTopOfBookBid().getPrice(), is(0.75030));
            assertThat(snapshot.getTopOfBookOffer().getPrice(), is(0.75050));
        }
    }
}