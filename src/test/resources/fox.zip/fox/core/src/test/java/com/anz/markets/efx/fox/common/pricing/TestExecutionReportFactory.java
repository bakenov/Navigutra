package com.anz.markets.efx.fox.common.pricing;

import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingCodecUtil;

public class TestExecutionReportFactory {

    public static class ExecutionReportStub {
        public ExecutionReportStub(final long timeNanos, final String region, final String targetStrategy,
                         final String portfolio, final String username, final SecurityType securityType,
                         final Tenor tenor, final String symbol, final double orderQty,
                         final String markets, final ExecType execType, final double leavesQty) {
            this.timeNanos = timeNanos;
            this.region = region;
            this.targetStrategy = targetStrategy;
            this.portfolio = portfolio;
            this.username = username;
            this.securityType = securityType;
            this.tenor = tenor;
            this.symbol = symbol;
            this.orderQty = orderQty;
            this.markets = markets;
            this.execType = execType;
            this.leavesQty = leavesQty;
        }

        public ExecutionReportStub() {
        }

        public long timeNanos;
        public String region;
        public String targetStrategy;
        public String portfolio;
        public String username;
        public SecurityType securityType;
        public Tenor tenor;
        public String symbol;
        public double orderQty;
        public String markets;
        public ExecType execType;
        public double leavesQty;
    }

    private final SbeTradingCodecUtil.Codec tradingCodec = SbeTradingCodecUtil.create();

    public ExecutionReportDecoder createExecutionReport(final String region, final String targetStrategy,
                                                        final String portfolio, final String username, final SecurityType securityType,
                                                        final Tenor tenor, final String symbol, final double orderQty, final String markets,
                                                        final ExecType execType, final double leavesQty) {

        tradingCodec.encoderSupplier().executionReport().messageStart(2, 20)
                .senderCompId().encode("GB:firewallTestMessage")
                .messageId(18)
                .clOrdId().encode("TestClientId")
                .symbol().encode(symbol)
                .marketId().encode(Venue.FOX.name())
                .securityType(securityType)
                .settlType(tenor)
                .orderQty(orderQty)
                .ordType(OrderType.MARKET)
                .targetStrategyName().encode(targetStrategy)
                .price(0)
                .execType(execType)
                .leavesQty(leavesQty)
                .side(Side.BUY)
                .currency().encode("EUR")
                .timeInForce(TimeInForce.GTC)
                .transactTime(1497338461000000L) //20170613-07:21:01 in nanos
                .partiesStart(4)
                .next()
                .partyRole(PartyRole.CLIENT_ID)
                .partyId().encode("14617523")
                .next()
                .partyRole(PartyRole.PORTFOLIO)
                .partyId().encode(portfolio)
                .next()
                .partyRole(PartyRole.USER_NAME)
                .partyId().encode(username)
                .next()
                .partyRole(PartyRole.TARGET_REGION)
                .partyId().encode(region)
                .partiesComplete()
                .strategyParametersStart(4)
                .next()
                .strategyParameterName().encode("StrategyName")
                .strategyParameterValue().encode("TWAP")
                .next()
                .strategyParameterName().encode("LimitPrice")
                .strategyParameterValue().encode("1.3917")
                .next()
                .strategyParameterName().encode("EndTime")
                .strategyParameterValue().encode("20170613-20:00:00.000")
                .next()
                .strategyParameterName().encode("Markets")
                .strategyParameterValue().encode(markets)
                .strategyParametersComplete()
                .regulatoryTradeIdsStart(2)
                .next()
                .id().encode("123123")
                .source().encode("blah")
                .next()
                .id().encode("535635")
                .source().encode("blah2")
                .regulatoryTradeIdsComplete()
                .hopsStart(1)
                .next()
                .hopCompId().encode("GB:daxled")
                .hopMessageId(45634)
                .hopReceivingTime(0)
                .hopSendingTime(1497338461000000L) //20170613-07:21:01 in nanos
                .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encodeEmpty()
                .messageComplete();
        return tradingCodec.decoderSupplier().executionReport();
    }

    public ExecutionReportDecoder createExecutionReport(final ExecutionReportStub executionReportStub) {
        return createExecutionReport(executionReportStub.region, executionReportStub.targetStrategy,
                executionReportStub.portfolio, executionReportStub.username, executionReportStub.securityType,
                executionReportStub.tenor, executionReportStub.symbol, executionReportStub.orderQty, executionReportStub.markets,
                executionReportStub.execType, executionReportStub.leavesQty);
    }
}
