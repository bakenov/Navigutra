package com.anz.markets.efx.fox.processor.state;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.trading.codec.api.TimeInForce;

public interface TimeInForceTimerConfig {
    long millis(TimerGroup timerGroup, TimeInForce timeInForce);
}
