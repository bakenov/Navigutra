package com.anz.markets.prophet.atest.pricing._5_triangulation;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.DisplayName;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

public class TriangulationTest_DirectDirect_NOKSEK extends BaseAcceptanceSpecification {

    @Test
    @Requirement(value = {Ref.PRICING_4_6, Ref.PRICING_4_6_3})
    @DisplayName("Triangulation of cross pair from DIRECT-DIRECT driver pairs: NOKSEK via EUR")
    public void given_indirect_direct_driver_pairs_triangulate_cross_pair() throws Exception {
        setup:
        {
            // Risk Skew not applied since 0 equiv position
            // NOP Skew not applied since NOP is 0
            // Overall Skew is 0

            // No News Events
            // Since no further price updates, Volatility is 0
            // Since no further price updates, Market Gap Factor not applicable
            // Since Equiv Pos is 0, Risk Adjusted Factor Not Applicable
            // i.e MODEL SPREAD == BASE SPREAD
        }
        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base()
                    .setClientSpreadConfigs(Lists.newArrayList(
                            // spread config for driver pairs
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURNOK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100),

                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 40),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 50),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 60),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 80),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.EURSEK, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 100)
                    ))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.ECONNEWS_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.VOLATILITY_PRICE_WIDENING_ENABLED, false))
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.MARKETGAP_PRICE_WIDENING_ENABLED, false));

            prophet.receive(configurationDataDefault);
        }

        when:
        {
            // receive driver pair a
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURNOK, 9.264, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURNOK)).getFirst();
            assertThat(clientPrice.getBids().size(), is(5));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 9.26200, 9.26600));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 9.26125, 9.26675));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 9.26025, 9.26775));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 9.25900, 9.26900));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 9.25700, 9.271000));
        }

        when:
        {
            // receive driver pair b
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.EURSEK, 9.483, 0.00001));
        }

        then:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.EURSEK)).getFirst();
            assertThat(clientPrice.getBids().size(), is(5));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 9.481000, 9.485000));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 9.480250, 9.485750));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 9.479250, 9.486750));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 9.478000, 9.488000));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 9.476000, 9.490000));
        }

        and:
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, isClientPriceInstrument(Instrument.NOKSEK)).getFirst();
            assertThat(clientPrice.getBids().size(), is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 1.02320310814, 1.0240768732));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 1.02320310814, 1.0240768732));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 1.02320310814, 1.0240768732));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 1.02317907008, 1.0241010671));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 1.02303936116, 1.0242407882));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 1.02303936116, 1.0242407882));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 1.02299132686, 1.0242892179));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 1.02282107308, 1.0244593828));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 1.02272109412, 1.0245603708));
        }
    }

}
