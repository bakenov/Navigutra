package com.anz.markets.prophet.marketdata.aggbook;


import com.anz.markets.prophet.ByteWatcherTodo;
import com.anz.markets.prophet.NoOpConsumer;
import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.marketdata.TestConfigurationDataFactory;
import com.anz.markets.prophet.marketdata.filter.SnapshotGenerator;
import com.anz.markets.prophet.status.Context;
import org.junit.Test;

import java.io.IOException;
import java.util.function.Consumer;

public class AggregatedBookManagerBWTest {

    private static final int REPS = 100_000;
    private static final long THRESHOLD = ByteWatcherTodo.THRESHOLD_AggregatedBookManagerBWTest;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    private final AggregatedBookManager aggregatedBookCalculator;
    private final Consumer<FilteredMarketDataSnapshot> aggregatedBookMarketDataConsumer;

    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_CNX;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_RFX;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_EBS;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_MSI;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_CITI;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_GS;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_HSP;
    private final FilteredMarketDataSnapshotImpl snapshotAUDUSD_FASTMATCH;

    public AggregatedBookManagerBWTest() throws IOException {

        Context.context().region(Region.GB);
        Context.context().tradingTimeZone(TradingTimeZone.LDN);

        IndexedConfigurationData indexedConfigurationData = TestConfigurationDataFactory.configurationDataForAggBookFiltering();

        aggregatedBookCalculator = new AggregatedBookManager(new NoOpConsumer<>(), Market.WSP_U);
        aggregatedBookCalculator.consumerOfIndexedConfigurationData().accept(indexedConfigurationData);
        snapshotAUDUSD_CNX = new SnapshotGenerator(Market.CNX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_RFX = new SnapshotGenerator(Market.RFX, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_EBS = new SnapshotGenerator(Market.EBS, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_MSI = new SnapshotGenerator(Market.MSI, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_CITI = new SnapshotGenerator(Market.CITI, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_GS = new SnapshotGenerator(Market.GS, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_HSP = new SnapshotGenerator(Market.HSP, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        snapshotAUDUSD_FASTMATCH = new SnapshotGenerator(Market.FASTMATCH, Instrument.AUDUSD).withBid(1.1, 1_000_000.0).withOffer(1.12, 1_000_000.0).buildFilteredMarketDataSnapshot();
        aggregatedBookMarketDataConsumer = aggregatedBookCalculator.consumerOfMarketData();
    }

    private void scenario_AggBookCalculationWithInstrument() {
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_CNX);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_RFX);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_EBS);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_MSI);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_CITI);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_GS);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_HSP);
        aggregatedBookMarketDataConsumer.accept(snapshotAUDUSD_FASTMATCH);
    }

    @Test
    public void testAggBookCalculationWithOnePriceChange() {
        helper.testAllocationNotExceeded(
                this::scenario_AggBookCalculationWithInstrument,
                REPS, REPS,
                THRESHOLD
        );
    }
}
