package com.anz.markets.efx.fox.processor.state.instrument;

import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Predicate;

import org.agrona.collections.Object2ObjectHashMap;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Venue;

public class DefaultInstrument implements Instrument {
    private final InstrumentKey instrumentKey;
    private int pipSizeDivisor;
    private boolean enabled;

    private final Map<Venue, VenueInstrument> venueInstruments = new Object2ObjectHashMap<>();
    private final Object2ObjectHashMap<String, Instrument> drivingInstruments = new Object2ObjectHashMap<>();
    private final DoubleUnaryOperator usdCalculator;

    private double consensusMidPrice = Double.NaN;

    public DefaultInstrument(final InstrumentKey instrumentKey, final int pipSizeDivisor, final boolean enabled) {
        this.instrumentKey = Objects.requireNonNull(instrumentKey);
        this.pipSizeDivisor = pipSizeDivisor;
        this.enabled = enabled;
        this.usdCalculator = new CachedUsdCalculator(new UsdCalculatorFactory(this));
    }

    @Override
    public InstrumentKey key() {
        return instrumentKey;
    }

    @Override
    public int pipSizeDivisor() {
        return pipSizeDivisor;
    }

    @Override
    public boolean enabled() {
        return enabled;
    }

    public DefaultInstrument pipSizeDivisor(final int pipSizeDivisor) {
        this.pipSizeDivisor = pipSizeDivisor;
        return this;
    }

    public DefaultInstrument enabled(final boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    @Override
    public void addVenueInstrument(final VenueInstrument venueInstrument) {
        venueInstruments.put(venueInstrument.venue().venueId(), venueInstrument);
    }

    @Override
    public void addDrivingInstrument(final Instrument instrument) {
        drivingInstruments.put(instrument.key().symbol(), instrument);
    }

    @Override
    public VenueInstrument venueInstrument(final Venue venueId) {
        return venueInstruments.get(venueId);
    }

    @Override
    public void forEach(final Predicate<VenueInstrument> filter, final Consumer<VenueInstrument> consumer) {
        for(VenueInstrument venueInstrument : venueInstruments.values()) {
            if (filter.test(venueInstrument)) {
                consumer.accept(venueInstrument);
            }
        }
    }

    @Override
    public void forEachDrivingInstrument(final Consumer<Instrument> consumer) {
        drivingInstruments.values().forEach(consumer);
    }

    @Override
    public Instrument drivingInstrument(final String symbol) {
        return drivingInstruments.get(symbol);
    }

    @Override
    public double consensusMidPrice() {
        return consensusMidPrice;
    }

    @Override
    public void consensusMidPrice(final double consensusMidPrice) {
        this.consensusMidPrice = consensusMidPrice;
    }

    @Override
    public double usdValue(final double nominalBaseAmount) {
        return usdCalculator.applyAsDouble(nominalBaseAmount);
    }

    @Override
    public String toString() {
        return "DefaultInstrument{" +
                "instrumentKey=" + instrumentKey +
                ", pipSizeDivisor=" + pipSizeDivisor +
                ", enabled=" + enabled +
                '}';
    }
}
