package com.anz.axle.lg.adapter.acceptance.utils;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.Side;

public class PriceListener {

    private final Queue<PricingMessage> pricingMessageQueue;

    public PriceListener(final Queue<PricingMessage> pricingMessageQueue) {
        this.pricingMessageQueue = Objects.requireNonNull(pricingMessageQueue);
    }

    public PriceEntry awaitAnyPrice(final Predicate<Object> matcher, final int timeout) {
        final PriceEntry priceEntry = new PriceEntry();
        final PricingMessage pricingMessage = awaitPriceMessage(matcher, timeout);

        pricingMessage.accept(pricingMessageVisitor(priceEntry, s -> true, i -> true));
        return priceEntry;
    }

    public PriceEntry awaitPrice(final Predicate<Object> matcher, final EntryType entryType) {
        return awaitPrice(matcher, entryType, 60);
    }

    public PriceEntry awaitPrice(final Predicate<Object> matcher) {
        return awaitPrice(matcher, null, 60);
    }

    public PriceEntry awaitPrice(final Predicate<Object> matcher, final EntryType entryType, final int timeout) {
        final PriceEntry priceEntry = new PriceEntry();
        final PricingMessage pricingMessage = awaitPriceMessage(matcher, timeout);

        pricingMessage.accept(pricingMessageVisitor(priceEntry, entryType));
        return priceEntry;
    }

    public PriceEntry awaitLastPrice(final Predicate<Object> matcher, final EntryType entryType, final int timeout) {
        final PriceEntry priceEntry = new PriceEntry();
        final List<PricingMessage> pricingMessages = awaitAllPriceMessage(matcher, timeout);

        pricingMessages.forEach(pricingMessage -> pricingMessage.accept(pricingMessageVisitor(priceEntry, entryType)));
        return priceEntry;
    }

    public PricingMessageVisitor.Exception pricingMessageVisitor(final PriceEntry priceEntry, final EntryType entryType) {
        final Predicate<IncrementalRefresh.Entry> incrementalRefreshEntryMatcher = incrementalRefreshEntryMatcher(entryType);
        final Predicate<SnapshotFullRefresh.Entry> snapshotFullRefreshEntryMatcher = snapshotFullRefreshEntryMatcher(entryType);

        return pricingMessageVisitor(priceEntry, snapshotFullRefreshEntryMatcher, incrementalRefreshEntryMatcher);
    }

    public PricingMessageVisitor.Exception pricingMessageVisitor(final PriceEntry priceEntry, final Predicate<SnapshotFullRefresh.Entry> snapshotFullRefreshEntryMatcher, final Predicate<IncrementalRefresh.Entry> incrementalRefreshEntryMatcher) {
        return new PricingMessageVisitor.Exception() {
            @Override
            public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                for (SnapshotFullRefresh.Entry entry : snapshotFullRefresh.entries) {
                    if (snapshotFullRefreshEntryMatcher.test(entry)) {
                        priceEntry.update(snapshotFullRefresh, entry);
                    }
                }
            }
            @Override
            public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                for (IncrementalRefresh.Entry entry : incrementalRefresh.entries) {
                    if (incrementalRefreshEntryMatcher.test(entry)) {
                        priceEntry.update(incrementalRefresh, entry);
                    }
                }
            }
        };
    }

    public PricingMessage awaitPriceMessage(final Predicate<Object> matcher, final int timeout) {
        return Asserter.of(pricingMessageQueue)
                .matching(matcher)
                .awaitMatchAndGetLast(timeout, TimeUnit.SECONDS);
    }

    public List<PricingMessage> awaitAllPriceMessage(final Predicate<Object> matcher, final int timeout) {
        return Asserter.of(pricingMessageQueue)
                .matching(matcher)
                .awaitMatchAndGetAll(timeout, TimeUnit.SECONDS);
    }

    public static class PriceEntry {
        public String msgType;
        public Side side;
        public EntryType entryType;
        public int quoteId;
        public double price;
        public double size;
        public InstrumentKey instrumentKey;
        public EnumSet<Flag> flags = EnumSet.noneOf(Flag.class);
        public LocalDate settlDate;
        public LocalDate maturityDate;

        public String currency() {
            return instrumentKey == null ? null : instrumentKey.symbol().substring(0,3);
        }

        private Side side(final EntryType mdEntryType) {
            switch (mdEntryType) {
                case BID: return Side.SELL;
                case OFFER: return Side.BUY;
                default: return null;
            }
        }

        public void update(final IncrementalRefresh incrementalRefresh, final IncrementalRefresh.Entry entry) {
            System.out.println("PriceMessage:" + incrementalRefresh);
            System.out.println("PriceMessageEntry:" + entry.toString());
            System.out.println("==============================================================");

            msgType = "Incremental";
            instrumentKey = InstrumentKey.of(incrementalRefresh.body.instrumentId);
            price = entry.mdEntryPx;
            size = entry.mdEntrySize;
            entryType = entry.mdEntryType;
            side = side(entry.mdEntryType);
            quoteId = entry.quoteEntryId;
            settlDate = incrementalRefresh.body.settlDate;
            maturityDate = incrementalRefresh.body.maturityDate;
        }

        public void update(final SnapshotFullRefresh snapshotFullRefresh, final SnapshotFullRefresh.Entry entry) {
            System.out.println("PriceMessage:" + snapshotFullRefresh);
            System.out.println("PriceMessageEntry:" + entry.toString());
            System.out.println("==============================================================");

            msgType = "Snapshot";
            instrumentKey = InstrumentKey.of(snapshotFullRefresh.body.instrumentId);
            price = entry.mdEntryPx;
            size = entry.mdEntrySize;
            entryType = entry.mdEntryType;
            side = side(entry.mdEntryType);
            quoteId = entry.quoteEntryId;
            settlDate = snapshotFullRefresh.body.settlDate;
            maturityDate = snapshotFullRefresh.body.maturityDate;
        }

        @Override
        public String toString() {
            return "PriceEntry{" +
                    "msgType=" + msgType +
                    ", side=" + side +
                    ", entryType=" + entryType +
                    ", quoteId=" + quoteId +
                    ", price=" + price +
                    ", size=" + size +
                    ", instrumentKey=" + instrumentKey +
                    ", flags=" + flags +
                    ", settlDate=" + settlDate +
                    ", maturityDate=" + maturityDate +
                    "}";
        }
    }

    public Predicate<IncrementalRefresh.Entry> incrementalRefreshEntryMatcher(final EntryType entryType) {
         return entryType == null ? entry -> entry.mdEntryPx > 0.0 : entry -> entry.mdEntryPx > 0.0 && entry.mdEntryType == entryType;
    }

    public Predicate<SnapshotFullRefresh.Entry> snapshotFullRefreshEntryMatcher(final EntryType entryType) {
        return entryType == null ? entry -> entry.mdEntryPx > 0.0 : entry -> entry.mdEntryPx > 0.0 && entry.mdEntryType == entryType;
    }
}
