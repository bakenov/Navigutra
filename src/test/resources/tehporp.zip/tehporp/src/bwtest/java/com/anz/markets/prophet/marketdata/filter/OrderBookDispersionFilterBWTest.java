package com.anz.markets.prophet.marketdata.filter;


import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.StandardMarketSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.impl.AggregatedBook;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketsSnapshotImpl;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.util.ProphetMarshallableCopier;
import com.google.common.collect.Lists;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import static com.anz.markets.prophet.marketdata.TestConfigurationDataFactory.withDefaults;
import static com.anz.markets.prophet.marketdata.filter.OrderBookDispersionFilterTest.createPrimaryMarketsSnapshotTestData;

public class OrderBookDispersionFilterBWTest {

    private static final int REPS = 100_000;
    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private static final int THRESHOLD = 500;

    static {
        Context.context().region(Region.GB);
    }

    private final OrderBookDispersionFilter orderBookDispersionFilter = new OrderBookDispersionFilter();
    private final IndexedConfigurationData indexedConfigurationData = new IndexedConfigurationData(getStandardMarketsImplWithStandardSpread());
    private AggregatedBook aggBook = OrderBookDispersionFilterTest.createAggBook();
    private MarketsSnapshotImpl primaryMarketsSnapshot;

    private final MarketDataSnapshotImpl cnxSnapshot = OrderBookDispersionFilterTest.createCnxSnapshotWithBid1_1_Offer1_01();
    private final FilteredMarketDataSnapshotImpl cnxFilteredSnapshot = FilteredMarketDataSnapshotImpl.forMarket();


    public OrderBookDispersionFilterBWTest() throws IOException {

        orderBookDispersionFilter.accept(indexedConfigurationData);

        primaryMarketsSnapshot = createPrimaryMarketsSnapshotTestData(0.0001);
        primaryMarketsSnapshot.updateWith(cnxSnapshot);

        new ProphetMarshallableCopier().copyIntoFilteredMarketData(cnxSnapshot, cnxFilteredSnapshot);

        warmup();
    }

    public void scenarioPerformFiltering() {
        for (int i = 0; i < REPS; i++) {
            orderBookDispersionFilter.perform(aggBook);
        }
    }

    public void warmup() {
        scenarioPerformFiltering();
    }

    @Test
    public void test_AllocationNotExceeded_Test() {
        helper.testAllocationNotExceeded(
                this::scenarioPerformFiltering,
                THRESHOLD // no allocation!
        );
    }

    //    @Test
    //    public void test__AllocationWatcher() {
    //        AllocationRecorder.addSampler(new Sampler() {
    //            public void sampleAllocation(int count,
    //                                         String desc,
    //                                         Object newObj,
    //                                         long size) {
    //                System.out.println("I just allocated the object " + newObj + " of type " + desc + " whose size is " + size);
    //                if (count != -1) { System.out.println("It's an array of size " + count); }
    //            }
    //        });
    //        filteredAggBookParams.setAggBookForInstrument(aggBook);
    //        filteredAggBookParams.setIncomingMarketData(cnxSnapshot);
    //        filteredAggBookParams.setMarketsSnapshot(primaryMarketsSnapshot);
    //        orderBookDispersionFilter.perform(filteredAggBookParams);
    //    }


    public static ConfigurationDataDefault getStandardMarketsImplWithStandardSpread() throws IOException {

        ConfigurationDataDefault configurationDataDefault = withDefaults(new ConfigurationDataDefault())
                .setMarketConfigs(Collections.EMPTY_LIST)
                .setStandardMarketSpreadConfigs(Lists.newArrayList(
                        new StandardMarketSpreadConfigImpl(Instrument.AUDUSD, 1.25e-4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
                ))
                .setMarketConfigs(
                        Arrays.asList(
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.AUDUSD),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURJPY),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURNOK),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURSEK),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.EURUSD),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.NZDUSD),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDCAD),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDCHF),
                                new MarketConfigImpl(Market.CNX).setRegion(Region.GB).setInstrument(Instrument.USDJPY)
                        )
                );

        for (MarketConfig mc : configurationDataDefault.getMarketConfigs()) {
            configurationDataDefault.addAggBook(Market.WSP_U, mc.getInstrument(), TradingTimeZone.GLOBAL, Region.GB, Market.CNX);
        }

        return configurationDataDefault;
    }
}
