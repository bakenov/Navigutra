package com.anz.axle.lg.adapter.barx;

import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.lg.adapter.config.CommonConfig;
import com.anz.axle.lg.adapter.config.MessagingConfig;
import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.messaging.transport.api.Connection;

@Configuration
@Import({
        CommonConfig.class,
        FixConfig.class,
        PricingConfig.class,
        TradingConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingSubscriptionConfig.class
})
public class ServerConfig {

    private final Service fixEngine;
    private final Connection connection;
    private final Service mainEventLoop;

    public ServerConfig(final Service fixEngine,
                        final Connection connection,
                        final Service mainEventLoop) {
        this.fixEngine = Objects.requireNonNull(fixEngine);
        this.connection = Objects.requireNonNull(connection);
        this.mainEventLoop = Objects.requireNonNull(mainEventLoop);
    }

    @PostConstruct
    public void init() {
        mainEventLoop.start();
        fixEngine.start();
    }

    @PreDestroy
    public void destroy() {
        fixEngine.stop();
        mainEventLoop.stop();
        connection.close();
    }
}
