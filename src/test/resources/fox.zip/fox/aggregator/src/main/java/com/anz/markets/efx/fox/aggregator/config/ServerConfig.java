package com.anz.markets.efx.fox.aggregator.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.Objects;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.anz.axle.servicelifecycle.Service;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;

@Configuration
@Import({
        CommonConfig.class,
        MetricsConfig.class,
        PropertiesConfig.class,
        MessagingConfig.class,
        PricingConfig.class,
        ReceiverConfig.class,
        PricingSubscriptionConfig.class,
        PricingPublicationConfig.class
})
public class ServerConfig {
    private final PricingClient<MarketDataBook> pricingClient;
    private final Service receiverEventLoopService;


    public ServerConfig(final PricingClient<MarketDataBook> pricingClient,
                        final Service receiverEventLoopService) {
        this.pricingClient = Objects.requireNonNull(pricingClient);
        this.receiverEventLoopService = Objects.requireNonNull(receiverEventLoopService);
    }

    @PostConstruct
    public void start() {
        pricingClient.service().start();
        receiverEventLoopService.start();
    }

    @PreDestroy
    public void stop() {
        pricingClient.service().stop();
        receiverEventLoopService.stop();
    }
}
