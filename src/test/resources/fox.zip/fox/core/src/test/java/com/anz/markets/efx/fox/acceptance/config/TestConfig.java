package com.anz.markets.efx.fox.acceptance.config;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.LongSupplier;

import org.agrona.concurrent.UnsafeBuffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.tools4j.eventsourcing.api.IndexedPollerFactory;
import org.tools4j.eventsourcing.api.MessageConsumer;
import org.tools4j.eventsourcing.api.Poller;
import org.tools4j.eventsourcing.common.PayloadBufferPoller;
import org.tools4j.eventsourcing.common.PollingProcessStep;
import org.tools4j.eventsourcing.mmap.MmapBuilder;
import org.tools4j.mmap.region.api.RegionFactory;
import org.tools4j.mmap.region.api.RegionRingFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.eventloop.EventLoopService;
import com.anz.markets.efx.eventloop.IdleStrategy;
import com.anz.markets.efx.eventloop.IdleStrategyId;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.CommandExecutionEndpoint;
import com.anz.markets.efx.fox.acceptance.api.PricingClientEndpoint;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.api.VenueEndpoint;
import com.anz.markets.efx.fox.codec.api.InitStage;
import com.anz.markets.efx.fox.codec.api.SorEncoderSupplier;
import com.anz.markets.efx.fox.codec.api.SorEncoders;
import com.anz.markets.efx.fox.codec.base.SorTranslator;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoSorDecoders;
import com.anz.markets.efx.fox.codec.pojo.codec.PojoSorEncoders;
import com.anz.markets.efx.fox.codec.pojo.matcher.InitialisationMatcher;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.sbe.SbeSorDecoders;
import com.anz.markets.efx.fox.codec.sbe.SbeSorEncoders;
import com.anz.markets.efx.fox.common.MessageConsumerToDecoderAdapter;
import com.anz.markets.efx.fox.config.CommonConfig;
import com.anz.markets.efx.fox.config.ServerConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.messaging.transport.api.MessageHandler;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.messaging.transport.api.Topic;
import com.anz.markets.efx.messaging.transport.api.Transport;
import com.anz.markets.efx.messaging.transport.stub.Sink;
import com.anz.markets.efx.messaging.transport.stub.Source;
import com.anz.markets.efx.messaging.transport.stub.StubbedTransport;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForReading;
import com.anz.markets.efx.ngaro.sbe.SbeMessageForWriting;
import com.anz.markets.efx.pricing.client.api.PricingClient;
import com.anz.markets.efx.pricing.codec.api.PricingEncoders;
import com.anz.markets.efx.pricing.codec.base.PricingTranslator;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingDecoders;
import com.anz.markets.efx.pricing.codec.pojo.codec.PojoPricingEncoders;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingDecoders;
import com.anz.markets.efx.pricing.codec.sbe.SbePricingEncoders;
import com.anz.markets.efx.trading.codec.api.TradingEncoders;
import com.anz.markets.efx.trading.codec.base.TradingTranslator;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingDecoders;
import com.anz.markets.efx.trading.codec.pojo.codec.PojoTradingEncoders;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingDecoders;
import com.anz.markets.efx.trading.codec.sbe.SbeTradingEncoders;

@Configuration
@Import(ServerConfig.class)
public class TestConfig {

    @Bean
    public PricingClientEndpoint pricingClientEndpoint(final PricingClient<MutableSbeMessage> pricingClient) {
        final Queue<PricingMessage> pojoQueue = new ConcurrentLinkedQueue<>();
        final PricingTranslator<SbeMessage> pricingSbe2PojoTranslator = pricingSbe2PojoTranslator(pojoQueue::add);
        final Consumer<MutableSbeMessage> sbeMessageConsumer = pricingSbe2PojoTranslator::decode;

        return new PricingClientEndpoint() {
            @Override
            public boolean pollAll(final long instrumentId) {
                return pricingClient.poller().pollAll(sbeMessageConsumer, instrumentId);
            }

            @Override
            public Queue<PricingMessage> polledSnapshots() {
                return pojoQueue;
            }
        };
    }

    @Bean
    public Function<String, Queue<PricingMessage>> pricingQueueLookup() {
        final Map<String, Queue<PricingMessage>> cache = new ConcurrentHashMap<>();
        final Function<String, Queue<PricingMessage>> factory = topic -> new ConcurrentLinkedQueue<>();
        return topic -> cache.computeIfAbsent(topic, factory);
    }

    @Bean
    public Function<String, Queue<TradingMessage>> tradingQueueLookup() {
        final Map<String, Queue<TradingMessage>> cache = new ConcurrentHashMap<>();
        final Function<String, Queue<TradingMessage>> factory = topic -> new ConcurrentLinkedQueue<>();
        return topic -> cache.computeIfAbsent(topic, factory);
    }

    @Bean
    public Function<String, Queue<SorMessage>> sorQueueLookup() {
        final Map<String, Queue<SorMessage>> cache = new ConcurrentHashMap<>();
        final Function<String, Queue<SorMessage>> factory = topic -> new ConcurrentLinkedQueue<>();
        return topic -> cache.computeIfAbsent(topic, factory);
    }

    @Bean
    public VenueEndpoint.Lookup venueEndpointLookup(final Function<String, Queue<PricingMessage>> pricingQueueLookup,
                                                    final Function<String, Queue<TradingMessage>> tradingQueueLookup,
                                                    final PrecisionClock systemPrecisionClock) {
        final Map<Venue, VenueEndpoint> cache = new HashMap<>();
        final Function<Venue, VenueEndpoint> factory = venue -> new DefaultVenueEndpoint(venue, pricingQueueLookup, tradingQueueLookup, systemPrecisionClock.millis());
        return venue -> cache.computeIfAbsent(venue, factory);
    }

    @Bean
    public SorEndpoint sorEndpoint(final Function<String, Queue<TradingMessage>> tradingQueueLookup,
                                   final Function<String, Queue<SorMessage>> sorQueueLookup,
                                   final @Value("${trading.request.topic}") String tradingRequestTopicName,
                                   final @Value("${trading.response.topic}") String tradingResponseTopicName,
                                   final @Value("${config.topic}") String configTopicName,
                                   final PrecisionClock systemPrecisionClock) {
        return new DefaultSorEndpoint(tradingQueueLookup,
                sorQueueLookup, tradingRequestTopicName,
                tradingResponseTopicName, configTopicName,
                1000, systemPrecisionClock.millis());
    }

    @Bean
    public AcceptanceContext acceptanceContext(final PricingClientEndpoint pricingClientEndpoint,
                                               final VenueEndpoint.Lookup venueEndpointLookup,
                                               final SorEndpoint sorEndpoint,
                                               final CommandExecutionEndpoint commandExecutionEndpoint,
                                               final PrecisionClock systemPrecisionClock) {
        return new AcceptanceContext() {
            @Override
            public PricingClientEndpoint pricingClientEndpoint() {
                return pricingClientEndpoint;
            }

            @Override
            public VenueEndpoint.Lookup venueEndpointLookup() {
                return venueEndpointLookup;
            }

            @Override
            public SorEndpoint sorEndpoint() {
                return sorEndpoint;
            }

            @Override
            public CommandExecutionEndpoint eventProcessingEndpoint() {
                return commandExecutionEndpoint;
            }

            @Override
            public PrecisionClock precisionClock() {
                return systemPrecisionClock;
            }

            @Override
            public void awaitInit(final int timeoutSeconds, final boolean cleanQueue) {
                Asserter.of(eventProcessingEndpoint().eventsQueue())
                        .matching(InitialisationMatcher.build().body().matches(InitialisationMatcher.initStage().eq(InitStage.END)))
                        .awaitMatchAndGetLast(timeoutSeconds, TimeUnit.SECONDS);
                if (cleanQueue) {
                    eventProcessingEndpoint().commandsQueue().clear();
                    eventProcessingEndpoint().eventsQueue().clear();
                }
            }
        };
    }

    private static boolean tradingTopic(final String topicName) {
        return topicName.contains("TRADING") || topicName.contains("HEARTBEAT");
    }

    private static boolean loopbackTopic(final String topicName) {
        return topicName.contains("LOOPBACK");
    }

    private static boolean configTopic(final String topicName) {
        return topicName.contains("CONFIG");
    }

    @Bean
    public Function<String, Source> sourceLookup(final Function<String, Queue<PricingMessage>> pricingQueueLookup,
                                                 final Function<String, Queue<TradingMessage>> tradingQueueLookup,
                                                 final Function<String, Queue<SorMessage>> sorQueueLookup,
                                                 final PrecisionClock systemPrecisionClock) {
        final Map<String, Source> cache = new ConcurrentHashMap<>();
        final Function<String, Source> sourceFactory = topic -> {
            if (tradingTopic(topic)) {
                return tradingSource(tradingQueueLookup.apply(topic));
            } else if(loopbackTopic(topic)) {
                return sorSource(sorQueueLookup.apply(topic));
            } else if(configTopic(topic)) {
                return sorSource(sorQueueLookup.apply(topic));
            } else {
                return pricingSource(pricingQueueLookup.apply(topic), systemPrecisionClock);
            }
        };
        return topic -> cache.computeIfAbsent(topic, sourceFactory);
    }

    @Bean
    public Function<String, Sink> sinkLookup(final Function<String, Queue<TradingMessage>> tradingQueueLookup, final Function<String, Queue<SorMessage>> sorQueueLookup) {
        final Map<String, Sink> cache = new ConcurrentHashMap<>();
        final Function<String, Sink> sinkFactory = topic -> {
            if (tradingTopic(topic)) {
                return tradingSink(tradingQueueLookup.apply(topic));
            } else if (loopbackTopic(topic)) {
                return sorSink(sorQueueLookup.apply(topic));
            } else if (configTopic(topic)) {
                return sorSink(sorQueueLookup.apply(topic));
            } else {
                throw new IllegalStateException("Only trading messages are expected to be published");
            }
        };
        return topic -> cache.computeIfAbsent(topic, sinkFactory);
    }

    @Bean
    public Transport transport(final Function<String, Source> sourceLookup,
                               final Function<String, Sink> sinkLookup) {
        return StubbedTransport.builder()
                .pollingStrategyConductor(PollingStrategy.Conductor.APPLICATION)
                .sinks(publicationTopic -> sinkLookup.apply(publicationTopic.name()))
                .sources(subscriptionTopic -> sourceLookup.apply(subscriptionTopic.name())).build();
    }

    /**
     * PojoPricingMessages are sourced from the pricingMessageQueue, translated to SBE message and pushed to
     * the subscription message handler.
     *
     * @param pricingMessageQueue - source of PojoPricingMessages
     * @return Pricing source
     */
    private static Source pricingSource(final Queue<PricingMessage> pricingMessageQueue, final PrecisionClock precisionClock) {
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final PricingTranslator<PricingMessage> pojo2SbeTranslator = pricingPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), precisionClock.nanos())
        );
        return (topic, messageHandler) -> {
            final PricingMessage pojoPricingMessage = pricingMessageQueue.poll();
            if (pojoPricingMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoPricingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    private static PricingTranslator<PricingMessage> pricingPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final PricingEncoders<SbeMessage> sbePricingEncoders = new SbePricingEncoders(() -> sbeMessage);

        return PricingTranslator.create(
                new PojoPricingDecoders().all(),
                sbePricingEncoders.toPricingEncoderSupplier(sbeMessageConsumer)
        );
    }

    /**
     * PojoTradingResponseMessages are sourced from the tradingResponseMessageQueue, translated to SBE message and pushed to
     * the subscription message handler.
     *
     * @param tradingMessageQueue - source of PojoTradingResponseMessages
     * @return Trading source
     */
    private static Source tradingSource(final Queue<TradingMessage> tradingMessageQueue) {
        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final TradingTranslator<TradingMessage> pojo2SbeTranslator = tradingPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        return (topic, messageHandler) -> {
            final TradingMessage pojoTradingMessage = tradingMessageQueue.poll();
            if (pojoTradingMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoTradingMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    /**
     * SorMessages are sourced from the sorMessageQueue, translated to SBE message and pushed to
     * the subscription message handler.
     *
     * @param sorMessageQueue - source of SorMessages
     * @return SOR source
     */
    private static Source sorSource(final Queue<SorMessage> sorMessageQueue) {
        final LongSupplier nanoTimeSource = () -> 0L;
        final AtomicReference<Topic> topicHolder = new AtomicReference<>();
        final AtomicReference<MessageHandler> messageHandlerHolder = new AtomicReference<>();
        final SorTranslator<SorMessage> pojo2SbeTranslator = sorPojo2SbeTranslator(
                sbeMessage -> messageHandlerHolder.get().onMessage(topicHolder.get(), sbeMessage.buffer(), 0, sbeMessage.messageLength(), nanoTimeSource.getAsLong())
        );
        return (topic, messageHandler) -> {
            final SorMessage pojoSorMessage = sorMessageQueue.poll();
            if (pojoSorMessage != null) {
                topicHolder.set(topic);
                messageHandlerHolder.set(messageHandler);
                try {
                    pojo2SbeTranslator.decode(pojoSorMessage);
                    return true;
                } finally {
                    messageHandlerHolder.set(null);
                    topicHolder.set(null);
                }
            }
            return false;
        };
    }

    /**
     * DirectBuffer content is translated to TradingMessage and placed to the tradingMessageQueue.
     *
     * @param tradingMessageQueue - destination of PojoTradingMessages
     * @return Trading sink
     */
    private static Sink tradingSink(final Queue<TradingMessage> tradingMessageQueue) {
        final AtomicReference<TradingMessage> messageHolder = new AtomicReference<>();
        final TradingTranslator<SbeMessage> tradingSbe2PojoTranslator = tradingSbe2PojoTranslator(messageHolder::set);
        final SbeMessageForReading sbeMessage = new SbeMessageForReading();
        return Sink.create((buf, off, len) -> {
            tradingSbe2PojoTranslator.decode(sbeMessage.wrap(buf, off, len));
            sbeMessage.unwrap();
            return messageHolder.getAndSet(null);
        }, tradingMessageQueue::offer);
    }

    /**
     * DirectBuffer content is translated to SorMessage and placed to the sorMessageQueue.
     *
     * @param sorMessageQueue - destination of SorMessages
     * @return SOR sink
     */
    private static Sink sorSink(final Queue<SorMessage> sorMessageQueue) {
        final AtomicReference<SorMessage> messageHolder = new AtomicReference<>();
        final SorTranslator<SbeMessage> sorSbe2PojoTranslator = sorSbe2PojoTranslator(messageHolder::set);
        final SbeMessageForReading sbeMessage = new SbeMessageForReading();
        return Sink.create((buf, off, len) -> {
            sorSbe2PojoTranslator.decode(sbeMessage.wrap(buf, off, len));
            sbeMessage.unwrap();
            return messageHolder.getAndSet(null);
        }, sorMessageQueue::offer);
    }

    private static TradingTranslator<TradingMessage> tradingPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final TradingEncoders<SbeMessage> sbeTradingEncoders = new SbeTradingEncoders(() -> sbeMessage);

        return TradingTranslator.create(
                new PojoTradingDecoders().all(),
                sbeTradingEncoders.toTradingEncoderSupplier(sbeMessageConsumer));
    }

    private static SorTranslator<SorMessage> sorPojo2SbeTranslator(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        return SorTranslator.create(
                new PojoSorDecoders().all(),
                sorEncoderSupplier(sbeMessageConsumer));
    }

    public static SorEncoderSupplier sorEncoderSupplier(final Consumer<? super SbeMessage> sbeMessageConsumer) {
        final ByteBuffer byteBuffer = ByteBuffer.allocateDirect(8192);
        final UnsafeBuffer buffer = new UnsafeBuffer(byteBuffer);
        final SbeMessageForWriting sbeMessage = new SbeMessageForWriting(buffer);
        final SorEncoders<SbeMessage> sbeSorEncoders = new SbeSorEncoders(() -> sbeMessage);
        return  sbeSorEncoders.toSorEncoderSupplier(sbeMessageConsumer);
    }

    private static TradingTranslator<SbeMessage> tradingSbe2PojoTranslator(final Consumer<? super TradingMessage> pojoMessageConsumer) {
        return TradingTranslator.create(
                new SbeTradingDecoders().all(),
                new PojoTradingEncoders().toTradingEncoderSupplier(pojoMessageConsumer)
        );
    }

    private static SorTranslator<SbeMessage> sorSbe2PojoTranslator(final Consumer<? super SorMessage> pojoMessageConsumer) {
        return SorTranslator.create(
                new SbeSorDecoders().all(),
                new PojoSorEncoders().toSorEncoderSupplier(pojoMessageConsumer)
        );
    }

    private static PricingTranslator<SbeMessage> pricingSbe2PojoTranslator(final Consumer<? super PricingMessage> pojoMessageConsumer) {
        return PricingTranslator.create(
                new SbePricingDecoders().all(),
                new PojoPricingEncoders().toPricingEncoderSupplier(pojoMessageConsumer)
        );
    }

    @Bean(destroyMethod = "close")
    public CommandExecutionEndpoint commandExecutionEndpoint(final @Value("${event.sourcing.directory}") String directory,
                                                               final @Value("${event.sourcing.commands.file.prefix}") String commandsFilePrefix,
                                                               final @Value("${event.sourcing.events.file.prefix}") String eventsFilePrefix) throws IOException {

        final IndexedPollerFactory commandsPollerFactory =
                MmapBuilder.create()
                        .directory(directory)
                        .filePrefix(commandsFilePrefix)
                        .regionRingFactory(RegionRingFactory.forSync(RegionFactory.SYNC))
                        .buildPollerFactory();

        final IndexedPollerFactory eventsPollerFactory =
                MmapBuilder.create()
                        .directory(directory)
                        .filePrefix(eventsFilePrefix)
                        .regionRingFactory(RegionRingFactory.forSync(RegionFactory.SYNC))
                        .buildPollerFactory();

        final Poller commandsPoller = commandsPollerFactory.createPoller(
                Poller.Options.builder()
                        .build());

        final Poller eventsPoller = eventsPollerFactory.createPoller(
                Poller.Options.builder()
                .bufferPoller(new PayloadBufferPoller())
                .build()
        );

        final Queue<Object> commandsQueue = new ConcurrentLinkedQueue<>();
        final Queue<Object> eventsQueue = new ConcurrentLinkedQueue<>();

        final TradingTranslator<SbeMessage> commandTradingSbe2PojoTranslator = tradingSbe2PojoTranslator(commandsQueue::add);
        final PricingTranslator<SbeMessage> commandPricingSbe2PojoTranslator = pricingSbe2PojoTranslator(commandsQueue::add);
        final SorTranslator<SbeMessage> commandSorSbe2PojoTranslator = sorSbe2PojoTranslator(commandsQueue::add);

        final TradingTranslator<SbeMessage> eventTradingSbe2PojoTranslator = tradingSbe2PojoTranslator(eventsQueue::add);
        final PricingTranslator<SbeMessage> eventPricingSbe2PojoTranslator = pricingSbe2PojoTranslator(eventsQueue::add);
        final SorTranslator<SbeMessage> eventSorSbe2PojoTranslator = sorSbe2PojoTranslator(eventsQueue::add);

        final MessageDecoder<SbeMessage> commandMessageDecoder = MessageDecoder.composite(Arrays.asList(commandSorSbe2PojoTranslator, commandTradingSbe2PojoTranslator, commandPricingSbe2PojoTranslator));
        final MessageDecoder<SbeMessage> eventMessageDecoder = MessageDecoder.composite(Arrays.asList(eventSorSbe2PojoTranslator, eventTradingSbe2PojoTranslator, eventPricingSbe2PojoTranslator));
        final MessageConsumer commandMessageConsumer = new MessageConsumerToDecoderAdapter(commandMessageDecoder);
        final MessageConsumer eventMessageConsumer = new MessageConsumerToDecoderAdapter(eventMessageDecoder);
        final PollingProcessStep commandExecutionStep = new PollingProcessStep(commandsPoller, commandMessageConsumer);
        final PollingProcessStep eventApplyingStep = new PollingProcessStep(eventsPoller, eventMessageConsumer);

        final IdleStrategy idleStrategy = CommonConfig.idleStrategyFactory(IdleStrategyId.BACK_OFF, 100, 100, 100).get();

        final EventLoopService eventProcessingEndpointPoller = new EventLoopService("EventProcessingQueueEndpointLoop", 10, TimeUnit.SECONDS, idleStrategy, commandExecutionStep::perform, eventApplyingStep::perform);
        eventProcessingEndpointPoller.start();

        return new CommandExecutionEndpoint() {
            @Override
            public Queue<Object> commandsQueue() {
                return commandsQueue;
            }

            @Override
            public Queue<Object> eventsQueue() {
                return eventsQueue;
            }

            @Override
            public void close() {
                eventProcessingEndpointPoller.stop();
                commandsPoller.close();
                eventsPoller.close();
            }
        };
    }
}
