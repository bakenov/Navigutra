package com.anz.markets.efx.fox.codec.sbe;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.codec.api.VenueInstrumentConfigHandler;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.VenueInstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageForwarder;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

final class SbeVenueInstrumentConfigDecoder {
    private final VenueInstrumentConfigDecoder venueInstrumentConfigDecoder = new VenueInstrumentConfigDecoder();
    private final Consumer<StringBuilder> messageLogger = venueInstrumentConfigDecoder::appendTo;
    private final Body body = new Body();

    private EncodingOrder.VenueInstrumentConfig encodingOrder = EncodingOrder.VenueInstrumentConfig.INITIAL;

    void decode(final SbeMessage message, final MessageHeaderDecoder headerDecoder,
                final VenueInstrumentConfigHandler venueInstrumentConfigHandler,
                final MessageForwarder messageForwarder) {
        encodingOrder = EncodingOrder.VenueInstrumentConfig.INITIAL;
        venueInstrumentConfigDecoder.wrap(message.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        try {
            venueInstrumentConfigHandler.onMessageStart(headerDecoder.source(), headerDecoder.sourceSeq());
            venueInstrumentConfigHandler.messageForwarder(messageForwarder);
            venueInstrumentConfigHandler.messageLogger(messageLogger);
            body.decode(venueInstrumentConfigHandler);
            venueInstrumentConfigHandler.onMessageComplete();
        } finally {
            encodingOrder = EncodingOrder.VenueInstrumentConfig.INITIAL;
            venueInstrumentConfigDecoder.wrap(null, 0, 0, 0);
        }
    }

    private final class Body implements VenueInstrumentConfigHandler.Body {

        void decode(final VenueInstrumentConfigHandler venueInstrumentConfigHandler) {
            encodingOrder = EncodingOrder.VenueInstrumentConfig.BODY;
            venueInstrumentConfigHandler.onBody(this);
        }

        @Override
        public Venue venue() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return Enums.venue(venueInstrumentConfigDecoder.venue());
        }

        @Override
        public long instrumentId() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.instrumentId();
        }

        @Override
        public double priceIncrement() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.priceIncrement();
        }

        @Override
        public int sizeIncrement() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.sizeIncrement();
        }

        @Override
        public int clipSizeMultiple() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.clipSizeMultiple();
        }

        @Override
        public double maxAllowedParentOrderQty() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.maxAllowedParentOrderQty();
        }

        @Override
        public int minClipSize() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.minClipSize();
        }

        @Override
        public int maxClipSize() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.maxClipSize();
        }

        @Override
        public int staleDataTimeout() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.staleDataTimeout();
        }

        @Override
        public int priority() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.priority();
        }

        @Override
        public int proportion() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.proportion();
        }

        @Override
        public boolean enabled() {
            encodingOrder.checkStrict(EncodingOrder.VenueInstrumentConfig.BODY);
            return venueInstrumentConfigDecoder.enabled() == YesNo.YES;
        }
    }
}
