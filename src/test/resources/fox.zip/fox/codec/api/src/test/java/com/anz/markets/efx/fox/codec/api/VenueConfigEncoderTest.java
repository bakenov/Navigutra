package com.anz.markets.efx.fox.codec.api;


import org.junit.Test;

import com.anz.markets.efx.ngaro.api.Venue;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

public class VenueConfigEncoderTest {
    @Test
    public void encoderChaining() {
        final VenueConfigEncoder encoder = mock(VenueConfigEncoder.class, RETURNS_DEEP_STUBS);

        encoder.messageStart(0, 0)
                .venue(Venue.RFX)
                .compId().encode("lg-rfx")
                .enabled(true)
                .messageComplete();
    }
}