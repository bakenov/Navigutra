package com.anz.axle.lg.adapter.d3.config;

import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.CronTask;
import org.springframework.scheduling.config.IntervalTask;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

import com.anz.axle.lg.adapter.d3.newsubscription.SubscriptionRegistry;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.metric.MetricDomain;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MetricLoggingConfig;
import com.anz.axle.lg.metric.MetricRepositoryFactory;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.queue.Queue;

@Configuration
@EnableScheduling
class TimerConfig implements SchedulingConfigurer {

    @Autowired
    private List<IntervalTask> fixedDelayTasks;

    @Autowired
    private List<CronTask> cronTasks;

    @Override
    public void configureTasks(final ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.setScheduler(timerTickScheduler());
        taskRegistrar.setFixedDelayTasksList(fixedDelayTasks);
        taskRegistrar.setCronTasksList(cronTasks);
    }

    @Bean(destroyMethod = "shutdown")
    ThreadPoolTaskScheduler timerTickScheduler() {
        final ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(1);
        return scheduler;
    }

    @Bean
    IntervalTask checkAndRetryAllFailedSubscriptionsIntervalTask(final Queue<Runnable> mainEventLoopRunnableQueue,
                                                                 final SubscriptionRegistry subscriptionRegistry,
                                                                 @Value("${retry.task.millis}") final long retryTaskMillis) {
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = subscriptionRegistry::checkAndRetryAllFailed;
        return new IntervalTask(
                () -> eventAppender.enqueue(task), retryTaskMillis
        );
    }

    @Bean
    IntervalTask checkAndHandleAllExpiredSubscriptionsIntervalTask(final Queue<Runnable> mainEventLoopRunnableQueue,
                                                                   final SubscriptionRegistry subscriptionRegistry,
                                                                   @Value("${expire.task.millis}") final long expireTaskMillis) {
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = subscriptionRegistry::checkAndHandleAllExpired;
        return new IntervalTask(
                () -> eventAppender.enqueue(task), expireTaskMillis
        );
    }

    @Bean
    IntervalTask checkAndHandleMissedUpdateIntervalTask(final Queue<Runnable> mainEventLoopRunnableQueue,
                                                        final SubscriptionRegistry subscriptionRegistry,
                                                        @Value("${missed.update.task.millis}") final long missedUpdateTaskMillis) {
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = subscriptionRegistry::checkAndHandleMissedUpdate;
        return new IntervalTask(
                () -> eventAppender.enqueue(task), missedUpdateTaskMillis
        );
    }

    @Bean
    IntervalTask publishLatestUpdatesIntervalTask(final Queue<Runnable> mainEventLoopRunnableQueue,
                                                  final SubscriptionRegistry subscriptionRegistry,
                                                  @Value("${publish.latest.updates.task.millis}") final long publishLatestUpdatesTaskMillis) {
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = subscriptionRegistry::publishLatestUpdates;
        return new IntervalTask(
                () -> eventAppender.enqueue(task), publishLatestUpdatesTaskMillis
        );
    }

    @Bean
    CronTask spotDateRoll(final Queue<Runnable> mainEventLoopRunnableQueue,
                          final SubscriptionRegistry subscriptionRegistry,
                          @Value("${spot.date.roll.cron.expression}") final String spotDateRollCronExpression,
                          @Value("${spot.date.roll.cron.time.zone}") final String spotDateRollCronTimeZone) {
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = subscriptionRegistry::spotDateRollResubscribe;
        return new CronTask(() -> eventAppender.enqueue(task), new CronTrigger(spotDateRollCronExpression, TimeZone.getTimeZone(spotDateRollCronTimeZone)));
    }

    @Bean
    IntervalTask mainEventLoopMetricReportTask(final Queue<Runnable> mainEventLoopRunnableQueue,
                                               final MetricRepository<Metric, Venue> metricRepository,
                                               @Value("${metrics.reporting.period.seconds}") final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(MetricDomain.MAIN_LOOP, metricRepository);
        final Queue.Appender<Runnable> eventAppender = mainEventLoopRunnableQueue.appender();
        final Runnable task = () -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository);
        return new IntervalTask(() -> eventAppender.enqueue(task), TimeUnit.SECONDS.toMillis(periodSeconds));
    }

    @Bean
    IntervalTask serviceRequestEventLoopMetricReportTask(final Queue<Runnable> serviceRequestEventLoopRunnableQueue,
                                                         final MetricRepository<Metric, Venue> metricRepository,
                                                         @Value("${metrics.reporting.period.seconds}") final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(MetricDomain.SERVICE_LOOP, metricRepository);
        final Queue.Appender<Runnable> eventAppender = serviceRequestEventLoopRunnableQueue.appender();
        final Runnable task = () -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository);
        return new IntervalTask(() -> eventAppender.enqueue(task), TimeUnit.SECONDS.toMillis(periodSeconds));
    }

    @Bean
    IntervalTask concurrentMetricReportTask(final MetricRepository<Metric, Venue> metricRepository,
                                            @Value("${metrics.reporting.period.seconds}") final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(MetricDomain.CONCURRENT, metricRepository);
        return new IntervalTask(() -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository), TimeUnit.SECONDS.toMillis(periodSeconds));
    }
}
