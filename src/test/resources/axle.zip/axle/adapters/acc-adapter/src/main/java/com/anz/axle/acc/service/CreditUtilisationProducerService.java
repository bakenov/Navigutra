package com.anz.axle.acc.service;

import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Service
public interface CreditUtilisationProducerService {
    CounterpartyCreditUtilisations findCounterpartySpotDateCreditUtilisationsSince(LocalDate start);
    CurrentVenueCurrencyCreditStates findCurrentVenueCurrencyCreditStatesSince(LocalDate start);
}
