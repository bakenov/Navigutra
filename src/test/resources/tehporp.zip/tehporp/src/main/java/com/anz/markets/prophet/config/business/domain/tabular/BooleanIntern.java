package com.anz.markets.prophet.config.business.domain.tabular;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class BooleanIntern implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Map<Boolean, BooleanIntern> intern = new HashMap<>();

    private boolean x;

    public static BooleanIntern get(Boolean x) {
        return intern.computeIfAbsent(x, y -> new BooleanIntern(x));
    }

    private BooleanIntern(final boolean x) {
        this.x = x;
    }

    public final boolean get() {
        return x;
    }
}