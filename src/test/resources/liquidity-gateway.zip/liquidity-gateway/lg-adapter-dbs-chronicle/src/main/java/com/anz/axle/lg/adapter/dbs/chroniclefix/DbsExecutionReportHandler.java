package com.anz.axle.lg.adapter.dbs.chroniclefix;

import java.util.Objects;
import java.util.function.LongSupplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.lg.adapter.SecurityTypeSymbolLookup;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.OrdStatus;
import com.anz.axle.lg.adapter.dbs.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.time.LocalDateDecoder;
import com.anz.markets.efx.ngaro.time.LocalDateFormat;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.ExecutionReportEncoder;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;

import static com.anz.axle.lg.adapter.chroniclefix.ChronicleFixUtils.zeroIfUnSet;
import static com.anz.axle.lg.adapter.fix.Converter.nanToZero;

public final class DbsExecutionReportHandler implements ChronicleMessageHandler<ExecutionReport> {
    private static final Logger LOGGER = LoggerFactory.getLogger(DbsExecutionReportHandler.class);
    private static final LocalDateDecoder DATE_DECODER = LocalDateFormat.YYYYMMDD.getDefaultDecoder();

    private final TradingEncoderSupplier tradingResponseEncoderSupplier;
    private final PrecisionClock precisionClock;
    private final String senderCompId;
    private final String compId;
    private final LongSupplier messageIdGenerator;
    private final SecurityTypeSymbolLookup securityTypeSymbolLookup;

    private final CachedFunction<String, String> symbol6Lookup = CachedFunction.of(SymbolNormaliser::toSymbol6);
    private final SourceSequencer sourceSequencer;

    public DbsExecutionReportHandler(final TradingEncoderSupplier tradingResponseEncoderSupplier,
                                     final PrecisionClock precisionClock,
                                     final String senderCompId,
                                     final String compId,
                                     final LongSupplier messageIdGenerator,
                                     final SecurityTypeSymbolLookup securityTypeSymbolLookup,
                                     final SourceSequencer sourceSequencer) {
        this.tradingResponseEncoderSupplier = Objects.requireNonNull(tradingResponseEncoderSupplier);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.messageIdGenerator = Objects.requireNonNull(messageIdGenerator);
        this.securityTypeSymbolLookup = Objects.requireNonNull(securityTypeSymbolLookup);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public void accept(final ExecutionReport message) throws IllegalArgumentException {

        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.debug("ExecutionReport received: {}", message);

        final long sequenceNumber = message.msgSeqNum();
        final long messageId = messageIdGenerator.getAsLong();
        final long sendingTimeNanos = zeroIfUnSet(message.sendingTime());
        final OrderStatus orderStatus = orderStatus(message.ordStatus());
        final String symbol = symbol6Lookup.apply((message.symbol()));

        final ExecutionReportEncoder.Body bodyEncoder = tradingResponseEncoderSupplier.executionReport()
                .messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .orderId().encode(message.orderID())
                .clOrdId().encode(message.clOrdID())
                .origClOrdId().encode(message.clOrdID())
                .clOrdLinkId().encodeEmpty()
                .marketId().encode(Venue.DBS.name())
                .execId().encodeNullable(message.execID())
                .execType(execType(message.execType()))
                .settlDate().encodeFormatted(message.settlDate(), DATE_DECODER)
                .maturityDate().encodeFormatted(message.maturityDate(), DATE_DECODER)
                .ordStatus(orderStatus)
                .symbol().encode(symbol)
                .securityType(securityTypeSymbolLookup.securityType(symbol))
                .orderQty(nanToZero(message.orderQty()))
                .targetStrategyName().encodeEmpty()
                .price(nanToZero(message.price()))
                .side(side(message.side()))
                .currency().encodeNullable(message.currency())
                .lastPx(nanToZero(message.lastPx()))
                .lastQty(nanToZero(message.lastShares()))
                .leavesQty(orderStatus == OrderStatus.REJECTED ? 0.0 : nanToZero(message.leavesQty()))
                .cumQty(nanToZero(message.cumQty()))
                .avgPx(nanToZero(message.avgPx()))
                .transactTime(zeroIfUnSet(message.transactTime()));

        bodyEncoder
                .partiesEmpty()
                .strategyParametersEmpty()
                .regulatoryTradeIdsEmpty()
                .hopsStart(2)
                    .next()
                        .hopCompId().encode(senderCompId)
                        .hopMessageId(sequenceNumber)
                        .hopReceivingTime(0)
                        .hopSendingTime(sendingTimeNanos)
                    .next()
                        .hopCompId().encode(compId)
                        .hopMessageId(messageId)
                        .hopReceivingTime(receivingTimeNanos)
                        .hopSendingTime(precisionClock.nanos())
                    .hopsComplete()
                .quoteId().encodeEmpty()
                .rejectText().encodeNullable(message.text())
                .messageComplete();
    }

    private ExecType execType(final char execType) {
        switch (execType) {
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.NEW: return ExecType.NEW;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.PARTIAL_FILL: return ExecType.TRADE;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.FILL: return ExecType.TRADE;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.TRADE: return ExecType.TRADE;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.PENDING_CANCEL: return ExecType.PENDING_CANCEL;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.CANCELED: return ExecType.CANCELED;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.EXPIRED: return ExecType.EXPIRED;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.PENDING_REPLACE: return ExecType.PENDING_REPLACE;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.REPLACE: return ExecType.REPLACED;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.REJECTED: return ExecType.REJECTED;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.ExecType.ORDER_STATUS: return ExecType.ORDER_STATUS;
            default: throw new IllegalArgumentException("Unsupported execType " + execType);
        }
    }

    private Side side(final char side) throws IllegalArgumentException {
        switch (side) {
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.Side.BUY : return Side.BUY;
            case com.anz.axle.lg.adapter.dbs.chroniclefix.generated.fields.Side.SELL : return Side.SELL;
            default: throw new IllegalArgumentException("Unsupported side " + side);
        }
    }

    private OrderStatus orderStatus(final char ordStatus) throws IllegalArgumentException {
        switch (ordStatus) {
            case OrdStatus.NEW: return OrderStatus.NEW;
            case OrdStatus.PARTIALLY_FILLED: return OrderStatus.PARTIALLY_FILLED;
            case OrdStatus.FILLED: return OrderStatus.FILLED;
            case OrdStatus.PENDING_CANCEL: return OrderStatus.PENDING_CANCEL;
            case OrdStatus.CANCELED: return OrderStatus.CANCELED;
            case OrdStatus.EXPIRED: return OrderStatus.EXPIRED;
            case OrdStatus.PENDING_REPLACE: return OrderStatus.PENDING_REPLACE;
            case OrdStatus.REPLACED: return OrderStatus.REPLACED;
            case OrdStatus.REJECTED : return OrderStatus.REJECTED;
            // what about U = Undefined?
            default: throw new IllegalArgumentException("Unsupported ordStatus " + ordStatus);
        }
    }
}
