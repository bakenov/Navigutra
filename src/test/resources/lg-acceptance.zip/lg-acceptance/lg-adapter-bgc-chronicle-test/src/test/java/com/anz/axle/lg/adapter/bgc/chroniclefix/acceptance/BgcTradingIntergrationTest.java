package com.anz.axle.lg.adapter.bgc.chroniclefix.acceptance;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.acceptance.utils.TestUtils;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.OrdType;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Logon;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.Logout;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.datamodel.DefaultHeaderTrailer;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.PartyRole;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import net.openhft.chronicle.bytes.Bytes;
import net.openhft.chronicle.core.io.IOTools;
import net.openhft.chronicle.wire.Marshallable;
import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.sessioncode.messages.StandardHeaderTrailer;
import software.chronicle.fix.staticcode.ChronicleFixEngine;
import software.chronicle.fix.staticcode.FixSessionHandler;
import software.chronicle.fix.staticcode.FixVersion;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.yaml.TcpSession;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.getRandomFreeLocalPort;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.setPersistStorePath;
import static com.anz.axle.lg.adapter.acceptance.utils.TestUtils.waitForStop;
import static com.anz.axle.lg.util.SymbolNormaliser.toSymbol6;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class BgcTradingIntergrationTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(BgcTradingIntergrationTest.class);

    @Rule
    public final TestName testName = new TestName();

    private final BgcFixToDTOTestDataGenerator dataGenerator = new BgcFixToDTOTestDataGenerator();

    private Application application;
    private SharedAcceptanceContext acceptanceContext;

    private Venue marketId;

    // Server side
    private static final String HOST = "localhost";
    private static final String TARGET_COMP_ID = "SERVER";
    private static final String USERNAME = "STUB";
    private static final String PASSWORD = "PASSWORD";

    private FixSessionHandler serverSession;
    private Queue<StandardHeaderTrailer> bgcReceiveQueue;
    private FixEngineCfg cfg;
    private ChronicleFixEngine engine;
    private TcpSession tcpSession;
    private PrecisionClock precisionClock;

    private String appName;
    private String senderCompId;
    private int port;
    private String fixFilePath;
    private String fixStorePath;
    private String path;

    @Before
    public void setup() throws Exception {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        appName = "bgc";
        marketId = Venue.BGCMIDFX;
        senderCompId = "_BGC_";
        setPersistStorePath(appName, testName.getMethodName());
        port = getRandomFreeLocalPort();
        path = "target/" + appName + "/" + System.currentTimeMillis();

        fixFilePath = path + "/log/";
        fixStorePath = path + "/store/";

        System.getProperties().putAll(
                StringUtils.parseMap(
                        "appName:lg-" + appName +
                                ",venue:" + marketId.name() +
                                ",appOptions:--reset" +
                                ",default.log.appender:Console" +
                                ",default.log.level:DEBUG" +
                                ",chronicle.fix.logging:true" +
                                "," + appName + ".fix.trading.allowedLatencyMs:60000" +
                                "," + appName + ".fix.pricing.session.enable:false" +
                                "," + appName + ".fix.trading.session.enable:true" +
                                "," + appName + ".fix.socket.use.ssl:N" +
                                "," + appName + ".fix.log.destination:STDOUT" +
                                "," + appName + ".fix.file.log.path:" + fixFilePath +
                                "," + appName + ".fix.file.store.path:" + fixStorePath +
                                "," + appName + ".fix.log_all:true" +
                                "," + appName + ".fix.reconnectInterval:1" +
                                "," + appName + ".fix.trading.sendercompid:" + senderCompId +
                                "," + appName + ".fix.trading.targetcompid:" + TARGET_COMP_ID +
                                "," + appName + ".fix.trading.username:" + USERNAME +
                                "," + appName + ".fix.trading.password:" + PASSWORD +
                                "," + appName + ".fix.trading.host:" + HOST +
                                "," + appName + ".fix.trading.port:" + port
                ));

        System.setProperty("rounding.decimal.place.symbols", "{'3':{'EURJPY','USDJPY','EURHUF'}}");

        startServerSide();

        application = new Application("lg-bgc-acceptance", TradingAcceptanceConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(SharedAcceptanceContext.class);
        precisionClock = application.getApplicationContext().getBean(PrecisionClock.class);
        assertTrue(TestUtils.waitFor(serverSession::isConnected, 10_000));
        LOGGER.info("Server connected.");
    }

    @After
    public void afterEach() {
        waitForStop(application, 3, 500, testName.getMethodName());
        IOTools.deleteDirWithFiles(path);
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void logon_trade_heartbeat_logoff() {
        // wait for login reply from BGC
        final Logon logon = (Logon) waitFor(Logon.class);
        assertThat(logon.senderCompID(), is(senderCompId));
        receivingLGHeartbeatOnUM();
        bgcReceiveQueue.clear();

        bgcFillSequence_sendOrderReceiveNewThenFillExecutionReports();
        bgcCancelSequence_sendOrderReceiveNewThenCancelExecutionReport();
        bgcCancelRequestPendingCancelCancelSequence_sendOrderReceivePendingCancelExecutionReport();
        bgcRejectSequence_sendOrderReceiveOrderReject();

        receivingLGHeartbeatOnUM();
        stoppingAndLogoutOnDisconnect();
    }

    private void receivingLGHeartbeatOnUM() {
        Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(HeartbeatMatcher.build()
                        .header().matches(HeartbeatMatcher.source().gt(0))
                        .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                        .body().matches(HeartbeatMatcher.senderCompId().eq("GB:lg-bgc"))
                        .body().matches(HeartbeatMatcher.messageId().gt(0L)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }

    private void bgcFillSequence_sendOrderReceiveNewThenFillExecutionReports() {

        final List<DefaultHeaderTrailer> bgcFillSequence = dataGenerator.bgcFillSequence();

        // send UM NewOrderSingle and BGC NewOrderSingle over fix
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle bgcNewOrderSingle = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle)bgcFillSequence.get(0);
        sendUMNewOrderSingleAndBGCReceiveNewOrderSingle(bgcNewOrderSingle);

        // BGC reply with ExecutionReport New, Fill then Calculated. Receive over UM
        final ExecutionReport bgcExecutionReportNew = (ExecutionReport)bgcFillSequence.get(1);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportNew);
        waitForExecutionReportFromUM(bgcExecutionReportNew, ExecType.NEW, OrderStatus.NEW, bgcNewOrderSingle.orderQty());

        final ExecutionReport bgcExecutionReportFill = (ExecutionReport)bgcFillSequence.get(2);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportFill);
        // lg ignores fill and generate UM ER from the following Calculated ER

        final ExecutionReport bgcExecutionReportCalculated = (ExecutionReport)bgcFillSequence.get(3);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportCalculated);
        final com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport umExecutionReportFill =
                waitForExecutionReportFromUM(bgcExecutionReportCalculated, ExecType.TRADE, OrderStatus.FILLED, bgcExecutionReportCalculated.leavesQty());

        assertThat(umExecutionReportFill.parties.size(), is((int)bgcExecutionReportCalculated.noPartyIDs()));
        assertThat(umExecutionReportFill.parties.get(0).partyRole, is(PartyRole.CLIENT_ID));
        assertThat(umExecutionReportFill.parties.get(0).partyId, is("UBZK"));
        assertThat(umExecutionReportFill.parties.get(1).partyRole, is(PartyRole.BUYER));
        assertThat(umExecutionReportFill.parties.get(1).partyId, is("ANZM"));
        assertThat(umExecutionReportFill.parties.get(2).partyRole, is(PartyRole.CONTRA_FIRM));
        assertThat(umExecutionReportFill.parties.get(2).partyId, is("UBZK"));
    }

    private void bgcCancelSequence_sendOrderReceiveNewThenCancelExecutionReport() {

        final List<DefaultHeaderTrailer> bgcCancelSequence = dataGenerator.bgcCancelSequence();

        // send UM NewOrderSingle and BGC NewOrderSingle over fix
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle bgcNewOrderSingle = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle)bgcCancelSequence.get(0);
        final NewOrderSingle newOrderSingleUM = sendUMNewOrderSingleAndBGCReceiveNewOrderSingle(bgcNewOrderSingle);

        // BGC reply with ExecutionReport New, Fill then Calculated. Receive over UM
        final ExecutionReport bgcExecutionReportNew = (ExecutionReport)bgcCancelSequence.get(1);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportNew);
        waitForExecutionReportFromUM(bgcExecutionReportNew, ExecType.NEW, OrderStatus.NEW, bgcNewOrderSingle.orderQty());

        // send Cancel to BGC
        final OrderCancelRequest orderCancelRequestUM = orderCancelRequestUMMessage(newOrderSingleUM);
        LOGGER.info("Sending OrderCancelRequest..." + orderCancelRequestUM);
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequestUM);

        LOGGER.info("Waiting for OrderCancelRequest..." + orderCancelRequestUM.body.symbol + " clOrdId=" + orderCancelRequestUM.body.clOrdId);
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest bgcOrderCancelRequest = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest)waitFor(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest.class);
        LOGGER.info("waitForOrderCancelRequest Received: " + bgcOrderCancelRequest);

        // BGC send cancel ER and receive by UM
        final ExecutionReport bgcExecutionReportCancel = (ExecutionReport)bgcCancelSequence.get(3);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportCancel);
        waitForExecutionReportFromUM(bgcExecutionReportCancel, ExecType.CANCELED, OrderStatus.CANCELED, bgcExecutionReportCancel.leavesQty());
    }

    private void bgcCancelRequestPendingCancelCancelSequence_sendOrderReceivePendingCancelExecutionReport() {
        final List<DefaultHeaderTrailer> bgcPendingCancelSequence = dataGenerator.bgcCancelRequestPendingCancelCancelSequence();

        // send UM NewOrderSingle and BGC NewOrderSingle over fix
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle bgcNewOrderSingle = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle)bgcPendingCancelSequence.get(0);
        final NewOrderSingle newOrderSingleUM = sendUMNewOrderSingleAndBGCReceiveNewOrderSingle(bgcNewOrderSingle);

        // BGC reply with ExecutionReport New, Fill then Calculated. Receive over UM
        final ExecutionReport bgcExecutionReportNew = (ExecutionReport)bgcPendingCancelSequence.get(1);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportNew);
        waitForExecutionReportFromUM(bgcExecutionReportNew, ExecType.NEW, OrderStatus.NEW, bgcNewOrderSingle.orderQty());

        // send Cancel to BGC
        final OrderCancelRequest orderCancelRequestUM = orderCancelRequestUMMessage(newOrderSingleUM);
        LOGGER.info("Sending OrderCancelRequest..." + orderCancelRequestUM);
        acceptanceContext.tradingRequestMessageQueue().add(orderCancelRequestUM);

        LOGGER.info("Waiting for OrderCancelRequest..." + orderCancelRequestUM.body.symbol + " clOrdId=" + orderCancelRequestUM.body.clOrdId);
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest bgcOrderCancelRequest = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest)waitFor(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelRequest.class);
        LOGGER.info("waitForOrderCancelRequest Received: " + bgcOrderCancelRequest);

        // BGC send pending cancel ER and receive by UM
        final ExecutionReport bgcExecutionReportPendingCancel = (ExecutionReport)bgcPendingCancelSequence.get(3);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportPendingCancel);
        waitForExecutionReportFromUM(bgcExecutionReportPendingCancel, ExecType.PENDING_CANCEL, OrderStatus.PENDING_CANCEL, bgcExecutionReportPendingCancel.leavesQty());

        // BGC send cancel ER and receive by UM
        final ExecutionReport bgcExecutionReportCancel = (ExecutionReport)bgcPendingCancelSequence.get(4);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportCancel);
        waitForExecutionReportFromUM(bgcExecutionReportCancel, ExecType.CANCELED, OrderStatus.CANCELED, bgcExecutionReportCancel.leavesQty());
    }

    private void bgcRejectSequence_sendOrderReceiveOrderReject() {
        final List<DefaultHeaderTrailer> bgcRejectSequence = dataGenerator.bgcRejectSequence();

        // send UM NewOrderSingle and BGC NewOrderSingle over fix
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle bgcNewOrderSingle = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle)bgcRejectSequence.get(0);
        sendUMNewOrderSingleAndBGCReceiveNewOrderSingle(bgcNewOrderSingle);

        // BGC reply with ExecutionReport New, Fill then Calculated. Receive over UM
        final ExecutionReport bgcExecutionReportReject = (ExecutionReport)bgcRejectSequence.get(1);
        sendExecutionReport(bgcNewOrderSingle.clOrdID(), bgcExecutionReportReject);
        waitForExecutionReportFromUM(bgcExecutionReportReject, ExecType.REJECTED, OrderStatus.REJECTED, 0.0);
    }

    private void stoppingAndLogoutOnDisconnect() {
        // trigger logoff
        application.stop();
        waitFor(Logout.class);
    }

    private NewOrderSingle sendUMNewOrderSingleAndBGCReceiveNewOrderSingle(final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle bgcNewOrderSingle) {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        // send NewOrderSingle
        final NewOrderSingle newOrderSingleUM = newOrderSingleUMMessage(clOrdId, bgcNewOrderSingle);
        LOGGER.info("Sending NewOrderSingle..." + newOrderSingleUM);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingleUM);

        // wait for BGC to receive NewOrderSingle
        LOGGER.info("Waiting for NewOrderSingle..." + newOrderSingleUM.body.symbol + " clOrdId=" + newOrderSingleUM.body.clOrdId);
        final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle receivedNewOrderSingle = (com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle)waitFor(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle.class);
        LOGGER.info("waitForNewOrderSingle Received: " + receivedNewOrderSingle);

        assertThat(receivedNewOrderSingle.clOrdID().toString(), is(newOrderSingleUM.body.clOrdId));
        assertThat(receivedNewOrderSingle.symbol(), is(SymbolNormaliser.toSymbol7(newOrderSingleUM.body.symbol)));
        assertThat(receivedNewOrderSingle.price(), is(1.0));
        assertThat(receivedNewOrderSingle.ordType(), is(OrdType.LIMIT));
        assertThat(receivedNewOrderSingle.side(), is(newOrderSingleUM.body.side == Side.SELL ? com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.SELL : com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.BUY));
        assertThat(receivedNewOrderSingle.orderQty(), is(newOrderSingleUM.body.orderQty));
        assertThat(receivedNewOrderSingle.timeInForce(), is(com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.TimeInForce.DAY));
        bgcReceiveQueue.clear();
        return newOrderSingleUM;
    }

    private NewOrderSingle newOrderSingleUMMessage(final String clOrdId, final com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.NewOrderSingle nos) {
        final InstrumentKey instrumentKey = InstrumentKey.of(SymbolNormaliser.toSymbol6(nos.symbol()), SecurityType.FXSPOT, Tenor.SP);

        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.senderCompId = "GB:lg-acc";
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.marketId = Venue.BGCMIDFX.name();
        newOrderSingle.body.ordType = OrderType.LIMIT;
        newOrderSingle.body.side = nos.side() == com.anz.axle.lg.adapter.bgc.chroniclefix.generated.fields.Side.SELL ? Side.SELL : Side.BUY;
        newOrderSingle.body.symbol = instrumentKey.symbol();
        newOrderSingle.body.securityType = instrumentKey.securityType();
        newOrderSingle.body.settlType = instrumentKey.tenor();
        newOrderSingle.body.price = nos.price();
        newOrderSingle.body.orderQty = nos.orderQty();
        newOrderSingle.body.timeInForce = TimeInForce.DAY;
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        return newOrderSingle;
    }

    private OrderCancelRequest orderCancelRequestUMMessage(final NewOrderSingle newOrderSingleUM) {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest();

        orderCancelRequest.body.senderCompId = "GB:lg-bgc";
        orderCancelRequest.body.clOrdId = clOrdId;
        orderCancelRequest.body.origClOrdId = newOrderSingleUM.body.clOrdId;
        orderCancelRequest.body.messageId = 1;
        orderCancelRequest.body.marketId = Venue.EBS.name();
        orderCancelRequest.body.ordType = newOrderSingleUM.body.ordType;
        orderCancelRequest.body.timeInForce = newOrderSingleUM.body.timeInForce;
        orderCancelRequest.body.side = newOrderSingleUM.body.side;
        orderCancelRequest.body.symbol = newOrderSingleUM.body.symbol;
        orderCancelRequest.body.securityType = newOrderSingleUM.body.securityType;
        orderCancelRequest.body.settlType = newOrderSingleUM.body.settlType;
        orderCancelRequest.body.orderQty = newOrderSingleUM.body.orderQty;
        orderCancelRequest.body.transactTime = acceptanceContext.precisionClock().nanos();
        return orderCancelRequest;
    }

    private ExecutionReport sendExecutionReport(final Bytes clOrdID, final ExecutionReport executionReport) {
        executionReport.clOrdID(executionReport.clOrdID_buffer());
        executionReport.clOrdID().append(clOrdID.toString());
        executionReport.sendingTime(TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis()));
        LOGGER.info("Sending BGC ExecutionReport.." + executionReport);
        serverSession.sendMessage(executionReport);
        return executionReport;
    }

    private com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport waitForExecutionReportFromUM(final ExecutionReport executionReport, final ExecType execType, final OrderStatus orderStatus, final Double leaveQty) {
        LOGGER.info("Waiting for ExecutionReport from UM..." + executionReport);
        System.out.println("Peak at queue: " + acceptanceContext.tradingResponseMessageQueue());
        return (com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport) Asserter.of(acceptanceContext.tradingResponseMessageQueue())
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(executionReport.clOrdID().toString()))
                        .body().matches(ExecutionReportMatcher.orderId().eq(executionReport.orderID().toString()))
                        .body().matches(ExecutionReportMatcher.marketId().eq(marketId.name()))
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-bgc"))
                        .body().matches(ExecutionReportMatcher.symbol().eq(toSymbol6(executionReport.symbol())))
                        .body().matches(ExecutionReportMatcher.execType().eq(execType))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus))
                        .body().matches(ExecutionReportMatcher.leavesQty().eq(leaveQty))
                        .body().matches(ExecutionReportMatcher.securityType().eq(SecurityType.FXSPOT))
                ).awaitMatchAndGetLast(20, TimeUnit.SECONDS);
    }

    @BeforeClass
    public static void beforeClass() {
        deleteAll();
    }
    @AfterClass
    public static void afterClass() {
        deleteAll();
    }

    private static void deleteAll() {
        IOTools.deleteDirWithFiles("target/bgc/");
    }

    private void startServerSide() throws Exception {
        cfg = Marshallable.fromFile("fix-bgc-acceptor.yaml");

        final FixSessionCfg sessionCfg = cfg.fixSessionCfgs().iterator().next();
        assertEquals(sessionCfg.name(), "SERVER");
        sessionCfg.fixVersion(FixVersion.V4_4);
        sessionCfg.fileStorePath(fixStorePath);
        sessionCfg.socketAcceptorHostPort(HOST + ":" + port);
        sessionCfg.targetCompID(TARGET_COMP_ID);
        sessionCfg.senderCompID(senderCompId);
        sessionCfg.messageNotifier(new BgcMessageNotifier());

        engine = new ChronicleFixEngine(sessionCfg);
        serverSession = engine.getHandler(SessionID.create(sessionCfg));
        tcpSession = new TcpSession(sessionCfg);

        bgcReceiveQueue = ((BgcMessageNotifier) serverSession.messageNotifier()).queue();
    }

    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass) {
        return waitFor(messageClass, "BGC Waiting for "+messageClass.getSimpleName()+"...");
    }
    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final String text) {
        return waitFor(messageClass, 60, text);
    }
    private StandardHeaderTrailer waitFor(final Class<? extends StandardHeaderTrailer> messageClass, final int timeout, final String text) {
        return waitFor(m -> messageClass.isInstance(m), timeout, text);
    }
    private StandardHeaderTrailer waitFor(final Predicate<? super Object> predicate, final int timeout, final String text) {
        return TestUtils.waitFor(bgcReceiveQueue, predicate, timeout, text);
    }
}
