package com.anz.axle.direct.performance;

import com.anz.axle.direct.performance.metrics.BasicStats;
import com.anz.axle.direct.performance.metrics.Count;
import com.anz.axle.direct.performance.metrics.Percentiles;
import com.anz.axle.direct.performance.metrics.Rates;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.NumberFormat;
import java.util.Collection;

public class TeamcityReporterFactory implements ReporterFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(TeamcityReporterFactory.class);

    private final NumberFormat numberFormat;

    public TeamcityReporterFactory() {
        numberFormat = NumberFormat.getNumberInstance();
        numberFormat.setGroupingUsed(false);
        numberFormat.setMaximumFractionDigits(2);
        numberFormat.setMinimumFractionDigits(2);
    }

    @Override
    public ProgressReporter createProgressReporter() {
        return new TeamcityProgressReporter();
    }

    @Override
    public MetricReporter createMetricReporter() {
        LOGGER.info("Creating " + TeamcityMetricReporter.class);
        return new TeamcityMetricReporter();
    }

    private static class TeamcityProgressReporter implements ProgressReporter {
        @Override
        public void beginTest(final String testName,
                              final Duration expectedDuration) {
            final long minutes = expectedDuration.getStandardMinutes();
            final Duration seconds = expectedDuration.minus(Duration.standardMinutes(minutes));
            final String duration = String.format("%s minutes and %s seconds", minutes, seconds.getStandardSeconds());
            System.out.println(Teamcity.progress("Running " + testName + " for " + duration));
        }

        @Override
        public void progress(final String testName,
                             final int step,
                             final int totalSteps) {
            System.out.println(Teamcity.progress(testName + " step " + step + "/" + totalSteps));
        }

        @Override
        public void completed(final String testName) {
            System.out.println(Teamcity.progress("Finished " + testName));
        }
    }

    private class TeamcityMetricReporter implements MetricReporter {

        @Override
        public void beginReports() {
        }

        @Override
        public void appendCounts(final Collection<Count> counters) {
            counters.forEach(this::appendCount);
        }

        private void appendCount(final Count count) {
            System.out.println(Teamcity.message("buildStatisticValue").prop("key", "counter." + count.getName()).prop("value", numberFormat.format(count.getCount())));
        }

        @Override
        public void appendBasicStats(final Collection<BasicStats> basicStatsList) {
            basicStatsList.forEach(this::appendBasicStat);
        }

        private void appendBasicStat(final BasicStats basicStats) {
            System.out.println(Teamcity.message("buildStatisticValue").prop("key", "gauge." + basicStats.getName()).prop("value", String.valueOf(basicStats.getMean())));
        }

        @Override
        public void appendHistograms(final Collection<Percentiles> percentilesList) {
            for (final Percentiles percentiles : percentilesList) {
                appendCount(percentiles);
                if (percentiles.getCount() > 0) {
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".min").prop("value", numberFormat.format(percentiles.getPercentile(0.0))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".50%").prop("value", numberFormat.format(percentiles.getPercentile(50.0))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".95%").prop("value", numberFormat.format(percentiles.getPercentile(95.0))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".98%").prop("value", numberFormat.format(percentiles.getPercentile(98.0))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".99%").prop("value", numberFormat.format(percentiles.getPercentile(99.0))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".99.9%").prop("value", numberFormat.format(percentiles.getPercentile(99.9))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".max").prop("value", numberFormat.format(percentiles.getPercentile(100.))));
                    System.out.println(Teamcity.message("buildStatisticValue").prop("key", "histogram." + percentiles.getName() + ".mean").prop("value", numberFormat.format(percentiles.getMean())));
                }
            }
        }

        @Override
        public void appendRates(final Collection<Rates> ratesList) {
            for (final Rates rates : ratesList) {
                System.out.println(Teamcity.message("buildStatisticValue").prop("key", "rate." + rates.getName() + ".mean").prop("value", numberFormat.format(rates.getMeanRate())));
                System.out.println(Teamcity.message("buildStatisticValue").prop("key", "rate." + rates.getName() + ".10sec").prop("value", numberFormat.format(rates.getTenSecondRate())));
                System.out.println(Teamcity.message("buildStatisticValue").prop("key", "rate." + rates.getName() + ".1min").prop("value", numberFormat.format(rates.getOneMinuteRate())));
                System.out.println(Teamcity.message("buildStatisticValue").prop("key", "rate." + rates.getName() + ".5min").prop("value", numberFormat.format(rates.getFiveMinuteRate())));
                System.out.println(Teamcity.message("buildStatisticValue").prop("key", "rate." + rates.getName() + ".15min").prop("value", numberFormat.format(rates.getFifteenMinuteRate())));
            }

        }

        @Override
        public void endReports() {
        }
    }
}
