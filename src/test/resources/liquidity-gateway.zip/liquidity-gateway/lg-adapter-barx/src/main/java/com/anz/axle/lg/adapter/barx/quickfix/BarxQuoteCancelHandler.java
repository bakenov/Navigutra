package com.anz.axle.lg.adapter.barx.quickfix;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.Message;
import quickfix.field.MsgSeqNum;
import quickfix.field.QuoteID;
import quickfix.field.QuoteReqID;
import quickfix.field.SendingTime;

import com.anz.axle.lg.adapter.barx.EntryIdPacking;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.IncrementalRefreshEncoder;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;


public final class BarxQuoteCancelHandler implements TypedFixMessageHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BarxQuoteCancelHandler.class);

    private final VenueRequestKeyLookup requestKeyLookup;
    private final PricingEncoderLookup pricingEncoderLookup;
    private final PrecisionClock precisionClock;
    private final SubscriptionManager subscriptionManager;
    private final String senderCompId;
    private final String compId;
    private final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender;
    private final SourceSequencer sourceSequencer;

    public BarxQuoteCancelHandler(final VenueRequestKeyLookup requestKeyLookup,
                                  final PricingEncoderLookup pricingEncoderLookup,
                                  final PrecisionClock precisionClock,
                                  final SubscriptionManager subscriptionManager,
                                  final String senderCompId,
                                  final String compId,
                                  final Consumer<EnumerableSetEncoder<IncrementalRefreshEncoder.Body, Flag>> flagsAppender,
 final SourceSequencer sourceSequencer) {
        this.requestKeyLookup = Objects.requireNonNull(requestKeyLookup);
        this.pricingEncoderLookup = Objects.requireNonNull(pricingEncoderLookup);
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.subscriptionManager = Objects.requireNonNull(subscriptionManager);
        this.senderCompId = Objects.requireNonNull(senderCompId);
        this.compId = Objects.requireNonNull(compId);
        this.flagsAppender = Objects.requireNonNull(flagsAppender);
        this.sourceSequencer = Objects.requireNonNull(sourceSequencer);
    }

    @Override
    public MessageType messageType() {
        return MessageType.MD_QUOTE_CANCEL;
    }

    @Override
    public void accept(final Message message) throws FieldNotFound {
        final long receivingTimeNanos = precisionClock.nanos();
        LOGGER.info("QuoteCancel received: {}", message);
        final int quoteRequestId = message.getInt(QuoteReqID.FIELD);
        final int sequenceNumber = message.getHeader().getInt(MsgSeqNum.FIELD);
        final long messageId = sequenceNumber;
        final Date sendingTime = message.getHeader().getUtcTimeStamp(SendingTime.FIELD);
        final long sendingTimeNanos = TimeUnit.MILLISECONDS.toNanos(sendingTime.getTime());

        final MarketDataSubscription subscription = subscriptionManager.lookupByRequestId(quoteRequestId);
        final RequestKey requestKey = requestKeyLookup.lookup(subscription.instrumentKey());
        final IncrementalRefreshEncoder.Body encoder = pricingEncoderLookup.lookup(requestKey).incrementalRefresh().messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence());
        flagsAppender.accept(encoder.mdFlags());

        clearQuoteIds(message, subscription);

        final IncrementalRefreshEncoder.Body mdEntries = encoder
                .marketId(requestKey.market())
                .instrumentId(requestKey.instrumentKey().instrumentId())
                .senderCompId().encode(compId)
                .messageId(messageId)
                .sendingTime(sendingTimeNanos)
                .referenceSpotDate().encodeNull()
                .tradeDate().encodeNull()
                .settlDate().encodeNull();

        final IncrementalRefreshEncoder.MdEntries.Next mdEntriesNext = mdEntries.entriesStart(2);
        cancelPriceBand(mdEntriesNext, sendingTimeNanos, (int) subscription.orderQty());

        mdEntriesNext.entriesComplete()
            .hopsStart(2)
                .next()
                    .hopCompId().encode(senderCompId)
                    .hopMessageId(sequenceNumber)
                    .hopSendingTime(sendingTimeNanos)
                .next()
                    .hopCompId().encode(compId)
                    .hopMessageId(messageId)
                    .hopReceivingTime(receivingTimeNanos)
                    .hopSendingTime(precisionClock.nanos())
            .hopsComplete()
        .messageComplete();
    }

    private void cancelPriceBand(IncrementalRefreshEncoder.MdEntries.Next mdEntriesNext, final long sendingTimeNanos, final int priceBand) {

        mdEntriesNext.next()
            .mdUpdateAction(UpdateAction.DELETE)
            .transactTime(sendingTimeNanos)
            .mdEntryType(EntryType.BID)
            .mdEntrySize((double)priceBand)
            .mdEntryId(EntryIdPacking.toId(EntryType.BID, priceBand))
            .mdEntryRefId(0)
            .quoteEntryId(0);

        mdEntriesNext.next()
            .mdUpdateAction(UpdateAction.DELETE)
            .transactTime(sendingTimeNanos)
            .mdEntryType(EntryType.OFFER)
            .mdEntrySize((double)priceBand)
            .mdEntryId(EntryIdPacking.toId(EntryType.OFFER, priceBand))
            .mdEntryRefId(0)
            .quoteEntryId(0);
    }

    private void clearQuoteIds(final Message message, final MarketDataSubscription subscription) {
        try {
            final String quoteId = message.getString(QuoteID.FIELD);
            if ("*".equals(quoteId)) {
                subscription.stringToIntCache().clear();
            }
        } catch (FieldNotFound fieldNotFound) {
            //no op
        }
    }
}
