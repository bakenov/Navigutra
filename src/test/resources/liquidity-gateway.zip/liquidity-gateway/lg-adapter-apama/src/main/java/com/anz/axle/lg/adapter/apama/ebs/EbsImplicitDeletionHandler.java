package com.anz.axle.lg.adapter.apama.ebs;

import java.util.Objects;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.snapshot.change.EntriesChangedListener;
import com.anz.markets.efx.pricing.codec.snapshot.snapshotter.BeforeBookChangeCompleteHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataBook;
import com.anz.markets.efx.pricing.codec.snapshot.state.MarketDataEntries;
import com.anz.markets.efx.pricing.codec.snapshot.state.Side;

public final class EbsImplicitDeletionHandler implements BeforeBookChangeCompleteHandler {

    private final EbsBookRules ebsBookRules;
    private final PrecisionClock precisionClock;


    public EbsImplicitDeletionHandler(final PrecisionClock precisionClock, final EbsBookRules ebsBookRules) {
        this.ebsBookRules = Objects.requireNonNull(ebsBookRules);
        this.precisionClock = Objects.requireNonNull(precisionClock);
    }

    @Override
    public void beforeBookChangeComplete(final MarketDataBook marketDataBook, final EntriesChangedListener entriesChangedListener) {
        final EbsBookRules.Config config = ebsBookRules.configFor(marketDataBook.requestKey().instrumentKey().symbol(), marketDataBook.requestKey().instrumentKey().securityType());
        processImplicitDeletions(config, marketDataBook.bids(), entriesChangedListener, Side.BID);
        processImplicitDeletions(config, marketDataBook.asks(), entriesChangedListener, Side.ASK);
    }

    private void processImplicitDeletions(final EbsBookRules.Config config,
                                          final MarketDataEntries entries,
                                          final EntriesChangedListener entriesChangedListener,
                                          final Side side) {
        if (entries.size() > 1) {
            final double bestPrice = entries.get(0).price();
            final double cutOff = config.priceRangeSteps() * config.priceRangeIncrement() - 1.0e-10; //see FIX_EBS_Support.mon
            final double cutOffPrice = side == Side.BID ? (bestPrice - cutOff) : (bestPrice + cutOff);
            final int depth = config.depth();
            final long removeTimeNanos = precisionClock.nanos();
            for (int level = entries.size() - 1; level >= 1; level--) {
                if (level >= depth || isPriceCutOff(entries, level, cutOffPrice, side)) {
                    entries.remove(level, removeTimeNanos, entriesChangedListener);
                }//else: NOTE: if we assume a price-sorted book we could stop here
            }
        }
    }

    private static boolean isPriceCutOff(final MarketDataEntries entries, final int index, final double cutOffPrice, final Side side) {
        final double price = entries.get(index).price();
        return side == Side.BID ? price <= cutOffPrice : price >= cutOffPrice;
    }
}
