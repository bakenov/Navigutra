package com.anz.axle.lg.adapter.apama.transport;

import java.util.function.Function;
import java.util.function.Supplier;

import com.apama.engine.beans.interfaces.EngineClientInterface;
import com.apama.services.event.IEventService;
import com.apama.services.event.IEventServiceChannel;
import com.apama.util.CompoundException;

public class ApamaTransport implements Transport {
    private final Supplier<EngineClientInterface> engineClientFactory;
    private final Function<EngineClientInterface, IEventService> eventServiceFactory;

    public ApamaTransport(final Supplier<EngineClientInterface> engineClientFactory, final Function<EngineClientInterface, IEventService> eventServiceFactory) {
        this.engineClientFactory = engineClientFactory;
        this.eventServiceFactory = eventServiceFactory;
    }

    @Override
    public Connection openConnection(final ConnectionConfig connectionConfig, final ConnectionStatusHandler connectionStatusHandler) {
        final EngineClientInterface engineClient = engineClientFactory.get();
        try {
            engineClient.setHost(connectionConfig.host());
            engineClient.setPort(connectionConfig.port());
            engineClient.setProcessName(connectionConfig.venue().name());
            engineClient.setConnectionPollingInterval(connectionConfig.connectionPollingInterval());
            engineClient.connectInBackground();
        } catch (CompoundException  e) {
            throw new RuntimeException("Failed to configure engineClient", e);
        }

        final IEventService eventService = eventServiceFactory.apply(engineClient);
        final IEventServiceChannel serviceChannel = eventService.addChannel(connectionConfig.channelName(), connectionConfig.channelConfig());

        return new ApamaConnection(engineClient, eventService, serviceChannel, connectionStatusHandler, connectionConfig);
    }
}
