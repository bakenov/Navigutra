package com.anz.markets.efx.fox.processor.event;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.fox.processor.state.ChildOrderRepository;
import com.anz.markets.efx.fox.api.domain.ChildOrder;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.ExecutionReportSbeDecoder;

public class ChildExecutionReportEvent implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChildExecutionReportEvent.class);

    private final PrecisionClock precisionClock;
    private final ChildOrderRepository childOrderRepository;

    private final ExecutionReportSbeDecoder executionReportDecoder = new ExecutionReportSbeDecoder();

    private final StringBuilder stringBuilder = new StringBuilder();
    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    public ChildExecutionReportEvent(final PrecisionClock precisionClock,
                                     final ChildOrderRepository childOrderRepository) {
        this.precisionClock = Objects.requireNonNull(precisionClock);
        this.childOrderRepository = Objects.requireNonNull(childOrderRepository);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        executionReportDecoder.wrap(message);

        final String marketId = executionReportDecoder.body().marketId().decodeAndCache(marketIdCache);
        if (!Venue.FOX.name().equals(marketId)) {
            logMessage();

            final long childOrigClOrdId = executionReportDecoder.body().origClOrdId().decodeLongOrZero();

            final ChildOrder childOrder;
            if (childOrigClOrdId > 0) {
                childOrder = childOrderRepository.lookupByClOrdId(childOrigClOrdId);
            } else {
                throw new IllegalStateException("ExecutionReport must provide clOrdId");
            }

            childOrder.applyExecutionReport(executionReportDecoder);
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        executionReportDecoder.appendTo(stringBuilder);
        LOGGER.info("Applying child ER: {}", stringBuilder);
    }
}
