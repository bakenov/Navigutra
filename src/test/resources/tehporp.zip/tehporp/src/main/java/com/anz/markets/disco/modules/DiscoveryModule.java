package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.config.DiscoPFPConfig;
import com.anz.markets.disco.config.JamDetectorPFPConfig;
import com.anz.markets.disco.data.MutableSignals;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.data.Signals;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.marketdata.MarketDataNewOrder;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.domain.time.TradingTimeZoneChime;
import com.anz.markets.prophet.marketdata.adjustment.TOBVWAPMarketDataAdjustment;
import com.anz.markets.prophet.pricer.pfp.cache.Markets;
import com.anz.markets.prophet.status.Context;
import org.apache.commons.lang3.mutable.MutableObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.PriorityQueue;

public class DiscoveryModule extends AbstractModule {

    private final Logger logger = LoggerFactory.getLogger(DiscoveryModule.class);

    public static final Symbol SIGNALS_MESSAGE_SYMBOL = MessageBus.getMessageType(Signals.class);

    private static class VenueConfig {
        final EnumObjMap<TradingTimeZone, VenueTimezoneConfig> configs = new EnumObjMap<>(TradingTimeZone.class);
        long latencyThreshold;

        public long getStaleThreshold() {
            final VenueTimezoneConfig venueTimezoneConfig = configs.get(Context.context().tradingTimeZone());
            if (venueTimezoneConfig == null) {
                return 0;
            } else {
                return venueTimezoneConfig.staleThreshold;
            }
        }

        public double getMinQty() {
            final VenueTimezoneConfig venueTimezoneConfig = configs.get(Context.context().tradingTimeZone());
            if (venueTimezoneConfig == null) {
                return Double.MAX_VALUE;
            } else {
                return venueTimezoneConfig.minQty;
            }
        }

    }

    private static class VenueTimezoneConfig {
        double minQty;
        long staleThreshold;
    }

    private static class DiscoConfig {
        Markets clusterConstituents[];
        Markets protectionConstituents[];
        TwoPriceMode twoPriceMode;
    }

    public enum TwoPriceMode {
        BEST, WORST, MEAN;
    }

    public static final int MAX_VENUE_STATE = Market.VALUES.length * Instrument.VALUES.length;

    /**
     * A constituent is a single market or the TOB of a set of markets.
     */
    private class Constituent {

        final VenueState[] components;

        public Constituent(final VenueState components[]) {
            this.components = components;
        }

        public double getFilteredPrice(final long t, final OrderSide side, final StringBuilder cc) {
            if (components.length == 1) {
                return components[0].getFilteredPrice(t, side, cc);
            } else {
                cc.append("(");
                double bestPrice = Double.NaN;
                for (int i = 0; i < components.length; i++) {
                    final double price = components[i].getFilteredPrice(t, side, cc);
                    if (side.isBuy()) {
                        if (Double.isNaN(bestPrice) || price > bestPrice) {
                            bestPrice = price;
                        }
                    } else {
                        if (Double.isNaN(bestPrice) || price < bestPrice) {
                            bestPrice = price;
                        }
                    }
                }
                cc.append(")");
                return bestPrice;
            }
        }

    }

    private class VenueState {

        final Market market;
        final Instrument instrument;

        final VenueConfig venueConfig = new VenueConfig();
        double priceChangeEpsilon;

        long venueTime;
        long receivedTime;
        boolean isLatent;
        boolean bidJammed;
        boolean askJammed;
        double notionalBid = Double.NaN;
        double notionalAsk = Double.NaN;

        long queuedStaleCheckTime;

        public VenueState(final Market market, final Instrument instrument) {
            this.market = market;
            this.instrument = instrument;
        }

        public boolean priceChanged(double p1, double p2) {
            return (Double.isNaN(p1) ^ Double.isNaN(p2)) || Math.abs(p1 - p2) >= priceChangeEpsilon;
        }

        public boolean isStale() {
            return Context.context().timeSource().nowNanos() - venueTime >= venueConfig.getStaleThreshold();
        }

        public void queueStaleCheckIfNotAlreadyQueued() {
            if (queuedStaleCheckTime == 0) {
                queuedStaleCheckTime = venueTime + venueConfig.getStaleThreshold();
                if (staleCheckQueue.size() < MAX_VENUE_STATE) {  // <- infinite queue prevention.
                    staleCheckQueue.add(this);
                } else {
                    // logic error - we must be adding more than one due to a bug.
                    logger.warn("Logic error - maximum queue size exceeded.  Stale check cannot be queued for {} {}", market, instrument);
                }
            }
        }

        public long getLatencyThreshold() {
            return venueConfig.latencyThreshold;
        }

        public double getFilteredPrice(final long t, final OrderSide side, final StringBuilder cc) {
            final double price = side.isBuy() ? notionalBid : notionalAsk;
            final boolean jammed = side.isBuy() ? bidJammed : askJammed;
            if (jammed) {
                cc.append("J");
            } else if (isLatent) {
                cc.append("L");
            } else if (price > 0) {
                final boolean isStale = t - venueTime >= venueConfig.getStaleThreshold();
                if (isStale) {
                    cc.append("S");
                } else {
                    cc.append("C");
                    return price;
                }
            } else {
                cc.append("X");
            }
            return Double.NaN;
        }

    }

    public static class DiscoState {
        final MutableSignals signals;

        double preProtectionClusterBid, preProtectionClusterAsk;
        Symbol preProtectionClusterBidCC, preProtectionClusterAskCC;
        double maxProtectionBid, minProtectionAsk;
        Symbol maxProtectionBidCC, minProtectionAskCC;
        double clusterBid, clusterAsk;

        public DiscoState(final Market discoMarket, final Instrument instrument) {
            signals = new MutableSignals(discoMarket, instrument);
        }
    }

    private static class DiscoTtzState {
        final DiscoConfig config;
        final Constituent clusterConstituents[];
        final Constituent protectionConstituents[];

        final DiscoState discoState;  // shared timezone independent state.

        public DiscoTtzState(final DiscoConfig config, final Constituent clusterConstituents[], final Constituent protectionConstituents[], final Market discoMarket, final Instrument instrument,
                             DiscoState discoState) {
            this.config = config;
            this.clusterConstituents = clusterConstituents;
            this.protectionConstituents = protectionConstituents;
            this.discoState = discoState;
        }
    }

    private static class ComputationTrigger {
        DiscoTtzState discoTtzState;
        boolean clusterConstituent;        // The trigger is a cluster constituent.
        boolean protectionConstituent;     // The trigger is a protection constituent.
    }

    public interface DerivedSignal {
        void populate(DiscoState state);
    }

    private final EnumObjTable<Market, Instrument, VenueState> venueStateCache = new EnumObjTable<>(Market.class, Instrument.class);
    private final EnumObjTable<Market, Instrument, EnumObjMap<TradingTimeZone, List<ComputationTrigger>>> inputTriggers = new EnumObjTable<>(Market.class, Instrument.class);

    private final Comparator<? super VenueState> staleCheckQueueComparator = (o1, o2) -> Long.compare(o1.queuedStaleCheckTime, o2.queuedStaleCheckTime);
    private final PriorityQueue<VenueState> staleCheckQueue = new PriorityQueue<>(1000, staleCheckQueueComparator);

    private final ClusterCalculatorV1 clusterCalculator = new ClusterCalculatorV1();
    private final StringBuilder ccs = new StringBuilder(100);

    private final List<DerivedSignal> derivedSignals = new ArrayList<>();

    private final JamDetector jamDetector = new JamDetector(jamSideState -> {
        // Transition to JAMMED state detected - trigger recalculations.
        final VenueState venueState = venueStateCache.get(jamSideState.jamState.market, jamSideState.jamState.instrument);
        if (venueState != null) {
            venueState.bidJammed = jamSideState.jamState.bidJammed();
            venueState.askJammed = jamSideState.jamState.askJammed();
            triggerCalculations(0, 0, venueState, true, true);
        }
    });

    public void addDerivedSignal(DerivedSignal derivedSignal) {
        derivedSignals.add(derivedSignal);
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.sub(this::consumeConfig, IndexedConfigurationData.class);
        messageBus.sub(this::consumeSnap, MarketDataSnapshot.class);
        messageBus.sub(this::consumeOneSecond, OneSecond.class);
        messageBus.sub(this::consumeTradingTimeZoneChime, TradingTimeZoneChime.class);
    }

    private void consumeConfig(IndexedConfigurationData config) {
        clearConfigState();
        try {
            setupConfig(config);
        } catch (Exception e) {
            clearConfigState();
            throw e;
        }
    }

    private void clearConfigState() {
        // venueStateCache.clear();  // retain across config changes
        // staleCheckQueue.clear();  // retain across config changes

        // Clear and rebuild triggers.
        inputTriggers.forEach((market, instrument, t1) -> t1.forEach((ttz, t2) -> t2.clear()));
    }

    private void consumeTradingTimeZoneChime(final TradingTimeZoneChime tradingTimeZoneChime) {
        inputTriggers.forEach((market, instrument, m) -> {
            final VenueState venueState = venueStateCache.get(market, instrument);
            triggerCalculations(0, 0, venueState, true, true);
        });
    }

    private void consumeOneSecond(final OneSecond oneSecond) {
        final long t = Context.context().timeSource().nowNanos();
        while (staleCheckQueue.size() > 0 && t >= staleCheckQueue.peek().queuedStaleCheckTime) {
            final VenueState venueState = staleCheckQueue.poll();
            venueState.queuedStaleCheckTime = 0;
            if (venueState.isStale()) {
                triggerCalculations(0, 0, venueState, true, true);
            } else {
                venueState.queueStaleCheckIfNotAlreadyQueued();
            }
        }
    }

    private void consumeSnap(final MarketDataSnapshot snap) {

        final List<ComputationTrigger> triggered = getTriggeredComputations(snap.getMarket(), snap.getInstrument());
        if (triggered.size() == 0) {
            // Don't proceed if venue data not used.
            return;
        }

        final VenueState venueState = venueStateCache.get(snap.getMarket(), snap.getInstrument());
        GcFriendlyAssert.notNull(venueState, "Logic error, venue state must exist %s %s", snap.getMarket(), snap.getInstrument());

        final long t = Context.context().timeSource().nowNanos();
        final double oldNotionalBid = venueState.notionalBid;
        final double oldNotionalAsk = venueState.notionalAsk;
        final boolean oldBidJammed = venueState.bidJammed;
        final boolean oldAskJammed = venueState.askJammed;
        final boolean oldIsLatent = venueState.isLatent;
        final boolean oldIsStale = venueState.isStale();
        venueState.venueTime = snap.getExternalEventTimeNS();
        venueState.receivedTime = t;
        venueState.isLatent = Math.abs(venueState.venueTime - venueState.receivedTime) > venueState.getLatencyThreshold();

        if (venueState.isLatent) {
            venueState.notionalBid = Double.NaN;
            venueState.notionalAsk = Double.NaN;
            venueState.bidJammed = false;
            venueState.askJammed = false;
        } else {
            venueState.notionalBid = getNotionalL1(snap.getBidEventList(), venueState.venueConfig);
            venueState.notionalAsk = getNotionalL1(snap.getOfferEventList(), venueState.venueConfig);
            venueState.queueStaleCheckIfNotAlreadyQueued();

            final JamDetector.JamState jamState = jamDetector.addSnapshot(t,snap.getMarket(),snap.getInstrument(),snap.getTopOfBookBid().getPrice(),snap.getTopOfBookOffer().getPrice());
            venueState.bidJammed = jamState.bidJammed();
            venueState.askJammed = jamState.askJammed();
        }

        final boolean stateChanged = (oldIsLatent ^ venueState.isLatent) || (oldIsStale ^ venueState.isStale()) || (oldBidJammed ^ venueState.bidJammed) || (oldAskJammed ^ venueState.askJammed);
        final boolean triggerBidCalculations = venueState.priceChanged(oldNotionalBid, venueState.notionalBid) || stateChanged;
        final boolean triggerAskCalculations = venueState.priceChanged(oldNotionalAsk, venueState.notionalAsk) || stateChanged;

        if (triggerBidCalculations || triggerAskCalculations) {
            triggerCalculations(snap.getExternalEventTimeNS(), snap.getExternalSourceId(), venueState, triggerBidCalculations, triggerAskCalculations);
        }
    }

    private List<ComputationTrigger> getTriggeredComputations(final Market market, final Instrument instrument) {
        final EnumObjMap<TradingTimeZone, List<ComputationTrigger>> triggeredByTimezone = inputTriggers.get(market, instrument);
        if (triggeredByTimezone == null) {
            return Collections.EMPTY_LIST;
        }
        return triggeredByTimezone.computeIfAbsent(Context.context().tradingTimeZone(), tradingTimeZone -> new ArrayList<>(0));
    }

    private void triggerCalculations(final long externalEventTimeNS, final long externalSourceId, final VenueState venueState, final boolean triggerBidCalculations, final boolean triggerAskCalculations) {
        final List<ComputationTrigger> triggered = getTriggeredComputations(venueState.market, venueState.instrument);
        for (int i = 0; i < triggered.size(); i++) {
            final ComputationTrigger trigger = triggered.get(i);
            reviseDiscoState(externalEventTimeNS, externalSourceId, venueState, trigger, triggerBidCalculations, triggerAskCalculations);
        }
    }

    private void reviseDiscoState(final long externalEventTimeNS, final long externalSourceId, final VenueState triggerVenueState, final ComputationTrigger trigger, final boolean triggerBidCalculations, final boolean triggerAskCalculations) {

        final DiscoTtzState discoTtzState = trigger.discoTtzState;

        final MutableSignals signals = discoTtzState.discoState.signals;
        signals.clear();

        boolean needToRecalculate = false;

        if ((trigger.clusterConstituent && triggerBidCalculations) || discoTtzState.discoState.preProtectionClusterBidCC == null) {
            ccs.setLength(0);
            final double newClusterBid = aggregatePrice(discoTtzState, OrderSide.BID, ccs);
            final Symbol ccsSymbol = Symbol.get(ccs);
            if (triggerVenueState.priceChanged(newClusterBid, discoTtzState.discoState.preProtectionClusterBid) || ccsSymbol != discoTtzState.discoState.preProtectionClusterBidCC) {
                discoTtzState.discoState.preProtectionClusterBid = newClusterBid;
                discoTtzState.discoState.preProtectionClusterBidCC = ccsSymbol;
                needToRecalculate |= true;
            }
        }
        if ((trigger.clusterConstituent && triggerAskCalculations) || discoTtzState.discoState.preProtectionClusterAskCC == null) {
            ccs.setLength(0);
            final double newClusterAsk = aggregatePrice(discoTtzState, OrderSide.OFFER, ccs);
            final Symbol ccsSymbol = Symbol.get(ccs);
            if (triggerVenueState.priceChanged(newClusterAsk, discoTtzState.discoState.preProtectionClusterAsk) || ccsSymbol != discoTtzState.discoState.preProtectionClusterAskCC) {
                discoTtzState.discoState.preProtectionClusterAsk = newClusterAsk;
                discoTtzState.discoState.preProtectionClusterAskCC = ccsSymbol;
                needToRecalculate |= true;
            }
        }

        if ((trigger.protectionConstituent && triggerBidCalculations) || discoTtzState.discoState.maxProtectionBidCC == null) {
            ccs.setLength(0);
            final double newMaxProtectionBid = protectionPrice(discoTtzState, OrderSide.BID, ccs);
            final Symbol ccsSymbol = Symbol.get(ccs);
            if (triggerVenueState.priceChanged(newMaxProtectionBid, discoTtzState.discoState.maxProtectionBid) || ccsSymbol != discoTtzState.discoState.maxProtectionBidCC) {
                discoTtzState.discoState.maxProtectionBid = newMaxProtectionBid;
                discoTtzState.discoState.maxProtectionBidCC = ccsSymbol;
                needToRecalculate |= true;
            }
        }
        if ((trigger.protectionConstituent && triggerAskCalculations) || discoTtzState.discoState.minProtectionAskCC == null) {
            ccs.setLength(0);
            final double newMinProtectionAsk = protectionPrice(discoTtzState, OrderSide.OFFER, ccs);
            final Symbol ccsSymbol = Symbol.get(ccs);
            if (triggerVenueState.priceChanged(newMinProtectionAsk, discoTtzState.discoState.minProtectionAsk) || ccsSymbol != discoTtzState.discoState.minProtectionAskCC) {
                discoTtzState.discoState.minProtectionAsk = newMinProtectionAsk;
                discoTtzState.discoState.minProtectionAskCC = ccsSymbol;
                needToRecalculate |= true;
            }
        }

        if (needToRecalculate) {
            final double clusterMid = 0.5 * (discoTtzState.discoState.preProtectionClusterBid + discoTtzState.discoState.preProtectionClusterAsk);

            final double protectionBid = discoTtzState.discoState.minProtectionAsk - 0.5 * (clusterMid - discoTtzState.discoState.minProtectionAsk);
            final double protectionAsk = discoTtzState.discoState.maxProtectionBid + 0.5 * (discoTtzState.discoState.maxProtectionBid - clusterMid);

            double finalBid = discoTtzState.discoState.preProtectionClusterBid;
            boolean protectedBid = false;
            if (protectionBid > 0 && protectionBid < finalBid) {
                // Note: if pre protection bid is NaN and protection bid is not NaN we want our final bid
                // to be NaN because we don't know how tight the resulting protection spread will be.  Hence we don't enter this block of code.
                //
                // Only check if we have a protection bid - if not continue with unprotected cluster price.
                finalBid = protectionBid;
                protectedBid = true;
            }
            double finalAsk = discoTtzState.discoState.preProtectionClusterAsk;
            boolean protectedAsk = false;
            if (protectionAsk > 0 && protectionAsk > finalAsk) {
                // See notes above for bid.
                finalAsk = protectionAsk;
                protectedAsk = true;
            }

            if (triggerVenueState.priceChanged(finalBid, discoTtzState.discoState.clusterBid)) {
                ccs.setLength(0);
                ccs.append(discoTtzState.discoState.preProtectionClusterBidCC);
                ccs.append("_");
                ccs.append(discoTtzState.discoState.minProtectionAskCC);  // yes, ASK
                ccs.append("_");
                ccs.append(protectedBid ? (Double.isNaN(protectionBid) ? "X" : "P") : "C");
                final Symbol ccsSymbol = Symbol.get(ccs);
                signals.add(SignalType.CBID, finalBid, ccsSymbol);
                discoTtzState.discoState.clusterBid = finalBid;
            }

            if (triggerVenueState.priceChanged(finalAsk, discoTtzState.discoState.clusterAsk)) {
                ccs.setLength(0);
                ccs.append(discoTtzState.discoState.preProtectionClusterAskCC);
                ccs.append("_");
                ccs.append(discoTtzState.discoState.maxProtectionBidCC);  // yes, BID
                ccs.append("_");
                ccs.append(protectedAsk ? (Double.isNaN(protectionAsk) ? "X" : "P") : "C");
                final Symbol ccsSymbol = Symbol.get(ccs);
                signals.add(SignalType.CASK, finalAsk, ccsSymbol);
                discoTtzState.discoState.clusterAsk = finalAsk;
            }
        }

        if (signals.getSize() > 0) {
            signals.setExternalEventTimeNS(externalEventTimeNS);
            signals.setExternalSourceId(externalSourceId);
            signals.setSignalsId(Context.context().idGenerator().incrementAndGetId());
            for (int i = 0; i < derivedSignals.size(); i++) {
                derivedSignals.get(i).populate(discoTtzState.discoState);
            }
            getStage().getMessageBus().pub(SIGNALS_MESSAGE_SYMBOL, signals);
        }
    }

    public static class ClusterCalculatorV1 {

        private final ConstituentPrice prices[] = new ConstituentPrice[100];

        private int n;

        public class ConstituentPrice {
            double price;
            int ccStartIdx;
            int ccEndIdx;
        }

        private final Comparator<ConstituentPrice> constituentPriceComparator = Comparator.comparingDouble(x -> x.price);

        public ClusterCalculatorV1() {
            for (int i = 0; i < prices.length; i++) {
                prices[i] = new ConstituentPrice();
            }
        }

        public void reset() {
            n = 0;
        }

        public void add(double price, int ccStartIdx, int ccEndIdx) {
            GcFriendlyAssert.isTrue(price > 0);
            prices[n].price = price;
            prices[n].ccStartIdx = ccStartIdx;
            prices[n].ccEndIdx = ccEndIdx;
            n++;
        }

        public int getSize() {
            return n;
        }

        // Note: side-effect - this operation can sort prices
        public double calculate(final OrderSide side, final TwoPriceMode mode, MutableObject<ConstituentPrice> removedConstituent) {
            removedConstituent.setValue(null);
            if (n == 0) {
                return Double.NaN;
            } else if (n == 1) {
                return prices[0].price;
            } else if (n == 2) {
                switch (mode) {
                    case BEST:
                        return side.isBuy() ? Math.max(prices[0].price, prices[1].price) : Math.min(prices[0].price, prices[1].price);
                    case WORST:
                        return side.isBuy() ? Math.min(prices[0].price, prices[1].price) : Math.max(prices[0].price, prices[1].price);
                    case MEAN:
                        return 0.5 * (prices[0].price + prices[1].price);
                    default:
                        throw new RuntimeException("Unknown mode.");
                }
            } else {
                Arrays.sort(prices, 0, n, constituentPriceComparator);
                int startIdx = 0;
                int endIdx = n - 1;
                final double delta = Math.abs(prices[0].price - prices[n - 2].price) - Math.abs(prices[1].price - prices[n - 1].price);
                if (delta > 0) {
                    removedConstituent.setValue(prices[startIdx]);
                    startIdx++;
                } else if (delta < 0) {
                    removedConstituent.setValue(prices[endIdx]);
                    endIdx--;
                } else {
                    // Don't remove either on equality.
                }
                double sum = 0;
                for (int i = startIdx; i <= endIdx; i++) {
                    sum += prices[i].price;
                }
                return sum / (endIdx - startIdx + 1);
            }
        }

        public double min() {
            if (n == 0) {
                return Double.NaN;
            }
            double x = prices[0].price;
            for (int i = 1; i < n; i++) {
                if (prices[i].price < x) {
                    x = prices[i].price;
                }
            }
            return x;
        }

        public double max() {
            if (n == 0) {
                return Double.NaN;
            }
            double x = prices[0].price;
            for (int i = 1; i < n; i++) {
                if (prices[i].price > x) {
                    x = prices[i].price;
                }
            }
            return x;
        }

    }

    private final MutableObject<ClusterCalculatorV1.ConstituentPrice> removedConstituent = new MutableObject<>();

    private double aggregatePrice(final DiscoTtzState state, final OrderSide side, final StringBuilder ccs) {
        filterVenues(state.clusterConstituents, side, ccs);
        final double price = clusterCalculator.calculate(side, state.config.twoPriceMode, removedConstituent);
        if (removedConstituent.getValue() != null) {
            for (int i = removedConstituent.getValue().ccStartIdx; i <= removedConstituent.getValue().ccEndIdx; i++) {
                ccs.setCharAt(i, '#');
            }
        }
        return price;
    }

    private double protectionPrice(final DiscoTtzState state, final OrderSide side, final StringBuilder ccs) {
        filterVenues(state.protectionConstituents, side, ccs);
        return side.isBuy() ? clusterCalculator.max() : clusterCalculator.min();
    }

    /**
     * Condition code key:
     * <pre>
     * X: invalid/indicative price
     * S: stale
     * L: latent
     * C: candidate
     * </pre>
     */
    private void filterVenues(final Constituent constituents[], final OrderSide side, final StringBuilder ccs) {
        final long t = Context.context().timeSource().nowNanos();
        clusterCalculator.reset();
        for (int i = 0; i < constituents.length; i++) {
            final Constituent constituent = constituents[i];
            final double price = constituent.getFilteredPrice(t, side, ccs);
            if (price > 0) {
                if (constituent.components.length > 1) {
                    clusterCalculator.add(price, ccs.length() - constituent.components.length - 1, ccs.length() - 2);
                } else {
                    clusterCalculator.add(price, ccs.length() - 1, ccs.length() - 1);
                }
            }
        }
    }


    private double getNotionalL1(final List<MarketDataNewOrder> orders, final VenueConfig venueConfig) {
        if (orders.size() == 0) {
            return Double.NaN;
        }
        final double minQty = venueConfig.getMinQty();
        double cum = 0;
        for (int i = 0; i < orders.size(); i++) {
            final MarketDataNewOrder order = orders.get(i);
            if (order.getPrice() > 0 && !order.isIndicative()) {
                cum += order.getQuantity();
                if (cum >= minQty) {
                    return order.getPrice();
                }
            } else {
                if (i == 0) {
                    return Double.NaN;  // if first order is bad - fail-fast.
                }
            }
        }
        return Double.NaN;
    }

    private void setupConfig(final IndexedConfigurationData config) {

        final JamDetectorPFPConfig jamDetectorPFPConfig = new JamDetectorPFPConfig(config.getPriceFormationPipelineConfigs());
        jamDetector.resetConfig();
        jamDetectorPFPConfig.getConfig().forEach((market, instrument, c) -> jamDetector.addConfig(market,instrument, c.tickCount, c.timePeriodNanos));

        final DiscoPFPConfig discoPFPConfig = new DiscoPFPConfig(config.getPriceFormationPipelineConfigs());
        final EnumObjTable<Market, Instrument, DiscoState> globalState = new EnumObjTable<>(Market.class, Instrument.class);
        for (Market discoMarket : Market.VALUES) {
            if (discoMarket.isInternalAgg()) {
                for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                    final EnumMap<Instrument, DiscoPFPConfig.DiscoPFPRowConfig> rows = discoPFPConfig.getConfig().get(discoMarket, ttz);
                    if (rows != null) {
                        rows.forEach((instrument, discoPFPRowConfig) -> {

                            final DiscoConfig discoConfig = new DiscoConfig();
                            discoConfig.clusterConstituents = discoPFPRowConfig.constituents;
                            discoConfig.protectionConstituents = discoPFPRowConfig.protection;
                            discoConfig.twoPriceMode = discoPFPRowConfig.twoPriceMode;

                            final Constituent clusterConstituents[] = createConstituents(config, instrument, discoConfig.clusterConstituents);
                            final Constituent protectionConstituents[] = createConstituents(config, instrument, discoConfig.protectionConstituents);
                            final DiscoState discoState = globalState.computeIfAbsent(discoMarket, instrument, () -> new DiscoState(discoMarket, instrument));
                            final DiscoTtzState discoTtzState = new DiscoTtzState(discoConfig, clusterConstituents, protectionConstituents, discoMarket, instrument, discoState);

                            final EnumObjMap<Market, ComputationTrigger> triggerMap = new EnumObjMap<>(Market.class);
                            for (Markets components : discoConfig.clusterConstituents) {
                                for (Market constituent : components.get()) {
                                    final EnumObjMap<TradingTimeZone, List<ComputationTrigger>> triggersByTimezone = inputTriggers.computeIfAbsent(constituent, instrument, () -> new EnumObjMap<>(TradingTimeZone.class));
                                    final List<ComputationTrigger> triggers = triggersByTimezone.computeIfAbsent(ttz, tradingTimeZone -> new ArrayList<>());
                                    final ComputationTrigger computationTrigger = new ComputationTrigger();
                                    computationTrigger.discoTtzState = discoTtzState;
                                    computationTrigger.clusterConstituent = true;
                                    computationTrigger.protectionConstituent = false;
                                    triggers.add(computationTrigger);
                                    triggerMap.put(constituent, computationTrigger);
                                }
                            }
                            for (Markets components : discoConfig.protectionConstituents) {
                                for (Market protection : components.get()) {
                                    ComputationTrigger computationTrigger = triggerMap.get(protection);
                                    if (computationTrigger == null) {
                                        final EnumObjMap<TradingTimeZone, List<ComputationTrigger>> triggersByTimezone = inputTriggers.computeIfAbsent(protection, instrument, () -> new EnumObjMap<>(TradingTimeZone.class));
                                        final List<ComputationTrigger> triggers = triggersByTimezone.computeIfAbsent(ttz, tradingTimeZone -> new ArrayList<>());
                                        computationTrigger = new ComputationTrigger();
                                        computationTrigger.discoTtzState = discoTtzState;
                                        computationTrigger.clusterConstituent = false;
                                        computationTrigger.protectionConstituent = true;
                                        triggers.add(computationTrigger);
                                        triggerMap.put(protection, computationTrigger);
                                    } else {
                                        computationTrigger.protectionConstituent = true;
                                    }
                                }
                            }
                        });
                    }
                }
            }
        }
    }

    private Constituent[] createConstituents(final IndexedConfigurationData config, final Instrument instrument, final Markets constituents[]) {
        final Constituent clusterConstituents[] = new Constituent[constituents.length];
        int i = 0;
        for (Markets constituent : constituents) {
            final VenueState components[] = new VenueState[constituent.get().length];
            int j = 0;
            for (Market venue : constituent.get()) {
                components[j++] = createOrUpdateVenueState(venue, instrument, config);
            }
            clusterConstituents[i++] = new Constituent(components);
        }
        return clusterConstituents;
    }

    /**
     * Creates venue state and sets parameters.  If it already exists preserves existing price data.
     */
    private VenueState createOrUpdateVenueState(final Market market, final Instrument instrument, final IndexedConfigurationData config) {
        final VenueState venueState = venueStateCache.computeIfAbsent(market, instrument, (m, i) -> new VenueState(m, i));

        venueState.priceChangeEpsilon = config.getPrecisionConfiguration().getInstrumentRateEpsilon(instrument) / 10.0;
        venueState.venueConfig.latencyThreshold = config.getLatencyFilterConfigs().getLatencyTimeOutNanosByMarket(market);

        for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
            final VenueTimezoneConfig venueTimezoneConfig = new VenueTimezoneConfig();
            if (config.getPriceFormationPipelineConfigs().hasFeature(TOBVWAPMarketDataAdjustment.FEATURE_NAME)) {
                venueTimezoneConfig.minQty = config.getPriceFormationPipelineConfigs().getConfig(market, instrument, ttz).getDoubleParamOrNaN(TOBVWAPMarketDataAdjustment.FEATURE_NAME, TOBVWAPMarketDataAdjustment.FEATURE_PARAM_TARGET_TOB_VWAP_QTY).get();
                if (Double.isNaN(venueTimezoneConfig.minQty)) {
                    venueTimezoneConfig.minQty = 0;
                }
            } else {
                venueTimezoneConfig.minQty = 0;
            }
            venueTimezoneConfig.staleThreshold = config.getStaleFilterConfigs().getTimeoutNanos(instrument, ttz);
            venueState.venueConfig.configs.put(ttz, venueTimezoneConfig);
        }

        return venueState;
    }

}
