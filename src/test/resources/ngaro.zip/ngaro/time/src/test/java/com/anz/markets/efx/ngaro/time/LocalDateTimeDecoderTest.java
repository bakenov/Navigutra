package com.anz.markets.efx.ngaro.time;

import java.nio.ByteBuffer;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import org.junit.Assert;
import org.junit.Test;

import com.anz.markets.efx.ngaro.core.ByteReader;

public class LocalDateTimeDecoderTest {

    @Test
    public void decodeEpochSeconds() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final LocalDateTime expected = LocalDateTime.of(2017, 02, 24, 17, 15, 31);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final long epochSeconds1 = decoder.decodeEpochSeconds(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochSeconds2 = decoder.decodeEpochSeconds(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("epochSeconds1 not as expected", expected.toEpochSecond(ZoneOffset.UTC), epochSeconds1);
        Assert.assertEquals("epochSeconds2 not as expected", expected.toEpochSecond(ZoneOffset.UTC), epochSeconds2);
    }

    @Test
    public void decodeEpochMillis() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_MMM);
        final LocalDateTime expected = LocalDateTime.of(2017, 02, 24, 17, 15, 31, 123000000);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31.123xxx");
        final int offset = 3;

        //when
        final long epochMillis1 = decoder.decodeEpochMillis(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochMillis2 = decoder.decodeEpochMillis(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final long exp = expected.toEpochSecond(ZoneOffset.UTC) * Epoch.MILLIS_PER_SECOND + 123;
        Assert.assertEquals("epochMillis1 not as expected", exp, epochMillis1);
        Assert.assertEquals("epochMillis2 not as expected", exp, epochMillis2);
    }


    @Test
    public void decodeEpochNanos() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final LocalDateTime expected = LocalDateTime.of(2017, 02, 24, 17, 15, 31, 123456789);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final long epochNanos1 = decoder.decodeEpochNanos(sb, ByteReader.CHAR_SEQUENCE, offset);
        final long epochNanos2 = decoder.decodeEpochNanos(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        final long exp = expected.toEpochSecond(ZoneOffset.UTC) * Epoch.NANOS_PER_SECOND + expected.getNano();
        Assert.assertEquals("epochNanos1 not as expected", exp, epochNanos1);
        Assert.assertEquals("epochNanos2 not as expected", exp, epochNanos2);
    }

    @Test
    public void decodeLocalDateTime() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final LocalDateTime expected = LocalDateTime.of(2017, 02, 24, 17, 15, 31, 123456789);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final LocalDateTime localTime1 = decoder.decodeLocalDateTime(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalDateTime localTime2 = decoder.decodeLocalDateTime(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("localTime1 not as expected", expected, localTime1);
        Assert.assertEquals("localTime2 not as expected", expected, localTime2);
    }

    @Test
    public void decodeLocalTimeNull() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final StringBuilder sb = new StringBuilder("xxx\0\0\0\0-\0\0-\0\0T\0\0:\0\0:\0\0.\0\0\0\0\0\0\0\0\0xxx");
        final int offset = 3;

        //when
        final LocalDateTime localTime1 = decoder.decodeLocalDateTime(sb, ByteReader.CHAR_SEQUENCE, offset);
        final LocalDateTime localTime2 = decoder.decodeLocalDateTime(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertNull("localTime1 should be null", localTime1);
        Assert.assertNull("localTime2 should be null", localTime2);
    }

    @Test
    public void decodeYear() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int year1 = decoder.decodeYear(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int year2 = decoder.decodeYear(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("year1 not as expected", 2017, year1);
        Assert.assertEquals("year2 not as expected", 2017, year2);
    }

    @Test
    public void decodeMonth() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int month1 = decoder.decodeMonth(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int month2 = decoder.decodeMonth(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("month1 not as expected", 02, month1);
        Assert.assertEquals("month2 not as expected", 02, month2);
    }

    @Test
    public void decodeDay() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int day1 = decoder.decodeDay(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int day2 = decoder.decodeDay(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("day1 not as expected", 24, day1);
        Assert.assertEquals("day2 not as expected", 24, day2);
    }

    @Test
    public void decodeHour() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int hour1 = decoder.decodeHour(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int hour2 = decoder.decodeHour(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("hour1 not as expected", 17, hour1);
        Assert.assertEquals("hour2 not as expected", 17, hour2);
    }

    @Test
    public void decodeMinute() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int minute1 = decoder.decodeMinute(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int minute2 = decoder.decodeMinute(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("minute1 not as expected", 15, minute1);
        Assert.assertEquals("minute2 not as expected", 15, minute2);
    }

    @Test
    public void decodeSecond() {
        //given
        final LocalDateTimeDecoder dec1 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM);
        final LocalDateTimeDecoder dec2 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31xxx");
        final int offset = 3;

        //when
        final int second1 = dec1.decodeSecond(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int second2 = dec2.decodeSecond(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("second1 not as expected", 0, second1);
        Assert.assertEquals("second2 not as expected", 31, second2);
    }

    @Test
    public void decodeNano() {
        //given
        final LocalDateTimeDecoder dec1 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS);
        final LocalDateTimeDecoder dec2 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_MMM);
        final LocalDateTimeDecoder dec3 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_UUUUUU);
        final LocalDateTimeDecoder dec4 = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24T17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final int nano1 = dec1.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano2 = dec2.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano3 = dec3.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano4a = dec4.decodeNano(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int nano4b = dec4.decodeNano(sb.substring(3), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("nano1 not as expected", 0, nano1);
        Assert.assertEquals("nano2 not as expected", 123000000, nano2);
        Assert.assertEquals("nano3 not as expected", 123456000, nano3);
        Assert.assertEquals("nano4a not as expected", 123456789, nano4a);
        Assert.assertEquals("nano4b not as expected", 123456789, nano4b);
    }

    @Test
    public void decodeSeparator() {
        //given
        final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(LocalDateFormat.YYYY_MM_DD, LocalTimeFormat.HH_MM_SS_NNNNNNNNN);
        final StringBuilder sb = new StringBuilder("xxx2017-02-24_17:15:31.123456789xxx");
        final int offset = 3;

        //when
        final int separator1 = decoder.decodeDateTimeSeparator(sb, ByteReader.CHAR_SEQUENCE, offset);
        final int separator2 = decoder.decodeDateTimeSeparator(sb.substring(offset), ByteReader.CHAR_SEQUENCE);

        //then
        Assert.assertEquals("separator1 not as expected", '_', separator1);
        Assert.assertEquals("separator2 not as expected", '_', separator2);
    }

    @Test
    public void decodeAllFormats() {
        final LocalDateTime expMM_SS_NNNNNNNNN = LocalDateTime.of(2017, 02, 24, 17, 15, 30, 123456789);
        final LocalDateTime expMM_SS_UUUUUU = LocalDateTime.of(2017, 02, 24, 17, 15, 30, 123456000);
        final LocalDateTime expMM_SS_MMM = LocalDateTime.of(2017, 02, 24, 17, 15, 30, 123000000);
        final LocalDateTime expMM_SS = LocalDateTime.of(2017, 02, 24, 17, 15, 30);
        final LocalDateTime expMM = LocalDateTime.of(2017, 02, 24, 17, 15, 00);
        final LocalDateFormat[] dateFormats = {LocalDateFormat.YYYYMMDD, LocalDateFormat.MMDDYYYY, LocalDateFormat.DDMMYYYY,
                LocalDateFormat.YYYY_MM_DD, LocalDateFormat.MM_DD_YYYY, LocalDateFormat.DD_MM_YYYY};
        final LocalTimeFormat[] timeFormats = {
                LocalTimeFormat.HHMM, LocalTimeFormat.HHMMSS, LocalTimeFormat.HHMMSSMMM, LocalTimeFormat.HHMMSSUUUUUU, LocalTimeFormat.HHMMSSNNNNNNNNN,
                LocalTimeFormat.HH_MM, LocalTimeFormat.HH_MM_SS, LocalTimeFormat.HH_MM_SS_MMM, LocalTimeFormat.HH_MM_SS_UUUUUU, LocalTimeFormat.HH_MM_SS_NNNNNNNNN
        };
        final String[] dateStrings = {"20170224", "02242017", "24022017",
                "2017-02-24", "02-24-2017", "24-02-2017"};
        final String[] timeStrings = {
                "1715", "171530", "171530123", "171530123456", "171530123456789",
                "17:15", "17:15:30", "17:15:30.123", "17:15:30.123456", "17:15:30.123456789"
        };
        final LocalDateTime[] expectedValues = {
                expMM, expMM_SS, expMM_SS_MMM, expMM_SS_UUUUUU, expMM_SS_NNNNNNNNN,
                expMM, expMM_SS, expMM_SS_MMM, expMM_SS_UUUUUU, expMM_SS_NNNNNNNNN
        };
        final char[] dateTimeSeparators = {'T', '_', ' ', LocalDateTimeEncoder.NO_SEPARATOR};

        for (int df = 0; df < dateFormats.length; df++) {
            for (int tf = 0; tf < timeFormats.length; tf++) {
                for (final char sep : dateTimeSeparators) {
                    final LocalDateTimeDecoder decoder = LocalDateTimeDecoder.valueOf(dateFormats[df], timeFormats[tf], sep);
                    final LocalDateTime expected = expectedValues[tf];
                    final String format = decoder.getDateTimeFormatString();
                    final int offset = 3;
                    final String input = dateStrings[df] + (sep == LocalDateTimeEncoder.NO_SEPARATOR ? "" : sep) + timeStrings[tf];
                    final String inputString = "abc" + input + "defghklmnopkrstuvwxyzabcdefghklmnopkrstuvwxyz".substring(input.length());
                    final byte[] inputArray = input.getBytes();
                    final ByteBuffer inputBuffer = ByteBuffer.wrap(inputArray);

                    //when
                    final LocalDateTime actual1 = decoder.decodeLocalDateTime(inputString, ByteReader.CHAR_SEQUENCE, offset);
                    final LocalDateTime actual2 = decoder.decodeLocalDateTime(inputArray, ByteReader.BYTE_ARRAY);
                    final LocalDateTime actual3 = decoder.decodeLocalDateTime(inputBuffer, ByteReader.BYTE_BUFFER);

                    //then
                    Assert.assertEquals("decoded actual1 not as expected for format " + format, expected, actual1);
                    Assert.assertEquals("decoded actual2 not as expected for format " + format, expected, actual2);
                    Assert.assertEquals("decoded actual3 not as expected for format " + format, expected, actual3);
                }
            }
        }
    }
}