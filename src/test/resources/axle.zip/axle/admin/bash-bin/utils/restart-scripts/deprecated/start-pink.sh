#!/bin/bash

echo "" | mailx -r "build.box@anz.com" -s "PINK ENV - starting all regions" "axletest@anz.com"

ssh AxlSv@daxa005z 'cd /app/apama/axle/environment/correlator/scripts && ./start.sh'

ssh axle@daxa008z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'
ssh AxlSv@daxa002z 'cd /app/apama/axle/environment/proxy/scripts && ./start.sh'

echo "" | mailx -r "build.box@anz.com" -s "PINK ENV - FINISHED starting all regions" "axletest@anz.com"
