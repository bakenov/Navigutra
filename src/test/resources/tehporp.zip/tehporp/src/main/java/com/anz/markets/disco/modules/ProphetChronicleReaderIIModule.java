package com.anz.markets.disco.modules;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.chroniclequeue.ChronicleQueueReader;
import com.anz.markets.prophet.chronicle.config.ChronicleHook;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.ReaderConfigBuilder;
import com.anz.markets.prophet.chronicle.config.RingBuffer;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.domain.chronicle.MessageType;
import com.anz.markets.prophet.domain.marketdata.MarketDataIncrement;
import com.anz.markets.prophet.domain.marketdata.MarketDataSnapshot;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataIncrementImpl;
import com.anz.markets.prophet.domain.marketdata.impl.MarketDataSnapshotImpl;

import java.io.IOException;

public class ProphetChronicleReaderIIModule extends AbstractInputModule implements ChronicleObjectReader {

    private final MarketDataIncrementImpl marketDataIncrement = new MarketDataIncrementImpl();
    private final MarketDataSnapshotImpl marketDataSnapshot = MarketDataSnapshotImpl.forMarket();

    private final String inPath;

    public ProphetChronicleReaderIIModule(final String inPath) {
        super("Prophet Chronicle Reader: " + inPath);
        this.inPath = inPath;
    }

    @Override
    public Runnable createInputRunnable() {
        final ReaderConfig config = ReaderConfigBuilder.create()
                .withStartPosition(0)
                .withStartAt(StartAt.INDEX)
                .withWaitStrategy(WaitStrategy.PAUSE)
                .withStartReadHook(ChronicleHook.START_READ)
                .withUnknownReadHook(ChronicleHook.unknownMessageCounter())
                //                .withHeaderFilter((header, index, messageType) -> !(messageType == MessageType.MARKET_DATA_SNAPSHOT || messageType == MessageType.MARKET_DATA_INCREMENT))
                .withChronicleObjectReader(this)
                .withRingBuffer(RingBuffer.NO_RING)
                .build();

        return new ChronicleQueueReader(inPath, config);
    }

    @Override
    public void processEntity(final ProphetBytes bytes, final MessageType messageType) {
        if (messageType == MessageType.MARKET_DATA_SNAPSHOT) {
            marketDataSnapshot.readMarshallable(bytes);
            getStage().getMessageBus().pub(MarketDataSnapshot.class, marketDataSnapshot);
        } else if (messageType == MessageType.MARKET_DATA_INCREMENT) {
            marketDataIncrement.readMarshallable(bytes);
            getStage().getMessageBus().pub(MarketDataIncrement.class, marketDataIncrement);
        }
    }

}
