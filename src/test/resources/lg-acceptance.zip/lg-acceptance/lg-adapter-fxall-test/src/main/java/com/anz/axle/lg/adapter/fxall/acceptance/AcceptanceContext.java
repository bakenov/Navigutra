package com.anz.axle.lg.adapter.fxall.acceptance;

import com.anz.axle.lg.adapter.acceptance.shared.SharedAcceptanceContext;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;

public interface AcceptanceContext extends SharedAcceptanceContext {
    FixMessageSender fixTradingMessageSender();
}
