package com.anz.axle.lg.adapter.ebs;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import software.chronicle.fix.codegen.CodeGenerator;
import software.chronicle.fix.codegen.FixType;

public class EbsChronicleFixCodeGenerator {

    public static void main(final String[] args) throws IOException {
        final long startTime = System.currentTimeMillis();
        final CodeGenerator cg = new CodeGenerator();
        cg.codePackage("com.anz.axle.lg.adapter.ebs.chroniclefix.generated");
        cg.schemaFile("lg-adapter-ebs", "src/main/resources/conf/FIX44-ebs.xml");
        cg.codeDirectory("lg-adapter-ebs", "target/generated-sources");
        cg.clean(true);

        // Retain decimal precision when reading floating point.
        cg.includeDecimalPrecision(false);

        // internal representation for datetimes
        cg.internalTimeUnit(TimeUnit.NANOSECONDS);

        // TODO: Double unset value 0 not NaN

        // this will cause the MDEntryID field to be bytes ( which has lower latency ) rather than a String
        // TODO: use AsciiString not Bytes
        cg.classOverride(f -> f.name().equals("MDEntryID") || f.name().equals("MDReqID") || f.name().equals("ClOrdID") || f.name().equals("OrigClOrdID") || f.name().equals("OrderID") || f.name().equals("Price")? FixType.BYTES : null);
        cg.run();
        System.out.println("EbsChronicleFixCodeGenerator completed in " + (System.currentTimeMillis() - startTime) + " ms");
    }
}