#!/bin/bash

die () {
        echo >&2 "$@"
        exit 1
}

[ "$#" -ge 3 ] || die "At least 3 arguments required, $# provided.  Usage deploy-to-destination.sh <job-name> <deploy-destination> <stop-start-application-during-install true/false> [released-by]"

JOB_NAME=$1
DEPLOY_DESTINATION=$2
STOP_START_APP=$3
if [ -n $4 ]; then RELEASED_BY=$4; fi

JAVA_HOME=/app/fxdev/java/jdk1.6.0_18
CVSROOT=:ext:fxdev@dfxa002z.unix.anz:/app/fxdev/repo
PATH=/app/fxdev/cvs:/app/fxdev/ant/apache-ant-1.7.1/bin:$JAVA_HOME/bin:$PATH
HUDSON_HOME=/app/fxdev/hudson/home
HUDSON_JOBS=$HUDSON_HOME/jobs
BUILDER_PATH=$HUDSON_JOBS/builder2_apama/workspace
DISCOVERY_PATH=$HUDSON_JOBS/axle-discovery/workspace


echo "Ensuring base directories exist on destination"
ssh axle@$DEPLOY_DESTINATION "mkdir -p ~/axle"

echo "Deploying application $JOB_NAME to $DEPLOY_DESTINATION by $RELEASED_BY"

RELEASE_VERSION=$(ls $HUDSON_JOBS/axle-release/lastSuccessful/com.anz.axle\$distribution/archive/com.anz.axle/distribution)
ssh axle@$DEPLOY_DESTINATION "cd ~/axle && rm -f fxagg-$RELEASE_VERSION-bin.zip && rm -rf fxagg-$RELEASE_VERSION"
scp $HUDSON_JOBS/axle-release/lastSuccessful/com.anz.axle\$distribution/archive/com.anz.axle/distribution/$RELEASE_VERSION/fxagg-$RELEASE_VERSION-bin.zip axle@$DEPLOY_DESTINATION:~/axle
ssh axle@$DEPLOY_DESTINATION "cd ~/axle && unzip -o fxagg-$RELEASE_VERSION-bin.zip && rm -f fxagg && ln -s fxagg-$RELEASE_VERSION fxagg"
ssh axle@$DEPLOY_DESTINATION "cd ~/axle/fxagg && chmod -R 754 */*.sh"

echo "Deployed application $JOB_NAME to $DEPLOY_DESTINATION by $RELEASED_BY"

ANT_RETURN_CODE=$?

echo "ANT: Return code is: \""$ANT_RETURN_CODE"\""
if [ $ANT_RETURN_CODE -ne 0 ];then
 
    echo "BUILD ERROR"
    exit 1;
else
 
    echo "BUILD SUCCESS"
    exit 0;
fi
