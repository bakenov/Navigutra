package com.anz.markets.prophet.positionrisk;

import net.openhft.chronicle.Chronicle;
import net.openhft.chronicle.ChronicleQueueBuilder;
import net.openhft.chronicle.ExcerptAppender;
import net.openhft.chronicle.ExcerptTailer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.concurrent.locks.LockSupport;

import static org.junit.Assert.assertEquals;

/**
 * This test seems to be testing that CQ3 can be opened and closed and read & written in different threads
 */
public class ChronicleGate {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChronicleGate.class);

    private static final int MAX = 10_000;
    private static final int delayNS = 1_000_000;
    private static final int FLIP_EVERY = 20;

    private volatile int active = 0, indexToWrite = 1;
    private volatile boolean stopping = false, flipped = true;
    private final String basePath = "FailoverChronicle";

    @After
    @Before
    public void clean() {
        LOGGER.warn("Cleanup Chronicle {}", basePath);
        ChronicleGate.deleteNow(basePath);
    }

    @Test
    public void testFlipBetweenWriters() throws IOException, InterruptedException {
        LOGGER.info("reps " + MAX + " delayNS " + delayNS);

        Thread w1 = startWriter(delayNS, basePath, 0);

        Thread w2 = startWriter(delayNS, basePath, 1);

        startReader(MAX, basePath, FLIP_EVERY);
        stopping = true;

        w1.join();
        w2.join();
    }

    public static void deleteNow(String basePath) {
        for (String name : new String[]{basePath, basePath + ".data", basePath + ".index"}) {
            final File file = new File(name);
            deleteNow(file);
        }
    }

    private static void deleteNow(final File file) {
        if (file.exists()) {
            final long timeoutMs = System.currentTimeMillis() + 2_000;
            while (System.currentTimeMillis() < timeoutMs) {
                final boolean succeeded;
                if (file.isDirectory()) {
                    succeeded = FileSystemUtils.deleteRecursively(file);
                } else {
                    succeeded = file.delete();
                }
                if (succeeded) {
                    return;
                }
                System.gc();
            }
            throw new IllegalStateException("Could not delete " + file.getPath());
        }
    }

    private Thread startWriter(final int delayNS, final String basePath, final int id) throws IOException {
        Thread t = new Thread() {
            @Override
            public void run() {
                try {
                    LOGGER.info("writing to {}", basePath);
                    Chronicle chronicle = null;
                    ExcerptAppender appender = null;
                    boolean writing = false;
                    do {
                        boolean meActive = (id == active);
                        if (writing != meActive) {
                            LOGGER.info("{}: is being flipped to active={}", id, meActive);
                            if (meActive) {
                                while (!flipped) { ; }
                                chronicle = ChronicleQueueBuilder.indexed(basePath).build();
                                appender = chronicle.createAppender();
                                LOGGER.info("writing to {} size {}", basePath, chronicle.size());
                            } else {
                                appender.close();
                                LOGGER.info("shutdown {} size {}", basePath, chronicle.size());
                                chronicle.close();
                                flipped = true;
                            }
                        }
                        if (meActive) {
                            appender.startExcerpt(75);
                            appender.writeLong(indexToWrite);
                            appender.writeLong(System.nanoTime());
                            appender.writeInt(id);
                            appender.finish();
                            LOGGER.debug(id + ": wrote indexToWrite " + indexToWrite + " appender.index " + appender.index() + " nextSynchronous()=" + appender.nextSynchronous());
                            assertEquals("<<< write mismatch", appender.index(), indexToWrite);
                            ++indexToWrite;
                        }
                        writing = meActive;
                        LockSupport.parkNanos(delayNS);
                    } while (!stopping);
                    appender.close();
                    LOGGER.info("finished write");
                    chronicle.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
        return t;
    }

    private void startReader(final int reps, final String basePath, int every) throws IOException {
        final Random r = new SecureRandom();
        final Chronicle chronicle = ChronicleQueueBuilder.indexed(basePath).build();
        int c = 1;
        long lastChronIndex = -1;
        LOGGER.info("reading from " + basePath);
        ExcerptTailer reader = chronicle.createTailer();
        while (true) {
            while (!reader.nextIndex()) {
                ; // while until there is a new Excerpt to read
            }

            long index = reader.readLong();
            long latency = System.nanoTime() - reader.readLong();
            int id = reader.readInt();
            reader.finish();
            LOGGER.debug(id + ": read " + index + " chron.index " + reader.index() + " latency " + latency + "ns");
            assertEquals(">>> mismatch index", index, c);
            assertEquals(">>> mismatch lastChronIndex ", reader.index(), (lastChronIndex + 1));
            assertEquals(">>> mismatch chron.index ", reader.index(), (c - 1));
            if (id != active) {
                LOGGER.info("  >>> mismatch n=" + id + " != " + active + " this is OK because writes are being drained");
            }
            if (++c == reps) {
                break;
            }
            lastChronIndex = reader.index();

            if (r.nextInt(every) == 7) {
                LOGGER.warn("  *** Flipping from {} c={}", active, c);
                active = active == 0 ? 1 : 0;
                flipped = false;
                // make sure we don't try and flip back before flip is completed
                while (!flipped) { ; }
            }
        }
        LOGGER.warn("finished read");
        reader.close();
        chronicle.close();
    }
}
