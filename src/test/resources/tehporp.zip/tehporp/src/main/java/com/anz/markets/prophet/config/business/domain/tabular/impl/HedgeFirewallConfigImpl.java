package com.anz.markets.prophet.config.business.domain.tabular.impl;

import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;
import com.anz.markets.prophet.config.business.domain.tabular.hedging.HedgeFirewallConfig;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.chronicle.MessageVersion;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HedgeFirewallConfigImpl implements HedgeFirewallConfig, ProphetMarshallable {
    private static final Logger LOGGER = LoggerFactory.getLogger(HedgeFirewallConfigImpl.class);

    private Portfolio portfolio;
    private Region region;
    private HedgeFirewallType hedgeFirewallType;
    private double limit;
    private boolean enabled;

    /**
     * Added this for deserialisation to work. Setters for mandatory field should not be created.
     * This method should not be called except for deserialisation.
     */
    @Deprecated
    public HedgeFirewallConfigImpl() {
    }

    public HedgeFirewallConfigImpl(final Portfolio portfolio,
                                   final Region region,
                                   final HedgeFirewallType hedgeFirewallType,
                                   final double limit) {
        this(portfolio, region, hedgeFirewallType, limit, false); // temporary until kdb table is modified.
    }

    public HedgeFirewallConfigImpl(final Portfolio portfolio,
                                   final Region region,
                                   final HedgeFirewallType hedgeFirewallType,
                                   final double limit,
                                   final boolean enabled) {
        GcFriendlyAssert.notNull(portfolio, "portfolio must not be null.");
        GcFriendlyAssert.notNull(region, "region must not be null.");
        GcFriendlyAssert.notNull(hedgeFirewallType, "hedgeFirewallType must not be null.");
        this.portfolio = portfolio;
        this.region = region;
        this.hedgeFirewallType = hedgeFirewallType;
        this.limit = limit;
        this.enabled = enabled;
    }

    @Override
    public Portfolio getPortfolio() {
        return portfolio;
    }

    @Override
    public Region getRegion() {
        return region;
    }

    @Override
    public HedgeFirewallType getHedgeFirewallType() {
        return hedgeFirewallType;
    }

    @Override
    public double getLimit() {
        return limit;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public static ProphetMarshallable constructReadMarshallable(final ProphetBytes in) {
        return new HedgeFirewallConfigImpl(
                in.readEnum(Portfolio.class),
                in.readEnum(Region.class),
                in.readEnum(HedgeFirewallType.class),
                in.readDouble(),
                Context.context().header().getMessageVersion().before(MessageVersion.VERSION_0_22) ? false : in.readBoolean());
    }

    @Override
    public void readMarshallable(@NotNull final ProphetBytes in) throws IllegalStateException {
        // not needed.
    }

    @Override
    public void writeMarshallable(@NotNull final ProphetBytes out) {
        FieldReflectionBytesMarshallable.INSTANCE.write(this, out);
    }

    @Override
    public String toString() {
        return "HedgeFirewallConfigImpl{" +
                "portfolio=" + portfolio +
                ", region=" + region +
                ", hedgeFirewallType=" + hedgeFirewallType +
                ", limit=" + limit +
                ", enabled=" + enabled +
                '}';
    }
}
