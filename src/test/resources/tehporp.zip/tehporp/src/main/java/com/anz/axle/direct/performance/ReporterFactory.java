package com.anz.axle.direct.performance;

public interface ReporterFactory {
    ProgressReporter createProgressReporter();

    MetricReporter createMetricReporter();
}
