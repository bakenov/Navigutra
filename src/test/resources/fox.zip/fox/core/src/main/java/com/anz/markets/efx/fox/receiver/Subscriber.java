package com.anz.markets.efx.fox.receiver;

import com.anz.markets.efx.messaging.transport.api.Subscription;

public interface Subscriber {
    Subscription subscribe();
}
