package com.anz.markets.efx.fox.processor.command;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.eventsourcing.CommandContext;
import com.anz.markets.efx.fox.firewall.api.Firewall;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.trading.codec.sbe.NewOrderSingleSbeDecoder;

public class ParentNewOrderSingleCommand implements MessageDecoder<SbeMessage> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParentNewOrderSingleCommand.class);

    private final CommandContext commandContext;
    private final Firewall inboundOrderFirewall;

    private final NewOrderSingleSbeDecoder newOrderSingleDecoder = new NewOrderSingleSbeDecoder();

    private final ByteValueCache<String> marketIdCache = new ByteValueCache<>(AsciiString::toString);

    private final StringBuilder stringBuilder = new StringBuilder();

    public ParentNewOrderSingleCommand(final CommandContext commandContext,
                                       final Firewall inboundOrderFirewall) {
        this.commandContext = Objects.requireNonNull(commandContext);
        this.inboundOrderFirewall = Objects.requireNonNull(inboundOrderFirewall);
    }

    @Override
    public boolean decode(final SbeMessage message) {
        if (!newOrderSingleDecoder.wrap(message)) return false;

        final String marketId = newOrderSingleDecoder.body().marketId().decodeAndCache(marketIdCache);

        if (Venue.FOX.name().equals(marketId)) {
            logMessage();
            inboundOrderFirewall.accept(newOrderSingleDecoder, commandContext);
            return true;
        }
        return false;
    }

    private void logMessage() {
        stringBuilder.setLength(0);
        newOrderSingleDecoder.appendTo(stringBuilder);
        LOGGER.info("Action parent NOS: {}", stringBuilder);
    }
}
