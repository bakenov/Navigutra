package com.anz.markets.disco.modules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.PriorityQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.config.DiscoVolatilityPFPConfig;
import com.anz.markets.disco.data.MutableSignals;
import com.anz.markets.disco.data.Signal;
import com.anz.markets.disco.data.SignalType;
import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.efx.ngaro.math.Epsilon;
import com.anz.markets.prophet.config.business.domain.indexed.IndexedConfigurationData;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.time.OneSecond;
import com.anz.markets.prophet.status.Context;

/**
 * This module publishes tick volatility signals.  It is configured via TV1, TV2, TV3 signal types.
 */
public class VolatilityModule extends AbstractModule {

    private final Logger logger = LoggerFactory.getLogger(VolatilityModule.class);

    public static final long RECHECK_FREQUENCY_NANOS = TimeUnit.SECONDS.toNanos(1);

    private static class TtzVolatilityState {
        final VolatilityConfig config;

        final double componentVolatility[];
        double lastPublishedVolatility = -1;  // force initial publish even if NaN
        double lastPublishedVolSpread = -1;

        public TtzVolatilityState(final VolatilityConfig config) {
            this.config = config;
            this.componentVolatility = new double[config.tauNanos.length];
            Arrays.fill(componentVolatility, Double.NaN);
        }
    }

    /**
     * State for each configured vol for a given market x instrument.
     **/
    private class VolatilityStates {
        final Market market;
        final Instrument instrument;
        final double priceChangeEpsilon;
        final double spreadChangeEpsilon;

        long signalTime;
        double bid = Double.NaN;
        double ask = Double.NaN;
        double volSignal = Double.NaN;
        long queuedRecheckTime;

        final EnumObjMap<TradingTimeZone, List<TtzVolatilityState>> states = new EnumObjMap<>(TradingTimeZone.class);

        public VolatilityStates(final Market market, final Instrument instrument, final double priceChangeEpsilon, final double spreadChangeEpsilon) {
            this.market = market;
            this.instrument = instrument;
            this.priceChangeEpsilon = priceChangeEpsilon;
            this.spreadChangeEpsilon = spreadChangeEpsilon;
        }

        public void add(final TradingTimeZone ttz, final TtzVolatilityState volatilityState) {
            states.computeIfAbsent(ttz, x -> new ArrayList<>()).add(volatilityState);
        }

        public boolean priceChanged(double p1, double p2) {
            return (Double.isNaN(p1) ^ Double.isNaN(p2)) || Math.abs(p1 - p2) >= priceChangeEpsilon;
        }

        public boolean spreadChanged(double p1, double p2) {
            return (Double.isNaN(p1) ^ Double.isNaN(p2)) || Math.abs(p1 - p2) >= spreadChangeEpsilon;
        }

        public void queueForRecheckIfNecessary() {
            if (queuedRecheckTime == 0 && volSignal > 0) {
                if (recheckQueue.size() < DiscoveryModule.MAX_VENUE_STATE) {  // <- infinite queue prevention.
                    queuedRecheckTime = Context.context().timeSource().nowNanos() + RECHECK_FREQUENCY_NANOS;
                    recheckQueue.add(this);
                } else {
                    // logic error - we must be adding more than one due to a bug.
                    logger.warn("Logic error - maximum queue size exceeded.  Recheck cannot be queued for {} {}", market, instrument);
                }
            }
        }
    }

    private static class VolatilityConfig {
        final SignalType signalType;
        final long tauNanos[];
        final double incSpread;
        final double volStep;
        final double volStart;
        final double volPowerInverse;

        final VolatilityDiscretiser volatilityDiscretiser;
        final double annualisationMultiplier[];

        public VolatilityConfig(final SignalType signalType, final long tauNanos[], final double incSpread, final double volStep, final double volStart, final double volPower,
                                final double lowThreshold, final double mediumThreshold) {
            this.signalType = signalType;
            this.tauNanos = tauNanos;
            this.incSpread = incSpread;
            this.volStep = volStep;
            this.volStart = volStart;
            this.volPowerInverse = 1.0/volPower;

            GcFriendlyAssert.isTrue(lowThreshold < mediumThreshold, "Low threshold must be below medium threshold.");
            this.volatilityDiscretiser = new VolatilityDiscretiser(lowThreshold, mediumThreshold);

            final long ONE_YEAR_NANOS = TimeUnit.SECONDS.toNanos(250 * 24 * 60 * 60);
            this.annualisationMultiplier = new double[tauNanos.length];
            for (int i = 0; i < annualisationMultiplier.length; i++) {
                GcFriendlyAssert.isTrue(tauNanos[i] > 0, "Tau must be positive.");
                annualisationMultiplier[i] = Math.sqrt(ONE_YEAR_NANOS / tauNanos[i]);
            }
        }
    }

    public static class VolatilityDiscretiser {

        public final Symbol LOW = Symbol.get("L");
        public final Symbol MEDIUM = Symbol.get("M");
        public final Symbol HIGH = Symbol.get("H");
        public final Symbol BAD = Symbol.get("X");

        final double lowThreshold;
        final double mediumThreshold;

        public VolatilityDiscretiser(final double lowThreshold, final double mediumThreshold) {
            this.lowThreshold = lowThreshold;
            this.mediumThreshold = mediumThreshold;
        }

        public Symbol getClassification(double vol) {
            if (vol >= 0) {
                if (vol <= lowThreshold) {
                    return LOW;
                } else if (vol <= mediumThreshold) {
                    return MEDIUM;
                } else {
                    return HIGH;
                }
            } else {
                return BAD;
            }
        }
    }

    private final EnumObjTable<Market, Instrument, VolatilityStates> stateMap = new EnumObjTable<>(Market.class, Instrument.class);

    private final Comparator<? super VolatilityStates> recheckQueueComparator = Comparator.comparingLong(x -> x.queuedRecheckTime);
    private final PriorityQueue<VolatilityStates> recheckQueue = new PriorityQueue<>(recheckQueueComparator);
    private final MutableSignals unsolicitedSignals = new MutableSignals();


    @Override
    public void sub(MessageBus messageBus) {
        messageBus.sub(this::consumeConfig, IndexedConfigurationData.class);
        messageBus.sub(this::consumeOneSecond, OneSecond.class);
        getStage().getProcessingModule(DiscoveryModule.class).addDerivedSignal(this::populate);
    }

    private void consumeOneSecond(final OneSecond oneSecond) {
        final long t = Context.context().timeSource().nowNanos();
        while (recheckQueue.size() > 0 && t >= recheckQueue.peek().queuedRecheckTime) {
            final VolatilityStates volatilityStates = recheckQueue.poll();
            volatilityStates.queuedRecheckTime = 0;
            try {
                unsolicitedSignals.setMarket(volatilityStates.market);
                unsolicitedSignals.setInstrument(volatilityStates.instrument);
                unsolicitedSignals.clear();
                recalculate(unsolicitedSignals,true);
                if (unsolicitedSignals.getSize() > 0) {
                    unsolicitedSignals.setExternalEventTimeNS(0);
                    unsolicitedSignals.setExternalSourceId(0);
                    unsolicitedSignals.setSignalsId(Context.context().idGenerator().incrementAndGetId());
                    getStage().getMessageBus().pub(DiscoveryModule.SIGNALS_MESSAGE_SYMBOL, unsolicitedSignals);
                }
            } finally {
                volatilityStates.queueForRecheckIfNecessary();
            }
        }
    }

    private void populate(final DiscoveryModule.DiscoState discoState) {
        recalculate(discoState.signals,false);
    }

    private void recalculate(final MutableSignals newSignals, final boolean isRecheck) {

        final VolatilityStates states = stateMap.get(newSignals.getMarket(), newSignals.getInstrument());
        if (states == null) {
            return;  // not configured.
        }

        final Signal bidSignal = newSignals.getSignal(SignalType.CBID);
        if (bidSignal != null && bidSignal.getValue() > 0) {
            states.bid = bidSignal.getValue();
        }

        final Signal askSignal = newSignals.getSignal(SignalType.CASK);
        if (askSignal != null && askSignal.getValue() > 0) {
            states.ask = askSignal.getValue();
        }

        final long t = Context.context().timeSource().nowNanos();

        final long dt = Math.max(0, t - states.signalTime);
        final double newVolSignal;
        if (states.signalTime == 0 || Double.isNaN(states.volSignal)) {
            newVolSignal = 0.5 * (states.bid + states.ask);   // reset to mid on first
        } else {
            newVolSignal = Math.max(states.bid, Math.min(states.volSignal, states.ask));
            // ^^^ will only produce a new signal if current signal is outside bid/ask window.
            // Note: is robust under inverted bid/ask - but will produce more signal deltas.
        }
        final List<TtzVolatilityState> ttzStates = states.states.get(Context.context().tradingTimeZone());
        if (ttzStates != null) {
            for (int i = 0; i < ttzStates.size(); i++) {
                calculateVolatility(newSignals, states, ttzStates.get(i), newVolSignal, dt, isRecheck);
            }
        }
        states.volSignal = newVolSignal;
        states.signalTime = t;
        states.queueForRecheckIfNecessary();
    }

    private void calculateVolatility(final MutableSignals newSignals, final VolatilityStates states, final TtzVolatilityState state, final double newVolSignal, final long dt, final boolean isRecheck) {

        double newVolatility = Double.NaN;
        for (int i = 0; i < state.config.tauNanos.length; i++) {
            final double term2 = Double.isNaN(state.componentVolatility[i]) ? 0 : state.componentVolatility[i] * Math.exp(-1 * dt / (double) state.config.tauNanos[i]);
            final double newVolComponent = Math.abs(newVolSignal - states.volSignal) + term2;
            final double annRelativeVolComponent = (newVolComponent / newVolSignal) * state.config.annualisationMultiplier[i];
            state.componentVolatility[i] = newVolComponent;
            if (annRelativeVolComponent > newVolatility || Double.isNaN(newVolatility)) {
                newVolatility = annRelativeVolComponent;
            }
        }

        if (Epsilon.EPS_0_001.doesNotEqualEpsilon(state.lastPublishedVolatility, newVolatility)) {
            boolean publish = true;
            if (!isRecheck && newVolatility > 0 && state.lastPublishedVolatility > 0) {
                // only publish if > 5% change in vol number
                publish = Math.abs(newVolatility - state.lastPublishedVolatility) / newVolatility > 0.05;
            }
            if (publish) {
                final Symbol volCategory = state.config.volatilityDiscretiser.getClassification(newVolatility);
                newSignals.add(state.config.signalType, newVolatility, volCategory);
                state.lastPublishedVolatility = newVolatility;
            }
        }

        // Vol spread for TV1.
        if (state.config.signalType == SignalType.TV1) {
            final double volSpread = state.config.incSpread * Math.pow(Math.max(0, (newVolatility - state.config.volStart) / state.config.volStep), state.config.volPowerInverse);
            if (states.spreadChanged(volSpread,state.lastPublishedVolSpread)) {
                final Symbol volCategory = state.config.volatilityDiscretiser.getClassification(newVolatility);
                newSignals.add(SignalType.TVS, volSpread, volCategory);
                state.lastPublishedVolSpread = volSpread;
            }
        }
    }

    private void consumeConfig(IndexedConfigurationData config) {
        clearConfigState();
        try {
            buildConfig(config, SignalType.TV1, DiscoVolatilityPFPConfig.FEATURE_NAME_TV1);
            buildConfig(config, SignalType.TV2, DiscoVolatilityPFPConfig.FEATURE_NAME_TV2);
            buildConfig(config, SignalType.TV3, DiscoVolatilityPFPConfig.FEATURE_NAME_TV3);
        } catch (Exception e) {
            clearConfigState();   // clear config on error to prevent incomplete config operating.
            throw e;
        }
    }

    private void clearConfigState() {
        // Remove individual vol config but retain (market,instrument) state.
        stateMap.forEach((market, instrument, volatilityStates) -> volatilityStates.states.clear());
        recheckQueue.clear();
    }

    private void buildConfig(IndexedConfigurationData config, SignalType signalType, String featureName) {
        final DiscoVolatilityPFPConfig discoVolatilityPFPConfig = new DiscoVolatilityPFPConfig(config.getPriceFormationPipelineConfigs(), featureName);
        for (Market market : Market.VALUES) {
            for (TradingTimeZone ttz : TradingTimeZone.VALUES_ACTUAL) {
                final EnumMap<Instrument, DiscoVolatilityPFPConfig.DiscoVolatilityPFPRowConfig> rows = discoVolatilityPFPConfig.getConfig().get(market, ttz);
                if (rows != null) {
                    rows.forEach((instrument, c) -> {
                        if (c.timePeriodSeconds.length > 0) {
                            final double priceChangeEpsilon = config.getPrecisionConfiguration().getInstrumentRateEpsilon(instrument) / 10.0;
                            final double spreadChangeEpsilon = config.getPrecisionConfiguration().rateToPips(instrument,priceChangeEpsilon);
                            final VolatilityStates volatilityStates = stateMap.computeIfAbsent(market, instrument, () -> new VolatilityStates(market, instrument, priceChangeEpsilon, spreadChangeEpsilon));

                            final long tauNanos[] = new long[c.timePeriodSeconds.length];
                            for (int i = 0; i < tauNanos.length; i++) {
                                tauNanos[i] = TimeUnit.SECONDS.toNanos(c.timePeriodSeconds[i]);
                            }
                            final double lowThreshold = 0.5;  //Currently hiding these from KDB config to prevent tweaking.
                            final double mediumThreshold = 2.0;
                            final VolatilityConfig volatilityConfig = new VolatilityConfig(signalType, tauNanos, c.incSpread, c.volStep, c.volStart, c.volPower, lowThreshold, mediumThreshold);

                            final TtzVolatilityState ttzVolatilityState = new TtzVolatilityState(volatilityConfig);
                            volatilityStates.add(ttz, ttzVolatilityState);
                            volatilityStates.queueForRecheckIfNecessary();
                        }
                    });
                }
            }
        }
    }

}
