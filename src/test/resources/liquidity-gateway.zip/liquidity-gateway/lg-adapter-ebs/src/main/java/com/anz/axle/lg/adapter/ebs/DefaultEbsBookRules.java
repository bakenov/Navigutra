package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.CustRepeatingBlocks_RelatedSymGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.CustRepeatingBlocks_RelatedSymGrp_NestedUserDataGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.UserResponse;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import org.agrona.collections.Long2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.NestedUserDataName.PRICE_INCREMENT;

public final class DefaultEbsBookRules implements EbsBookRules {

    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultEbsBookRules.class);
    private final Long2ObjectHashMap<EbsBookRules.Config> configByInstrument = new Long2ObjectHashMap<>();
    private final TenorLookup tenorLookup;

    public DefaultEbsBookRules(final TenorLookup tenorLookup) {
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
    }

    @Override
    public Config configFor(final long instrumentId) {
        return configByInstrument.get(instrumentId);
    }

    @Override
    public void update(final UserResponse userResponse) {
        configByInstrument.clear();

        for (int i = 0; i < userResponse.noRelatedSym(); i++) {
            final CustRepeatingBlocks_RelatedSymGrp_1 symGrp_1 = userResponse.custRepeatingBlocks_RelatedSymGrp_1(i);
            String priceIncrementStr = null;
            for (int j = 0; j < symGrp_1.noNestedUserData(); j++) {
                final CustRepeatingBlocks_RelatedSymGrp_NestedUserDataGrp_1 userDataGrp1 = symGrp_1.custRepeatingBlocks_RelatedSymGrp_NestedUserDataGrp_1(j);
                if (PRICE_INCREMENT.equals(userDataGrp1.nestedUserDataName())) {
                    priceIncrementStr = userDataGrp1.nestedUserDataValue();
                    break;
                }
            }

            final String symbol6 = SymbolNormaliser.toSymbol6(symGrp_1.symbol());
            final double priceIncrement = priceIncrementStr == null ? 0.0 : Double.parseDouble(priceIncrementStr);
            final double[] values = new double[]{symGrp_1.priceDepth(), priceIncrement, symGrp_1.priceDepthRange()};

            final SecurityType securityType = FixCFICode.from(symGrp_1.cFICode());
            final Tenor tenor = tenorLookup.anzTenor(symGrp_1.settlType());
            if (securityType == null || tenor == null || priceIncrement == 0.0) {
                LOGGER.warn("Skip. Can not parse EbsBookRulesConfig for symbol={} securityType={} tenor={} {}", symbol6, securityType, tenor, symGrp_1);
                continue;
            }

            final InstrumentKey instrumentKey = InstrumentKey.of(symbol6, securityType, tenor);
            final EbsBookRules.Config config = toConfig(instrumentKey, values);
            LOGGER.info("Add to Config: {} {}", instrumentKey, config);
            configByInstrument.put(instrumentKey.instrumentId(), config);
        }
    }

    private static int toIntegral(final double[] depthIncrementSteps, int index, final String valueName, final String symbol) {
        final double value = depthIncrementSteps[index];
        final int integral = (int)value;
        if (integral != value) {
            throw new IllegalArgumentException(valueName + " boolRule value with index=" + index +
                    " must be integral but was " + value + " for " + symbol);
        }
        return integral;
    }

    private EbsBookRules.Config toConfig(final InstrumentKey instrumentKey, final double[] depthIncrementSteps) {
        if (depthIncrementSteps == null) {
            throw new IllegalArgumentException("bookRules is null for " + instrumentKey.symbol());
        }
        if (depthIncrementSteps.length != 3) {
            throw new IllegalArgumentException("Expected 3 values (PriceDepth, PriceDepthRange.Increment, PriceDepthRange.Steps) in bookRules but found " +
                    depthIncrementSteps.length + " for " + instrumentKey.symbol());
        }
        final int depth = toIntegral(depthIncrementSteps, INDEX_PRICE_DEPTH, "PriceDepth", instrumentKey.symbol());
        final double priceRangeIncrement = depthIncrementSteps[INDEX_PRICE_RANGE_INCREMENT];
        final int priceRangeSteps = toIntegral(depthIncrementSteps, INDEX_PRICE_RANGE_STEPS, "PriceDepthRange.Steps", instrumentKey.symbol());
        return new DefaultEbsBookRules.DefaultConfig(instrumentKey, depth, priceRangeIncrement, priceRangeSteps);
    }

    public static class DefaultConfig implements Config {

        private final InstrumentKey instrumentKey;
        private final int depth;
        private final double priceRangeIncrement;
        private final int priceRangeSteps;

        public DefaultConfig(final InstrumentKey instrumentKey, final int depth, final double priceRangeIncrement, final int priceRangeSteps) {
            this.instrumentKey = Objects.requireNonNull(instrumentKey);
            this.depth = depth;
            this.priceRangeIncrement = priceRangeIncrement;
            this.priceRangeSteps = priceRangeSteps;
        }
        @Override
        public int depth() {
            return depth;
        }

        @Override
        public double priceRangeIncrement() {
            return priceRangeIncrement;
        }

        @Override
        public int priceRangeSteps() {
            return priceRangeSteps;
        }

        @Override
        public String toString() {
            return "DefaultConfig{" +instrumentKey +
                    ", depth=" + depth +
                    ", priceRangeIncrement=" + priceRangeIncrement +
                    ", priceRangeSteps=" + priceRangeSteps +
                    '}';
        }
    }
}
