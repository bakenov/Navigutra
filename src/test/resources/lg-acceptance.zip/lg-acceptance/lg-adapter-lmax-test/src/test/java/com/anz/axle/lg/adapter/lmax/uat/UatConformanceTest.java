package com.anz.axle.lg.adapter.lmax.uat;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.fix4j.test.util.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.Session;
import quickfix.field.ClOrdID;
import quickfix.field.Currency;
import quickfix.field.HandlInst;
import quickfix.field.MassCancelRequestType;
import quickfix.field.MaxShow;
import quickfix.field.MsgType;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.OrigClOrdID;
import quickfix.field.Price;
import quickfix.field.SecurityExchange;
import quickfix.field.SecurityReqID;
import quickfix.field.SecurityRequestType;
import quickfix.field.SecurityStatusReqID;
import quickfix.field.SubscriptionRequestType;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix42.OrderCancelReplaceRequest;
import quickfix.fix42.OrderCancelRequest;
import quickfix.fix42.SecurityDefinitionRequest;
import quickfix.fix42.SecurityStatusRequest;
import quickfix.fix44.OrderMassCancelRequest;

import com.anz.axle.applicationboot.Application;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener;
import com.anz.axle.lg.adapter.lmax.acceptance.AcceptanceConfig;
import com.anz.axle.lg.adapter.lmax.acceptance.AcceptanceContext;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.adapter.acceptance.utils.PriceListener.PriceEntry;
import com.anz.axle.lg.util.SymbolNormaliser;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.UpdateAction;
import com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.IncrementalRefresh;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessageVisitor;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;
import com.anz.markets.efx.trading.codec.api.ExecType;
import com.anz.markets.efx.trading.codec.api.OrderStatus;
import com.anz.markets.efx.trading.codec.api.OrderType;
import com.anz.markets.efx.trading.codec.api.Side;
import com.anz.markets.efx.trading.codec.api.TimeInForce;
import com.anz.markets.efx.trading.codec.pojo.matcher.ExecutionReportMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.ExecutionReport;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

import static com.anz.markets.efx.pricing.codec.pojo.matcher.IncrementalRefreshMatcher.mdUpdateAction;
@Ignore("long running uat test to be ignored")
public class UatConformanceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(UatConformanceTest.class);
    public static final String GB_LG_LMAX = "GB:lg-lmax";
    public static final String GB_LG_ACC = "GB:lg-acc";
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private OrderRepository orderRepository;

    @Before
    public void setup() throws Exception {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        System.getProperties().putAll(
            StringUtils.parseMap(
                "appName:lg-lmax" +
//                ",lmax.fix.log.destination:STDOUT" +
                ",lmax.fix.log.destination:FILE" +
                ",lmax.fix.pricing.sendercompid:anzmd1" +
                ",lmax.fix.pricing.targetcompid:LMAXIBB-MD" +
//                ",lmax.fix.pricing.host:10.54.180.252" +
//                ",lmax.fix.pricing.port:443" +
//                        ",lmax.fix.pricing.host:localhost" +
                        ",lmax.fix.pricing.host:daxa003z.unix.anz" +
                        ",lmax.fix.pricing.port:14179" +
                ",lmax.fix.pricing.password:anzmdibank1" +

                ",lmax.fix.trading.reset.on.logon:N" +
                ",lmax.fix.trading.reset.on.logout:N" +
                ",lmax.fix.trading.reset.on.disconnect:N" +

//                ",lmax.fix.trading.sendercompid:anzfxuat1" +
                ",lmax.fix.trading.sendercompid:anzibank2" +
                ",lmax.fix.trading.targetcompid:FIX-API" +
//                ",lmax.fix.trading.host:10.54.180.250" +
//                ",lmax.fix.trading.port:443" +
                        ",lmax.fix.trading.host:daxa003z.unix.anz" +
                        ",lmax.fix.trading.port:14177" +
//                ",lmax.fix.trading.password:anzfxuat1" +
                ",lmax.fix.trading.password:anzibank2" +
                ",lmax.fix.account:ANZBANK2" +
                ",lmax.fix.heartbeat.interval.seconds:10" +
                ",ValidateUserDefinedFields:N" +
                ",ValidateFieldsOutOfOrder:N" +
                ",ValidateFieldsHaveValues:N"
            ));

        application = new Application("lg-lmax-acceptance", AcceptanceConfig.class);
        application.startAndAwaitStarted();

        acceptanceContext = application.getApplicationContext().getBean("acceptanceContext", AcceptanceContext.class);
        acceptanceContext.tradingResponseMessageQueue().clear();

        orderRepository = new OrderRepository();
        TimeUnit.SECONDS.sleep(20);
    }

    private static final Side SIDE = Side.BUY;
    private static final EntryType ENTRYTYPE_SIDE = (SIDE == Side.SELL)  ? EntryType.BID : EntryType.OFFER;
    private static final double PRICE_OFFSET = 0.0005;

    @After
    public void afterEach() {
        application.stop();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    //@Ignore
    @Test
    public void logonAndWait() throws Exception {
       for (int i = 0; i < 5; i++) {
            System.out.println("==wait "+(i+1)+"============================================================");
            orderRepository.receivedUpdate = false;
            captureExecutionReports(5, 1);
            if (orderRepository.receivedUpdate) {
                orderRepository.dumpOrdersAndExecutions();
            }
        }
    }

    //@Ignore
    @Test
    public void logonAndWaitForDisconnect() throws Exception {
        final PriceEntry onDisconnect = onDisconnect(5);
        if (onDisconnect != null) {
            captureExecutionReports(10, 5);
        }
    }

    //@Ignore
    @Test
    public void testAll() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        //newOrderSingle_ER_LIMIT_GFD_4_1();
        newOrderSingle_Client_Logout_Cancel_ER_4_2();
        orderCancelReplace_ER_LIMIT_GFD_4_3_1();
        orderCancelReplace_ER_LIMIT_GFD_4_3_3();
        orderCancelReplace_ER_LIMIT_GFD_4_3_5();
    }

    @Test
    public void submit_SecurityDefinitionRequest_and_receive_SecurityDefinitions_for_all_tradeable_instruments_on_LMAX_2_1_1() throws Exception {
        // request to trading session
        final SecurityDefinitionRequest securityDefinitionRequest = new SecurityDefinitionRequest();
        final String securityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-DR";
        securityDefinitionRequest.setString(SecurityExchange.FIELD, "LMAX");
        securityDefinitionRequest.setString(SecurityReqID.FIELD, securityReqID);
        securityDefinitionRequest.setInt(SecurityRequestType.FIELD, 0);

        // SecurityDefinitionRequest (c) & receive SecurityDefinition (d) - received on trading session
        acceptanceContext.fixMessageSender().accept(securityDefinitionRequest);
        TimeUnit.SECONDS.sleep(5);
    }

    @Test
    public void submit_SecurityStatusRequest_for_instrument_and_receive_single_SecurityStatus_snapshot_LMAX_2_2_1() throws Exception {

        // Submit SecurityStatusRequest for an open instrument and receive single SecurityStatus snapshot
        final SecurityStatusRequest statusRequest = new SecurityStatusRequest();
        final String securityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-SR";
        statusRequest.setString(SecurityExchange.FIELD, "LMAX");
        statusRequest.setString(SecurityStatusReqID.FIELD, securityReqID);
        statusRequest.setInt(SubscriptionRequestType.FIELD, 1); //1= SNAPSHOT PLUS UPDATES 2=DISABLE PREVIOUS
        statusRequest.setString(Symbol.FIELD, "GBP/USD");

        // SecurityStatusRequest (e) & receive SecurityStatus (f) - Snapshot
        // request to pricing session
        Session.sendToTarget(statusRequest, acceptanceContext.pricingSessionId());
        /*
        20171212-01:45:48.857: 8=FIX.4.2|9=109|35=e|34=52|49=anzmd1|52=20171212-01:45:48.857|56=LMAXIBB-MD|55=GBP/USD|207=LMAX|263=1|324=151304312521401-SR|10=202|
        20171212-01:45:49.174: 8=FIX.4.2|9=123|35=f|49=LMAXIBB-MD|56=anzmd1|34=99|52=20171212-01:45:49.027|324=151304312521401-SR|22=8|55=GBP/USD|207=LMAX|326=17|48=3002|10=072|
         */
        TimeUnit.SECONDS.sleep(20);
    }

    @Test
    public void submit_SecurityStatusRequest_for_closed_suspended_instrument_and_receive_single_SecurityStatus_snapshot_2_2_2() throws Exception {
        // Submit SecurityStatusRequest for an open instrument and receive single SecurityStatus snapshot
        final SecurityStatusRequest statusRequest = new SecurityStatusRequest();
        final String securityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-SR";
        statusRequest.setString(SecurityExchange.FIELD, "LMAX");
        statusRequest.setString(SecurityStatusReqID.FIELD, securityReqID);
        statusRequest.setInt(SubscriptionRequestType.FIELD, 1); //1= SNAPSHOT PLUS UPDATES 2=DISABLE PREVIOUS
        statusRequest.setString(Symbol.FIELD, "GBP/XXX");

        // SecurityStatusRequest (e) & receive SecurityStatus (f) - Snapshot
        Session.sendToTarget(statusRequest, acceptanceContext.pricingSessionId());
        /*
        20171212-02:37:35.967: 8=FIX.4.2|9=109|35=e|34=52|49=anzmd1|52=20171212-02:37:35.967|56=LMAXIBB-MD|55=GBP/XXX|207=LMAX|263=1|324=151304623066901-SR|10=244|
        20171212-02:37:36.279: 8=FIX.4.2|9=116|35=f|49=LMAXIBB-MD|56=anzmd1|34=111|52=20171212-02:37:36.102|22=8|324=151304623066901-SR|55=GBP/XXX|207=LMAX|326=20|10=024|
        326=20 (20= Unknown or Invalid)
         */
        TimeUnit.SECONDS.sleep(20);
    }

    @Test
    public void submit_SecurityStatusRequest_for_open_instrument_and_receive_single_SecurityStatus_snapshot_followed_by_updates_2_3_1() throws Exception {
        // Submit SecurityStatusRequest for an open instrument and receive single SecurityStatus snapshot
        final SecurityStatusRequest statusRequest = new SecurityStatusRequest();
        final String securityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-SR";
        statusRequest.setString(SecurityExchange.FIELD, "LMAX");
        statusRequest.setString(SecurityStatusReqID.FIELD, securityReqID);
        statusRequest.setInt(SubscriptionRequestType.FIELD, 1); //1= SNAPSHOT PLUS UPDATES 2=DISABLE PREVIOUS
        statusRequest.setString(Symbol.FIELD, "GBP/USD");

        // SecurityStatusRequest (e) & receive SecurityStatus (f) - Snapshot
        Session.sendToTarget(statusRequest, acceptanceContext.pricingSessionId());

        // wait for status change
        TimeUnit.SECONDS.sleep(300);
    }

    @Test
    public void submit_SecurityStatusRequest_to_unsubscribe_and_stop_receiving_updates_2_4_1() throws Exception {
        // Submit SecurityStatusRequest for an open instrument and receive single SecurityStatus snapshot
        final SecurityStatusRequest statusRequest = new SecurityStatusRequest();
        final String securityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-SR";
        statusRequest.setString(SecurityExchange.FIELD, "LMAX");
        statusRequest.setString(SecurityStatusReqID.FIELD, securityReqID);
        statusRequest.setInt(SubscriptionRequestType.FIELD, 1); //1= SNAPSHOT PLUS UPDATES 2=DISABLE PREVIOUS
        statusRequest.setString(Symbol.FIELD, "GBP/USD");

        // SecurityStatusRequest (e) & receive SecurityStatus (f) - Snapshot
        Session.sendToTarget(statusRequest, acceptanceContext.pricingSessionId());
        TimeUnit.SECONDS.sleep(5);

        // Un-subscribe
        final SecurityStatusRequest unscribeRequest = new SecurityStatusRequest();
        final String unscribeSecurityReqID = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-SR";
        unscribeRequest.setString(SecurityExchange.FIELD, "LMAX");
        unscribeRequest.setString(SecurityStatusReqID.FIELD, unscribeSecurityReqID);
        unscribeRequest.setInt(SubscriptionRequestType.FIELD, 2); //1= SNAPSHOT PLUS UPDATES 2=DISABLE PREVIOUS
        unscribeRequest.setString(Symbol.FIELD, "GBP/USD");
        Session.sendToTarget(statusRequest, acceptanceContext.pricingSessionId());
        TimeUnit.SECONDS.sleep(10);
    }

    @Test
    public void newOrderSingle_ER_LIMIT_GFD_4_1() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        newOrderSingle_captureExecution(true,"EURUSD", Side.SELL, OrderType.LIMIT, TimeInForce.DAY, ExecType.TRADE, OrderStatus.FILLED);
        newOrderSingle_captureExecution(false,"EURCAD", Side.BUY, OrderType.LIMIT, TimeInForce.DAY, ExecType.TRADE, OrderStatus.FILLED);
    }

    @Test
    public void newOrderSingle_Client_Logout_Cancel_ER_4_2() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();

        final PriceEntry priceEntry = awaitSnapshotPrice(InstrumentKey.of("EURUSD", SecurityType.FXSPOT, Tenor.SP).instrumentId(), Side.BUY);
        final Side nosSide = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, nosSide);
        priceEntry.size *= 10;
        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, priceEntry.side, clOrdId, priceEntry);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        captureExecutionReports(2, 5);
        orderRepository.dumpOrdersAndExecutions();
        /*
            @After will logout
            re-logon again to receive cancel order. Make sure trading resets are N.
            Should look like this:
            20171204-20:55:17.103: 8=FIX.4.2|9=184|35=D|34=9|49=anzibank2|52=20171204-20:55:17.102|56=FIX-API|1=ANZBANK2|11=151242089388901|15=EUR|21=1|38=250000000|40=2|44=1.18509|54=1|55=EUR/USD|59=0|60=20171204-20:55:17.042|167=FOR|10=114|
            20171204-20:55:17.462: 8=FIX.4.2|9=249|35=8|49=FIX-API|56=anzibank2|34=12|52=20171204-20:55:17.850|60=20171204-20:55:17.850|20=0|22=8|6=0|11=151242089388901|17=QACFOAAAAAF5OMBH|48=3001|55=EUR/USD|1=13003|37=QACFOAAAAABMGJ5X|151=250000000|14=0|38=250000000|54=1|44=1.18509|59=0|150=0|39=0|10=093|
            20171204-20:55:18.992: 8=FIX.4.2|9=60|35=5|34=10|49=anzibank2|52=20171204-20:55:18.992|56=FIX-API|10=125|
            20171204-20:55:19.335: 8=FIX.4.2|9=60|35=5|49=FIX-API|56=anzibank2|34=13|52=20171204-20:55:19.729|10=127|
            -- re-logon here -- note PossDupFlag(43=Y) Cancel (150=4)
            20171204-20:59:14.036: 8=FIX.4.2|9=90|35=A|34=11|49=anzibank2|52=20171204-20:59:14.036|56=FIX-API|95=9|96=anzibank2|98=0|108=10|10=171|
            20171204-20:59:14.396: 8=FIX.4.2|9=72|35=A|49=FIX-API|56=anzibank2|34=15|52=20171204-20:59:14.452|98=0|108=10|10=159|
            20171204-20:59:14.402: 8=FIX.4.2|9=70|35=2|34=12|49=anzibank2|52=20171204-20:59:14.402|56=FIX-API|7=14|16=0|10=030|
            20171204-20:59:14.741: 8=FIX.4.2|9=288|35=8|49=FIX-API|56=anzibank2|34=14|43=Y|52=20171204-20:59:14.805|122=20171204-20:55:19.729|60=20171204-20:55:19.729|20=0|22=8|6=0|11=151242089388901|17=QACF
         */
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_1() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 2);

        // Submit OrderCancelReplaceRequest to change price of a zero-filled order - Buy
        final NewOrderSingle newOrderSingleBuy = sendRestingOrder("EURUSD", Side.BUY);
        newOrderSingleBuy.body.price -= 0.01;
        final String clOrdIdBuy = sendOrderCancelReplaceRequest(newOrderSingleBuy);
        final Queue<TradingMessage> responseMessages = captureExecutionReports(5, 5);
        assertExecutionReceived(responseMessages, newOrderSingleBuy, clOrdIdBuy, OrderStatus.REPLACED, ExecType.REPLACED);

        // Submit OrderCancelReplaceRequest to change price of a zero-filled order - Sell
        final NewOrderSingle newOrderSingleSell = sendRestingOrder("EURGBP", Side.SELL);
        newOrderSingleSell.body.price += 0.01;
        final String clOrdIdSell = sendOrderCancelReplaceRequest(newOrderSingleSell);
        final Queue<TradingMessage> responseMessages2 = captureExecutionReports(5, 5);
        assertExecutionReceived(responseMessages2, newOrderSingleSell, clOrdIdSell, OrderStatus.REPLACED, ExecType.REPLACED);

        orderRepository.dumpOrdersAndExecutions();
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_3() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Submit OrderCancelReplaceRequest to change price of a part-filled order - Buy
        final NewOrderSingle newOrderSingleBuy = buildPartiallyFilledRestingOrder("EURUSD", Side.BUY);
        sendAndWaitForExecution(newOrderSingleBuy.body.clOrdId, newOrderSingleBuy, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);

        newOrderSingleBuy.body.price -= 0.01;
        final String clOrdIdBuy = sendOrderCancelReplaceRequest(newOrderSingleBuy);

        final ExecutionReportMatcher buyMatcher = buildExecutionReportMatcher(newOrderSingleBuy, clOrdIdBuy, ExecType.REPLACED, OrderStatus.PARTIALLY_FILLED);
        captureOrMatchExecutionReports(10, 5, buyMatcher);

        //Submit OrderCancelReplaceRequest to change price of a part-filled order - Sell
        final NewOrderSingle newOrderSingleSell = buildPartiallyFilledRestingOrder("EURGBP", Side.SELL);
        sendAndWaitForExecution(newOrderSingleSell.body.clOrdId, newOrderSingleSell, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);

        newOrderSingleSell.body.price += 0.01;
        final String clOrdIdSell = sendOrderCancelReplaceRequest(newOrderSingleSell);
        final ExecutionReportMatcher sellMatcher = buildExecutionReportMatcher(newOrderSingleSell, clOrdIdSell, ExecType.REPLACED, OrderStatus.PARTIALLY_FILLED);
        captureOrMatchExecutionReports(10, 5, sellMatcher);

        captureExecutionReports(50, 1);
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_5() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        //Submit OrderCancelReplaceRequest to change Qty of a part-filled order where new Qty is greater than Executed Qty
        submit_OrderCancelReplaceRequest_to_change_Qty_of_a_part_filled_order((q) -> q * 100);
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_7() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        //Submit OrderCancelReplaceRequest to change Qty of a part-filled order where new Qty equals Executed Qty
        submit_OrderCancelReplaceRequest_to_change_Qty_of_a_part_filled_order((q) -> q);
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_9() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        //Submit OrderCancelReplaceRequest to change Qty of a part-filled order where new Qty is less than Executed Qty
        submit_OrderCancelReplaceRequest_to_change_Qty_of_a_part_filled_order((q) -> q / 10);
    }

    @Test
    public void orderCancelReplace_ER_LIMIT_GFD_4_3_11() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        final NewOrderSingle newOrderSingleBuy = buildPartiallyFilledRestingOrder("EURUSD", Side.BUY);
        final ExecutionReport partiallyFilledER = (ExecutionReport)sendAndWaitForExecution(newOrderSingleBuy.body.clOrdId, newOrderSingleBuy, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);

        newOrderSingleBuy.body.price = partiallyFilledER.body.lastPx;
        newOrderSingleBuy.body.orderQty = partiallyFilledER.body.lastQty;
        final String clOrdIdBuy = sendOrderCancelReplaceRequest(newOrderSingleBuy);

        final ExecutionReportMatcher buyMatcher = buildExecutionReportMatcher(newOrderSingleBuy, clOrdIdBuy, ExecType.REPLACED, OrderStatus.PARTIALLY_FILLED);
        captureOrMatchExecutionReports(10, 5, buyMatcher);
    }

    @Test
    public void orderCancelReplace_OrderCancelReject_LIMIT_4_4() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        // Receive OrderCancelReject when submitted OrderCancelReplaceRequest on a fully-filled order
        final NewOrderSingle newOrderSingle = newOrderSingle_captureExecution(true,"EURUSD", Side.SELL, OrderType.LIMIT, TimeInForce.DAY, ExecType.TRADE, OrderStatus.FILLED);
        sendOrderCancelReplaceRequest(newOrderSingle);
        /* replaceRequest(G) and cancelReject(9)
        20171205-22:39:01.326: 8=FIX.4.2|9=179|35=G|34=21|49=anzibank2|52=20171205-22:39:01.326|56=FIX-API|11=151251351576701-R|21=1|38=67000000|40=2|41=151251351576701|44=1.18312|54=1|55=EUR/USD|59=0|60=20171205-22:39:01.325|10=153|
        20171205-22:39:01.644: 8=FIX.4.2|9=150|35=9|49=FIX-API|56=anzibank2|34=29|52=20171205-22:39:01.476|1=13003|11=151251351576701-R|37=NONE|39=8|41=151251351576701|58=UNKNOWN_ORDER|102=1|434=2|10=094|
         */

        TimeUnit.SECONDS.sleep(2);

        // Send an OrderCancelRequest when receiving an OrderCancelReject (VERY IMPORTANT)
        sendOrderCancelRequest(newOrderSingle);
        /* try to cancel(F) filled order and received reject(9)
        20171205-22:39:03.326: 8=FIX.4.2|9=141|35=F|34=22|49=anzibank2|52=20171205-22:39:03.326|56=FIX-API|11=151251351576701-C|41=151251351576701|54=1|55=EUR/USD|60=20171205-22:39:03.326|10=200|
        20171205-22:39:03.644: 8=FIX.4.2|9=150|35=9|49=FIX-API|56=anzibank2|34=30|52=20171205-22:39:03.476|1=13003|11=151251351576701-C|37=NONE|39=8|41=151251351576701|58=UNKNOWN_ORDER|102=1|434=1|10=072|
         */
    }

    @Test
    public void orderCancelRequest_LIMIT_4_5() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);
    }

    @Test
    public void orderCancel_Filled_OrderCancelReject_LIMIT_4_6() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Receive OrderCancelReject when submitted OrderCancelRequest on a fully-filled order
        final NewOrderSingle newOrderSingle = newOrderSingle_captureExecution(true,"EURUSD", Side.SELL, OrderType.LIMIT, TimeInForce.DAY, ExecType.TRADE, OrderStatus.FILLED);
        sendOrderCancelRequest(newOrderSingle);
        /*
        20171205-22:50:54.702: 8=FIX.4.2|9=141|35=F|34=27|49=anzibank2|52=20171205-22:50:54.702|56=FIX-API|11=151251422879201-C|41=151251422879201|54=1|55=EUR/USD|60=20171205-22:50:54.702|10=199|
        20171205-22:50:55.023: 8=FIX.4.2|9=150|35=9|49=FIX-API|56=anzibank2|34=38|52=20171205-22:50:54.879|1=13003|11=151251422879201-C|37=NONE|39=8|41=151251422879201|58=UNKNOWN_ORDER|102=1|434=1|10=086|
         */
    }

    @Test
    public void newOrderSingle_ER_New_PartFilled_Filled_Cancel_LIMIT_IOC_4_7() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Submit a Limit (IOC) order and receive ExecutionReport (New) - Buy/Sell
        submit_order_receive_ExecutionReport_New_Filled(OrderType.LIMIT, TimeInForce.IOC,"EURDKK", Side.BUY);
        submit_order_receive_ExecutionReport_New_Filled(OrderType.LIMIT, TimeInForce.IOC,"EURGBP", Side.SELL);

        //Receive a Part Filled ExecutionReport(s) followed by Cancelled ExecutionReport when Limit (IOC) is partially filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.LIMIT, TimeInForce.IOC, "EURUSD", Side.BUY);
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.LIMIT, TimeInForce.IOC,"EURGBP", Side.SELL);

        //Receive multiple ExecutionReports when Limit (IOC) is filled in multiple executions - Buy/Sell
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Filled(OrderType.LIMIT, TimeInForce.IOC,"EURGBP", Side.BUY);
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Filled(OrderType.LIMIT, TimeInForce.IOC,"EURUSD", Side.SELL);

        //Receive a Cancelled ExecutionReport when Limit (IOC) cannot be filled (price unavailable) - Buy/Sell
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.LIMIT, TimeInForce.IOC, "EURGBP", Side.BUY);
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.LIMIT, TimeInForce.IOC, "EURCAD", Side.SELL);
    }

    @Test
    public void register_executions_using_LastPX_and_LastShares_LIMIT_IOC_4_7_11() throws Exception {
        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        register_executions_using_LastPX_and_LastShares(OrderType.LIMIT, TimeInForce.IOC, "EURUSD", Side.SELL);
    }

    @Test
    public void newOrderSingle_ER_New_Filled_MARKET_FOK_4_8_1_10() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Receive New/Filled ExecutionReport when Market (FOK) is fully filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.FOK, "EURUSD", Side.BUY);
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.FOK,"EURGBP", Side.SELL);

        //Receive multiple ExecutionReports when Market (FOK) is filled in multiple executions - Buy/sell
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Filled(OrderType.MARKET, TimeInForce.FOK,"EURDKK", Side.BUY);
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Filled(OrderType.MARKET, TimeInForce.FOK,"EURGBP", Side.SELL);

        //Receive a Cancelled ExecutionReport when Market (FOK) cannot be filled (qty unavailable) - Buy/Sell
        cancelled_ExecutionReport_when_cannot_be_filled_qty_unavailable(OrderType.MARKET, TimeInForce.FOK, "EURGBP", Side.BUY);
        cancelled_ExecutionReport_when_cannot_be_filled_qty_unavailable(OrderType.MARKET, TimeInForce.FOK, "EURUSD", Side.SELL);
    }

    @Test
    public void register_executions_using_LastPX_and_LastShares_MARKET_FOK_4_8_11() throws Exception {
        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        register_executions_using_LastPX_and_LastShares(OrderType.MARKET, TimeInForce.FOK, "EURUSD", Side.SELL);
    }

    @Test
    public void newOrderSingle_ER_New_Filled_MARKET_IOC_4_9() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Receive New/Filled ExecutionReport when Market (IOC) is fully filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.IOC, "EURUSD", Side.BUY);
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.IOC,"EURGBP", Side.SELL);

        //Receive a Part Filled ExecutionReport(s) followed by Cancelled ExecutionReport when Market (IOC) is partially filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.MARKET, TimeInForce.IOC,"EURUSD", Side.BUY);
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.MARKET, TimeInForce.IOC,"EURGBP", Side.SELL);

        //Receive a Cancelled ExecutionReport when Market (IOC) cannot be filled (price unavailable) - Buy/sell
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.MARKET, TimeInForce.IOC,"EURGBP", Side.BUY);
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.MARKET, TimeInForce.IOC,"EURUSD", Side.SELL);

        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        register_executions_using_LastPX_and_LastShares(OrderType.MARKET, TimeInForce.IOC);
    }

    @Test
    public void newOrderSingle_ER_New_Filled_MARKET_FOK_4_10() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Receive New/Filled ExecutionReport when Market (FOK) is fully filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.FOK, "EURUSD", Side.BUY);
        submit_order_receive_ExecutionReport_New_Filled(OrderType.MARKET, TimeInForce.FOK,"EURGBP", Side.SELL);

        //Receive a Part Filled ExecutionReport(s) followed by Cancelled ExecutionReport when Market (FOK) is partially filled - Buy/Sell
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.MARKET, TimeInForce.FOK,"EURAUD", Side.BUY);
        submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(OrderType.MARKET, TimeInForce.FOK,"EURHKH", Side.SELL);

        //Receive a Cancelled ExecutionReport when Market (FOK) cannot be filled (price unavailable) - Buy/sell
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.MARKET, TimeInForce.FOK,"EURJPY", Side.BUY);
        cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(OrderType.MARKET, TimeInForce.FOK,"EURSEK", Side.SELL);

        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        register_executions_using_LastPX_and_LastShares(OrderType.MARKET, TimeInForce.FOK);
    }

    @Test
    public void newOrderSingle_ER_New_Filled_Limit_DAY_Iceberg_4_12() throws Exception {
        System.out.println(String.format("---------------- Running: %s", testName.getMethodName()));
        // capture prev session cancels
        captureExecutionReports(20, 1);

        sendAsIcebregOrder(buildfullyFilledOrder(OrderType.LIMIT, TimeInForce.GTD, "EURAUD", Side.BUY));
        captureExecutionReports(20, 20);
        sendAsIcebregOrder(buildfullyFilledOrder(OrderType.LIMIT, TimeInForce.GTD, "EURCAD", Side.SELL));
        captureExecutionReports(20, 20);


        sendAsIcebregOrder(buildPartiallyFilledOrder(OrderType.LIMIT, TimeInForce.GTD, "EURJPY", Side.BUY));
        captureExecutionReports(20, 20);
        sendAsIcebregOrder(buildPartiallyFilledOrder(OrderType.LIMIT, TimeInForce.GTD, "EURSEK", Side.SELL));
        captureExecutionReports(20, 20);

    }

    private void register_executions_using_LastPX_and_LastShares(final OrderType orderType, final TimeInForce timeInForce) throws Exception {
        register_executions_using_LastPX_and_LastShares(orderType, timeInForce, "EURCAD", Side.BUY);
    }

    private void register_executions_using_LastPX_and_LastShares(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
        //Register executions using LastPX (tag 31) and LastShares (tag 32)
        final NewOrderSingle newOrderSingle = buildOrderFromMarketData(orderType, timeInForce, symbol, side, 1, true, true);

        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 2);
        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-lmax"))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(newOrderSingle.body.clOrdId))
                .body().matches(ExecutionReportMatcher.lastQty().eq(newOrderSingle.body.orderQty))
                .body().matches(ExecutionReportMatcher.execType().eq(ExecType.TRADE))
                .body().matches(ExecutionReportMatcher.ordStatus().eq(OrderStatus.FILLED))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().hasAny();
        if (Side.BUY == side) {
            matcher.body().matches(ExecutionReportMatcher.lastPx().le(newOrderSingle.body.price));
        } else {
            matcher.body().matches(ExecutionReportMatcher.lastPx().ge(newOrderSingle.body.price));
        }
        Asserter.of(messages)
                .matching(matcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void submit_order_receive_ExecutionReport_New_Filled(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
//        final NewOrderSingle newOrderSingle = buildfullyFilledOrder(orderType, timeInForce, symbol, side);
        final NewOrderSingle newOrderSingle = buildOrderFromMarketData(orderType, timeInForce, symbol, side, 1, false, true);

        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 2);
        final ExecutionReportMatcher newMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.NEW, OrderStatus.NEW);
        final ExecutionReportMatcher filledMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.TRADE, OrderStatus.FILLED);
        Asserter.of(messages)
                .matching(newMatcher)
                .thenMatching(filledMatcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void submit_order_receive_ExecutionReport_New_PartiallyFilled_Filled(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
//        final NewOrderSingle newOrderSingle = buildOrderFromMarketData(orderType, timeInForce, symbol, side, 5, false, false);
        final NewOrderSingle newOrderSingle = buildOrderFromMarketData(orderType, timeInForce, symbol, side, 5, false, true);
        newOrderSingle.body.price = inMarketPrice(newOrderSingle.body.price, side);
        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 10);
        final ExecutionReportMatcher newMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.NEW, OrderStatus.NEW);
        final ExecutionReportMatcher partiallyFilledMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);
        final ExecutionReportMatcher filledMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.TRADE, OrderStatus.FILLED);
        Asserter.of(messages)
                .matching(newMatcher)
                .thenMatching(partiallyFilledMatcher)
                .thenMatching(filledMatcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void cancelled_ExecutionReport_when_cannot_be_filled_qty_unavailable(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
        final NewOrderSingle newOrderSingle = buildfullyFilledOrder(orderType, timeInForce, symbol, side);
        newOrderSingle.body.price *= 1000;
        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 2);
        final ExecutionReportMatcher newMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.NEW, OrderStatus.NEW);
        final ExecutionReportMatcher cancelMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.CANCELED, OrderStatus.CANCELED);
        Asserter.of(messages)
                .matching(newMatcher)
                .thenMatching(cancelMatcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void cancelled_ExecutionReport_when_cannot_be_filled_price_unavailable(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
        final NewOrderSingle newOrderSingle = buildfullyFilledOrder(orderType, timeInForce, symbol, side);
        newOrderSingle.body.price = offMarketPrice(newOrderSingle.body.price, side);
        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 2);
        final ExecutionReportMatcher newMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.NEW, OrderStatus.NEW);
        final ExecutionReportMatcher cancelMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.CANCELED, OrderStatus.CANCELED);
        Asserter.of(messages)
                .matching(newMatcher)
                .thenMatching(cancelMatcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void submit_order_receive_ExecutionReport_New_PartiallyFilled_Cancel(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side side) throws Exception {
//        final NewOrderSingle newOrderSingle = buildPartiallyFilledOrder(orderType, timeInForce, symbol, side);
        final NewOrderSingle newOrderSingle = buildOrderFromMarketData(orderType, timeInForce, symbol, side, 10, true, true);

        final Queue<TradingMessage> messages = sendAndCaptureExecution(newOrderSingle, 5, 2);
        final ExecutionReportMatcher newMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.NEW, OrderStatus.NEW);
        final ExecutionReportMatcher partiallyFilledMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);
        final ExecutionReportMatcher cancelMatcher = buildExecutionReportMatcher(newOrderSingle.body.clOrdId, ExecType.CANCELED, OrderStatus.CANCELED);
        Asserter.of(messages)
                .matching(newMatcher)
                .thenMatching(partiallyFilledMatcher)
                .thenMatching(cancelMatcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private void submit_OrderCancelReplaceRequest_to_change_Qty_of_a_part_filled_order(final Function<Double, Double> qtyModifier) throws Exception {
        // capture prev session cancels
        captureExecutionReports(20, 1);

        //Submit OrderCancelReplaceRequest to change Qty of a part-filled order where new Qty is greater than Executed Qty - Buy
        final NewOrderSingle newOrderSingleBuy = buildPartiallyFilledRestingOrder("EURUSD", Side.BUY);
        final ExecutionReport partiallyFilledER = (ExecutionReport)sendAndWaitForExecution(newOrderSingleBuy.body.clOrdId, newOrderSingleBuy, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);

        newOrderSingleBuy.body.orderQty = qtyModifier.apply(partiallyFilledER.body.cumQty);
        final String clOrdIdBuy = sendOrderCancelReplaceRequest(newOrderSingleBuy);

        final ExecutionReportMatcher buyMatcher = buildExecutionReportMatcher(newOrderSingleBuy, clOrdIdBuy, ExecType.REPLACED, OrderStatus.PARTIALLY_FILLED);
        captureOrMatchExecutionReports(10, 5, buyMatcher);

        //Submit OrderCancelReplaceRequest to change Qty of a part-filled order where new Qty is greater than Executed Qty - Sell
        final NewOrderSingle newOrderSingleSell = buildPartiallyFilledRestingOrder("EURGBP", Side.SELL);
        final ExecutionReport partiallyFilledERSell = (ExecutionReport)sendAndWaitForExecution(newOrderSingleSell.body.clOrdId, newOrderSingleSell, ExecType.TRADE, OrderStatus.PARTIALLY_FILLED);

        newOrderSingleSell.body.orderQty = qtyModifier.apply(partiallyFilledERSell.body.cumQty);
        final String clOrdIdSell = sendOrderCancelReplaceRequest(newOrderSingleSell);

        final ExecutionReportMatcher sellMatcher = buildExecutionReportMatcher(newOrderSingleSell, clOrdIdSell, ExecType.REPLACED, OrderStatus.PARTIALLY_FILLED);
        captureOrMatchExecutionReports(10, 5, sellMatcher);

        captureExecutionReports(50, 1);
    }

    private NewOrderSingle buildPartiallyFilledRestingOrder(final String symbol, final Side orderSide) {
        return buildPartiallyFilledOrder(OrderType.LIMIT, TimeInForce.DAY, symbol, orderSide);
    }

    private NewOrderSingle buildPartiallyFilledOrder(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side orderSide) {
        return buildOrderFromMarketData(orderType, timeInForce, symbol, orderSide, 100, false, false);
    }

    private NewOrderSingle buildfullyFilledOrder(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side orderSide) {
        return buildOrderFromMarketData(orderType, timeInForce, symbol, orderSide, 1, false, false);
    }

    private NewOrderSingle buildOrderFromMarketData(final OrderType orderType, final TimeInForce timeInForce, final String symbol, final Side orderSide, final double sizeFactor, final boolean useMarketPrice, final boolean snapshotPrice) {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);
        final PriceEntry priceEntry = snapshotPrice ? awaitSnapshotPrice(instrumentKey.instrumentId(), orderSide) : awaitIncrementPrice(instrumentKey.instrumentId(), orderSide);
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = useMarketPrice ? priceEntry.price : inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * sizeFactor;

        return newOrderSingle(orderType, timeInForce, price, side, clOrdId, priceEntry);
    }

    private TradingMessage assertExecutionReceived(Queue<TradingMessage> responseMessages, final NewOrderSingle newOrderSingle, final String clOrdId, final OrderStatus orderStatus, final ExecType execType) throws Exception {
        final ExecutionReportMatcher matcher = buildExecutionReportMatcher(newOrderSingle, clOrdId, execType, orderStatus);
        return Asserter.of(responseMessages)
                .matching(matcher)
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
    }

    private ExecutionReportMatcher buildExecutionReportMatcher(final String clOrdId, final ExecType execType, final OrderStatus orderStatus) {
        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-lmax"))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.marketId().eq(Venue.LMAX.name()))
                .body().matches(ExecutionReportMatcher.execType().eq(execType))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().hasAny();
        if (orderStatus != null) {
            matcher.body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus));
        }
        return matcher;
    }

    private ExecutionReportMatcher buildExecutionReportMatcher(final NewOrderSingle newOrderSingle, final String clOrdId, final ExecType execType, final OrderStatus orderStatus) {
        final ExecutionReportMatcher matcher = ExecutionReportMatcher.build()
                .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-lmax"))
                .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                .body().matches(ExecutionReportMatcher.execType().eq(execType))
                .body().matches(ExecutionReportMatcher.marketId().eq(Venue.LMAX.name()))
                .body().matches(ExecutionReportMatcher.orderQty().eq(newOrderSingle.body.orderQty))
                .body().matches(ExecutionReportMatcher.price().eq(newOrderSingle.body.price))
                .strategyParameters().countEquals(0)
                .regulatoryTradeIds().countEquals(0)
                .hops().hasAny();
        if (orderStatus != null) {
            matcher.body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus));
        }
        return matcher;
    }

    private NewOrderSingle sendRestingOrder(final String symbol, final Side side) throws Exception {
        final String clOrdIdSell = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final NewOrderSingle newOrderSingle = buildRestingOrder(true, clOrdIdSell,symbol, side);
        sendAndWaitForExecution(clOrdIdSell, newOrderSingle, ExecType.NEW, OrderStatus.NEW);
        return newOrderSingle;
    }

    private NewOrderSingle buildRestingOrder(final boolean snapshotPrice, final String clOrdId, final String symbol, final Side side) throws Exception {
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);

        final PriceEntry priceEntry = snapshotPrice ? awaitSnapshotPrice(instrumentKey.instrumentId(), side) : awaitIncrementPrice(instrumentKey.instrumentId(), side);
        final Side nosSide = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, nosSide);
        priceEntry.size *= 10;
        return newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, priceEntry.side, clOrdId, priceEntry);
    }

    private String sendOrderCancelReplaceRequest(final NewOrderSingle newOrderSingle) throws Exception {
        final String clOrdId = newOrderSingle.body.clOrdId + "-R";
        final OrderCancelReplaceRequest orderCancelReplaceRequest = new OrderCancelReplaceRequest();

        orderCancelReplaceRequest.setString(ClOrdID.FIELD, clOrdId);
        orderCancelReplaceRequest.setString(OrigClOrdID.FIELD, newOrderSingle.body.clOrdId);
        orderCancelReplaceRequest.setString(Symbol.FIELD, SymbolNormaliser.toSymbol7(newOrderSingle.body.symbol));
        orderCancelReplaceRequest.setChar(quickfix.field.Side.FIELD, newOrderSingle.body.side == Side.BUY ? '1' : '2');
        orderCancelReplaceRequest.setChar(quickfix.field.OrdType.FIELD, newOrderSingle.body.ordType == OrderType.MARKET ? '1' : '2');
        orderCancelReplaceRequest.setChar(quickfix.field.HandlInst.FIELD, '1');
        orderCancelReplaceRequest.setDouble(quickfix.field.OrderQty.FIELD, newOrderSingle.body.orderQty);
        orderCancelReplaceRequest.setChar(quickfix.field.TimeInForce.FIELD, timeInForce(newOrderSingle.body.timeInForce));

        orderCancelReplaceRequest.setDouble(quickfix.field.Price.FIELD, newOrderSingle.body.price);

        final Date transactTime2 = new Date();
        transactTime2.setTime(System.currentTimeMillis());
        orderCancelReplaceRequest.setUtcTimeStamp(TransactTime.FIELD, transactTime2, true);

        System.out.println(String.format("== send sendOrderCancelReplaceRequest for: clOrdId=%s|orderQty=%2f|price=%2f",
                newOrderSingle.body.clOrdId, newOrderSingle.body.orderQty, newOrderSingle.body.price));
        acceptanceContext.fixMessageSender().accept(orderCancelReplaceRequest);
        return clOrdId;
    }

    private String sendOrderCancelRequest(final NewOrderSingle newOrderSingle) throws Exception {
        final String clOrdId = newOrderSingle.body.clOrdId + "-C";
        final OrderCancelRequest cancelRequest = new OrderCancelRequest();

        cancelRequest.setString(ClOrdID.FIELD, clOrdId);
        cancelRequest.setString(OrigClOrdID.FIELD, newOrderSingle.body.clOrdId);
        cancelRequest.setString(Symbol.FIELD, SymbolNormaliser.toSymbol7(newOrderSingle.body.symbol));
        cancelRequest.setChar(quickfix.field.Side.FIELD, newOrderSingle.body.side == Side.BUY ? '1' : '2');

        final Date transactTime2 = new Date();
        transactTime2.setTime(System.currentTimeMillis());
        cancelRequest.setUtcTimeStamp(TransactTime.FIELD, transactTime2, true);

        System.out.println(String.format("== send sendOrderCancelRequest for: clOrdId=%s|side=%s",
                newOrderSingle.body.clOrdId, newOrderSingle.body.side));
        acceptanceContext.fixMessageSender().accept(cancelRequest);
        return clOrdId;
    }

    //@Ignore
    @Test
    public void partiallyFilled_and_wait() throws Exception {

        final NewOrderSingle newOrderSingle = buildPartiallyFilledOrder();

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        while (true) {
            captureExecutionReports(1, 1);
        }
    }

    //@Ignore
    @Test
    public void testDisconnectLogout() throws Exception {
        TimeUnit.SECONDS.toSeconds(10);
        final PriceEntry priceEntry = onDisconnect(5);
        if (priceEntry != null) {
            orderMassCancelRequest(MassCancelRequestType.CANCEL_ORDERS_FOR_A_SECURITY, priceEntry.instrumentKey.symbol());
        }
    }

    //@Ignore
    @Test
    public void cancel_all_orders() throws Exception {
        TimeUnit.SECONDS.toSeconds(10);
        orderMassCancelRequest(MassCancelRequestType.CANCEL_ALL_ORDERS, null);
        TimeUnit.SECONDS.toSeconds(10);
    }

    //@Ignore
    @Test
    public void send_resting_order_remote_logout_cancel_all() throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice();
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * 50;

        final NewOrderSingle newOrderSingle = newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, side, clOrdId, priceEntry);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        TimeUnit.SECONDS.toSeconds(5);
        captureExecutionReports(3, 30);
        TimeUnit.SECONDS.toSeconds(2);

        final PriceEntry onDisconnect = onDisconnect(5);
        if (onDisconnect != null) {
            captureExecutionReports(10, 5);
//            orderMassCancelRequest(MassCancelRequestType.CANCEL_ALL_ORDERS, onDisconnect.symbol);
        }

        TimeUnit.MINUTES.toSeconds(30);
    }

    //@Ignore
    @Test
    public void send_PartiallyFilled() throws Exception {
        sendAndCaptureExecutions(buildPartiallyFilledOrder());
    }

    //@Ignore
    @Test
    public void send_FullyFilled() throws Exception {
        sendAndCaptureExecutions(fullyFilledNewOrderSingle());
        orderRepository.dumpLastExecutions();
    }

    private void sendAndCaptureExecutions(final NewOrderSingle newOrderSingle) throws Exception {
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        TimeUnit.SECONDS.toSeconds(5);
        captureExecutionReports(3, 10);
        TimeUnit.SECONDS.toSeconds(1);
    }

    private NewOrderSingle fullyFilledNewOrderSingle() {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice(InstrumentKey.of("USDZAR", SecurityType.FXSPOT, Tenor.SP).instrumentId());
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        return newOrderSingle(OrderType.MARKET, TimeInForce.IOC, price, side, clOrdId, priceEntry);
    }

    private NewOrderSingle buildPartiallyFilledOrder() {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final PriceEntry priceEntry = awaitAnyPrice();
        final Side side = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, side);
        priceEntry.size = priceEntry.size * 110;

        return newOrderSingle(OrderType.LIMIT, TimeInForce.DAY, price, side, clOrdId, priceEntry);
    }

    private NewOrderSingle newOrderSingle(final OrderType orderType, final TimeInForce timeInForce, final double price, final Side side, final String clOrdId, final PriceEntry entry) {
        final NewOrderSingle newOrderSingle = new NewOrderSingle();
        newOrderSingle.body.transactTime = acceptanceContext.precisionClock().nanos();
        newOrderSingle.body.timeInForce = timeInForce;
        if (timeInForce == TimeInForce.GTD) {
            newOrderSingle.body.expireTime = acceptanceContext.precisionClock().nanos() + 3600000000000L;
        }
        newOrderSingle.body.messageId = 1;
        newOrderSingle.body.orderQty = entry.size;
        newOrderSingle.body.clOrdId = clOrdId;
        newOrderSingle.body.currency = entry.currency();
        newOrderSingle.body.ordType = orderType;
        newOrderSingle.body.timeInForce = timeInForce;
        newOrderSingle.body.price = price;
        newOrderSingle.body.securityType = SecurityType.FXSPOT;
        newOrderSingle.body.senderCompId = GB_LG_ACC;
        newOrderSingle.body.settlCurrency = entry.currency();
        newOrderSingle.body.side = side;
        newOrderSingle.body.symbol = entry.instrumentKey.symbol();
        return newOrderSingle;
    }

    private void sendAsIcebregOrder(final NewOrderSingle nos) {

        final quickfix.fix42.NewOrderSingle icebregNewOrderSingle = new quickfix.fix42.NewOrderSingle();
        icebregNewOrderSingle.getHeader().setString(MsgType.FIELD, MsgType.ORDER_SINGLE);
        icebregNewOrderSingle.setString(Symbol.FIELD, SymbolNormaliser.toSymbol7(nos.body.symbol));
        icebregNewOrderSingle.setString(quickfix.field.SecurityType.FIELD, quickfix.field.SecurityType.FOREIGN_EXCHANGE_CONTRACT);
        icebregNewOrderSingle.setString(ClOrdID.FIELD, nos.body.clOrdId);
        icebregNewOrderSingle.setChar(quickfix.field.Side.FIELD, nos.body.side == Side.BUY ? quickfix.field.Side.BUY : quickfix.field.Side.SELL);
        icebregNewOrderSingle.setDouble(OrderQty.FIELD, nos.body.orderQty);
        icebregNewOrderSingle.setChar(OrdType.FIELD, OrdType.LIMIT);
        icebregNewOrderSingle.setChar(quickfix.field.TimeInForce.FIELD, quickfix.field.TimeInForce.DAY);
        icebregNewOrderSingle.setDouble(Price.FIELD, nos.body.price);
        icebregNewOrderSingle.setString(Currency.FIELD, nos.body.currency);
        final Date transactTime = new Date();
        transactTime.setTime(TimeUnit.NANOSECONDS.toMillis(nos.body.transactTime));
        icebregNewOrderSingle.setUtcTimeStamp(TransactTime.FIELD, transactTime, true);
        icebregNewOrderSingle.setChar(HandlInst.FIELD, '1');
        icebregNewOrderSingle.setDouble(MaxShow.FIELD, 0);

        System.out.println("Sending Icebreg Order=" + nos.body.clOrdId + " symbol(55)=" + nos.body.symbol + " ======" + icebregNewOrderSingle);
        acceptanceContext.fixMessageSender().accept(icebregNewOrderSingle);
    }

    private PriceEntry awaitAnyPrice() {
        return awaitAnyPrice(InstrumentKey.of("EUR/USD", SecurityType.FXSPOT, Tenor.SP).instrumentId());
    }

    private PriceEntry awaitAnyPrice(final long instrumentId) {
        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(GB_LG_LMAX))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.LMAX))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(instrumentId))
                .entries().anyMatches(mdUpdateAction().eq(UpdateAction.NEW))
                .hops().countAtLeast(2);

        return new PriceListener(acceptanceContext.pricingMessageQueue()).awaitPrice(matcher);
    }

    private PriceEntry awaitSnapshotPrice(final long instrumentId, final Side side) {
        final SnapshotFullRefreshMatcher matcher = SnapshotFullRefreshMatcher.build()
                .body().matches(SnapshotFullRefreshMatcher.senderCompId().eq(GB_LG_LMAX))
                .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.LMAX))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentId))
                .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentId))
                .hops().countAtLeast(2);

        return new PriceListener(acceptanceContext.pricingMessageQueue()).awaitPrice(matcher, side == Side.BUY ? EntryType.OFFER : EntryType.BID);
    }

    private PriceEntry awaitIncrementPrice(final long instrumentId, final Side side) {
        final IncrementalRefreshMatcher matcher = IncrementalRefreshMatcher.build()
                .body().matches(IncrementalRefreshMatcher.senderCompId().eq(GB_LG_LMAX))
                .body().matches(IncrementalRefreshMatcher.marketId().eq(Venue.LMAX))
                .body().matches(IncrementalRefreshMatcher.instrumentId().eq(instrumentId))
                .entries().oneMatches(mdUpdateAction().eq(UpdateAction.NEW))
                .hops().countAtLeast(2);

        return new PriceListener(acceptanceContext.pricingMessageQueue()).awaitPrice(matcher, side == Side.BUY ? EntryType.OFFER : EntryType.BID);
    }

    private Queue<TradingMessage> captureOrMatchExecutionReports(final int maxNumOfERs, final int maxSecsToWait, final ExecutionReportMatcher matcher) throws InterruptedException {
        System.out.println("==============================================================");
        System.out.println("Start Execution Report capture: " + maxNumOfERs + "," + maxSecsToWait);
        System.out.println("==============================================================");
        int receivedCount = 0;
        int loopCount = 0;

        final Queue<TradingMessage> tradingResponseMessages = new ConcurrentLinkedQueue<>();
        while (true) {
            boolean matched = false;
            while (true) {
                TradingMessage tradingResponseMessage = acceptanceContext.tradingResponseMessageQueue().poll();
                if (tradingResponseMessage == null) break;
                receivedCount++;
                orderRepository.update((ExecutionReport)tradingResponseMessage);
                tradingResponseMessages.add(tradingResponseMessage);
                if (matcher != null) {
                    matched = matcher.test(tradingResponseMessage);
                    if (matched) break;
                }
            }
            if (matched || receivedCount >= maxNumOfERs || loopCount >= maxSecsToWait) break;
            loopCount++;
            TimeUnit.SECONDS.sleep(1);
        }
        System.out.println("==============================================================");
        System.out.println("Execution Reports received: " + receivedCount);
        System.out.println("==============================================================");
        return tradingResponseMessages;
    }

    private Queue<TradingMessage> captureExecutionReports(final int maxNumOfERs, final int maxSecsToWait) throws InterruptedException {
        return captureOrMatchExecutionReports(maxNumOfERs, maxSecsToWait, null);
    }

    private double inMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? + PRICE_OFFSET : -PRICE_OFFSET);
    }

    private double offMarketPrice(final double price, final Side side) {
        return price + ((side == Side.BUY) ? - 10*PRICE_OFFSET : + 500*PRICE_OFFSET);
    }

    private PriceEntry onDisconnect(final int millisSecondsToWait) {
        System.out.println("==============================================================");
        System.out.println("Waiting for onDisconnect");
        System.out.println("==============================================================");
        while(true) {
            PricingMessage pricingMessage = acceptanceContext.pricingMessageQueue().poll();
            if (pricingMessage != null) {
                final PriceEntry priceEntry = new PriceEntry();
                pricingMessage.accept(new PricingMessageVisitor.Exception() {
                        @Override
                        public void onSnapshotFullRefresh(final SnapshotFullRefresh snapshotFullRefresh) {
                            priceEntry.msgType = "W";
                            priceEntry.flags.addAll(snapshotFullRefresh.body.mdFlags);
                            priceEntry.instrumentKey = InstrumentKey.of(snapshotFullRefresh.body.instrumentId);
                        }

                        @Override
                        public void onIncrementalRefresh(final IncrementalRefresh incrementalRefresh) {
                            priceEntry.msgType = "X";
                            priceEntry.flags.addAll(incrementalRefresh.body.mdFlags);
                            priceEntry.instrumentKey = InstrumentKey.of(incrementalRefresh.body.instrumentId);
                        }
                });
                if (!priceEntry.flags.isEmpty()) {
                    System.out.println("==============================================================");
                    System.out.println("onDisconnect..." + priceEntry);
                    System.out.println("==============================================================");
                    return priceEntry;
                }
            }
            //??? TimeUnit.MILLISECONDS.sleep(millisSecondsToWait);
        }
    }

    private void orderMassCancelRequest(final char massCancelRequestType, final String symbol) throws InterruptedException {

        // cancel all orders by symbol 'q' - receive 'r' - OrderMassCancelReport
        final OrderMassCancelRequest orderMassCancelRequest = new OrderMassCancelRequest();
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get() + "-MC";

        orderMassCancelRequest.setChar(MassCancelRequestType.FIELD, massCancelRequestType);
        orderMassCancelRequest.setString(ClOrdID.FIELD, clOrdId);
        if (symbol != null) {
            orderMassCancelRequest.setString(Symbol.FIELD, symbol);
        }
        final Date transactTime = new Date();
        transactTime.setTime(System.currentTimeMillis());
        orderMassCancelRequest.setUtcTimeStamp(TransactTime.FIELD, transactTime, true);
        captureExecutionReports(30, 2);

        System.out.println("==============================================================");
        System.out.println("Dumping OrderRepository.");
        orderRepository.dumpAllOrderRequest();
        orderRepository.dumpExecutionsReceived();
        orderRepository.dumpLastExecutions();
        orderRepository.dumpOrderStatus();
        System.out.println("==============================================================");

        System.out.println("Sending OrderMassCancelRequest type(530)=" + String.valueOf(massCancelRequestType) + " symbol(55)=" + symbol);
        acceptanceContext.fixMessageSender().accept(orderMassCancelRequest);
        System.out.println("==============================================================");
        System.out.println("Sent OrderMassCancelRequest: " + orderMassCancelRequest);
        System.out.println("==============================================================");
        TimeUnit.SECONDS.toSeconds(10);
    }

    private char timeInForce(final TimeInForce timeInForce) {
        Objects.requireNonNull(timeInForce, "timeInForce is required");
        switch (timeInForce) {
            case DAY: return quickfix.field.TimeInForce.DAY;
            case IOC: return quickfix.field.TimeInForce.IMMEDIATE_OR_CANCEL;
            case FOK: return quickfix.field.TimeInForce.FILL_OR_KILL;
            default: throw new IllegalArgumentException("Unsupported timeInForce: " + timeInForce);
        }
    }

    public TradingMessage sendAndWaitForExecution(final String clOrdId, final NewOrderSingle newOrderSingle, final ExecType execType, final OrderStatus orderStatus) throws Exception {
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        Queue<TradingMessage> responseMessages = captureExecutionReports(10, 5);

        final TradingMessage message = Asserter.of(responseMessages)
                .matching(ExecutionReportMatcher.build()
                        .body().matches(ExecutionReportMatcher.senderCompId().eq("GB:lg-lmax"))
                        .body().matches(ExecutionReportMatcher.marketId().eq(Venue.LMAX.name()))
                        .body().matches(ExecutionReportMatcher.clOrdId().eq(clOrdId))
                        .body().matches(ExecutionReportMatcher.execType().eq(execType))
                        .body().matches(ExecutionReportMatcher.ordStatus().eq(orderStatus))
                        .strategyParameters().countEquals(0)
                        .regulatoryTradeIds().countEquals(0)
                        .hops().hasAny())
                .awaitMatchAndGetLast(1, TimeUnit.SECONDS);
        System.out.println("==============================================================");
        return message;
    }

    public Queue<TradingMessage> sendAndCaptureExecution(final NewOrderSingle newOrderSingle, final int maxNumOfERs, final int maxSecsToWait) throws Exception {
        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);
        return captureExecutionReports(maxNumOfERs, maxSecsToWait);
    }

    public NewOrderSingle newOrderSingle_captureExecution(final boolean snapshotPrice, final String symbol, final Side side, final OrderType orderType, final TimeInForce timeInForce, final ExecType execType, final OrderStatus orderStatus) throws Exception {
        final String clOrdId = "" + acceptanceContext.tradingMessageIdGenerator().get();
        final InstrumentKey instrumentKey = InstrumentKey.of(symbol, SecurityType.FXSPOT, Tenor.SP);
        final PriceEntry priceEntry = snapshotPrice ? awaitSnapshotPrice(instrumentKey.instrumentId(), side) : awaitIncrementPrice(instrumentKey.instrumentId(), side);
        final Side nosSide = priceEntry.side == Side.SELL ? Side.BUY : Side.SELL;
        final double price = inMarketPrice(priceEntry.price, nosSide);
        final NewOrderSingle newOrderSingle = newOrderSingle(orderType, timeInForce, price, nosSide, clOrdId, priceEntry);

        System.out.println(newOrderSingle.toString());
        System.out.println("==============================================================");
        orderRepository.newOrder(newOrderSingle);
        acceptanceContext.tradingRequestMessageQueue().add(newOrderSingle);

        final ExecutionReportMatcher matcher = buildExecutionReportMatcher(newOrderSingle, clOrdId, execType, orderStatus);
        captureOrMatchExecutionReports(10, 5, matcher);

        System.out.println("==============================================================");
        captureExecutionReports(10, 1);
        orderRepository.dumpOrdersAndExecutions();
        return newOrderSingle;
    }

    private static class OrderRepository {
        private final Map<String, ExecutionReport> executionReports = new HashMap<>();
        private final Map<String, NewOrderSingle> newOrderSingles = new HashMap<>();
        private final List<String> executionReportReceived = new LinkedList<>();

        public boolean receivedUpdate = false;

        public void newOrder(final NewOrderSingle newOrderSingle) {
            if (newOrderSingle != null) {
                newOrderSingles.put(newOrderSingle.body.clOrdId, newOrderSingle);
            }
        }

        public void update(final ExecutionReport executionReport) {
            if (executionReport != null) {
                receivedUpdate = true;
                executionReports.put(executionReport.body.orderId, executionReport);
                final String receivedER = format(executionReport);
                executionReportReceived.add(receivedER);
                System.out.println("Added ER: " + receivedER + " to Repo.");
            }
        }
        public void dumpExecutionsReceived() {
            System.out.println("---" +executionReportReceived.size()+" ER Received---------------------------------------------");
            executionReportReceived.forEach(e -> System.out.println(e));
        }

        public void dumpAllOrderRequest() {
            System.out.println("---" +newOrderSingles.size()+" NewOrderSingle-------------------------------------------");
            newOrderSingles.values().forEach(o -> System.out.println(o));
        }

        public void dumpLastExecutions() {
            System.out.println("---" +executionReports.size()+" Last Executions-----------------------------------------");
            executionReports.values().forEach(e -> System.out.println(e));
        }

        public void dumpOrderStatus() {
            System.out.println("---Order Status-----------------------------------------------");
            executionReports.values().forEach(e -> {
                System.out.println((e.body.leavesQty != 0 ? "Open" : "Filled") + format(e));
            });
        }

        public void dumpOrdersAndExecutions() {
            System.out.println("Dumping OrderRepository.");
            dumpAllOrderRequest();
            dumpLastExecutions();
            dumpExecutionsReceived();
            dumpOrderStatus();
            System.out.println("==============================================================");
        }

        private String format(final ExecutionReport e) {
            return String.format(" Order: orderId=%s|symbol=%s|execType=%s|ordStatus=%s|orderQty=%2f|orderType=%s|price=%2f|currency=%s|leavesQty=%2f|cumQty=%2f|avgPx=%2f|lastPx=%2f|lastShares=%2f|clOrdId=%s|side=%s|rejectText=%s",
                    e.body.orderId,e.body.symbol,e.body.execType,e.body.ordStatus,e.body.orderQty,e.body.ordType,e.body.price,e.body.currency,
                    e.body.leavesQty,e.body.cumQty,e.body.avgPx,e.body.lastPx,e.body.lastQty,e.body.clOrdId,e.body.side,e.body.rejectText);
        }
    }
}