#!/bin/bash
# -*- sh -*-
source ~/axle/environment/shell/axle.rc &> /dev/null

: << =cut

=head1 NAME

datafabric6 - Plugin to monitor the Datafabric

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=datafabric
 #%# capabilities=autoconf

=cut

HOME_DATACENTRE=${datafabric.node}
HOME_DATACENTRE_SHORT=`echo $HOME_DATACENTRE | awk -F. '{ print $(NF-1); }'`

if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Datafabric 6 -' $HOME_DATACENTRE '- Operation Times for Trading Region (ms)'
    echo 'graph_category datafabric'
    echo 'graph_scale no'
    echo 'df6_1.label Agg Book'
    echo 'df6_1.draw LINE2'
    echo 'df6_2.label Algo Status'
    echo 'df6_2.draw LINE2'
    echo 'df6_3.label Deals'
    echo 'df6_3.draw LINE2'
    echo 'df6_4.label Execution Order'
    echo 'df6_4.draw LINE2'
    echo 'df6_5.label Position'
    echo 'df6_5.draw LINE2'
    echo 'df6_6.label Position Config'
    echo 'df6_6.draw LINE2'
    echo 'df6_7.label Trading Order'
    echo 'df6_7.draw LINE2'
    exit 0
fi

function emptyRecord() {
  echo "df6_1.value U"
  echo "df6_2.value U"
  echo "df6_3.value U"
  echo "df6_4.value U"
  echo "df6_5.value U"
  echo "df6_6.value U"
  echo "df6_7.value U"
}

GEMFIRE_HOME=~/gemfire
LOGS=~/axle/datafabric/logs
if [ -f /etc/redhat-release ] ; then
    DATEPATH=date
else
    DATEPATH=/opt/sfw/bin/date
fi

# Munin plugins are executed every 5 minutes (production setting as of 2015-06-02)
# In case this changes, be sure to adjust the extract reuse and the stat sweep windows below (in all fabric plugins)

LATEST_DAT=`ls -ltr $LOGS/ | grep .dat | grep "$HOME_DATACENTRE.statistics-" | tr -s ' ' | tail -1 | awk -F' ' '{ print $(NF); }'`
LATEST_DAT_FILE=$LOGS/$LATEST_DAT
# Reuse stat extract if it was created within the last 1.5 minutes - this number is based on below:
#  - the plugin is executed every 5 minutes (dictated by the master)
#  - it takes around 3 minutes to produce the file (in the lab)
#  - deduct a further half minute to not to overlap with the next schedule
STATS_FILE="`find -L $LOGS -cmin -1.5 -type f -name "${HOME_DATACENTRE}.statreport-*.txt" | sort | tail -1`"

if [ "$LATEST_DAT_FILE" == "" ] && [ "$STATS_FILE" == "" ]; then
  emptyRecord
  exit 0
fi

# Refresh the cache - this is a very resource intensive operation
if [ "$STATS_FILE" == "" ]; then
  TIME_STAMP=`$DATEPATH -u '+%Y-%m-%d_%H-%M-00'`
  STATS_FILE=$LOGS/$HOME_DATACENTRE.statreport-$TIME_STAMP.txt
  # use a 5 minute period up until the start of the present minute
  TIME_FROM=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC' --date '-5 min'`
  TIME_UNTIL=`$DATEPATH -u '+%Y/%m/%d %H:%M:00.000 UTC'`
  DF_STAT_EXTRACT_CMD="${GEMFIRE_HOME}/bin/gemfire stats -starttime=\"${TIME_FROM}\" -endtime=\"${TIME_UNTIL}\" -archive=\"${LATEST_DAT_FILE}\" -persec"

  $DF_STAT_EXTRACT_CMD > "$STATS_FILE"
fi

# If there are no data, bail out honouring semantics
if [ ! -s "$STATS_FILE" ]; then
  emptyRecord
  exit 0
fi

egrep "(Partitioned Region|createsCompleted|putsCompleted|destroysCompleted|getsCompleted|containsKeyCompleted|putAllsCompleted|containsValueForKeyCompleted|createTime|putTime|containsKeyTime|putAllsTime|containsValueForKeyTime)" $STATS_FILE | awk -F' ' '
BEGIN {
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:createsCompleted:average"] = "df6_1_1";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putsCompleted:average"] = "df6_1_2";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:destroysCompleted:average"] = "df6_1_3";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:getsCompleted:average"] = "df6_1_4";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsKeyCompleted:average"] = "df6_1_5";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putAllsCompleted:average"] = "df6_1_6";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsValueForKeyCompleted:average"] = "df6_1_7";

  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:createTime:average"] = "df6_1_1t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putTime:average"] = "df6_1_2t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:destroyTime:average"] = "df6_1_3t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:getTime:average"] = "df6_1_4t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsKeyTime:average"] = "df6_1_5t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:putAllsTime:average"] = "df6_1_6t";
  lookingfor["Partitioned Region /axle_trading_AggBook Statistics:containsValueForKeyTime:average"] = "df6_1_7t";

  lookingfor["Partitioned Region /axle_trading_Deals Statistics:createsCompleted:average"] = "df6_3_1";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putsCompleted:average"] = "df6_3_2";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:destroysCompleted:average"] = "df6_3_3";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:getsCompleted:average"] = "df6_3_4";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsKeyCompleted:average"] = "df6_3_5";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putAllsCompleted:average"] = "df6_3_6";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsValueForKeyCompleted:average"] = "df6_3_7";

  lookingfor["Partitioned Region /axle_trading_Deals Statistics:createTime:average"] = "df6_3_1t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putTime:average"] = "df6_3_2t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:destroyTime:average"] = "df6_3_3t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:getTime:average"] = "df6_3_4t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsKeyTime:average"] = "df6_3_5t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:putAllsTime:average"] = "df6_3_6t";
  lookingfor["Partitioned Region /axle_trading_Deals Statistics:containsValueForKeyTime:average"] = "df6_3_7t";

  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:createsCompleted:average"] = "df6_4_1";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putsCompleted:average"] = "df6_4_2";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:destroysCompleted:average"] = "df6_4_3";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:getsCompleted:average"] = "df6_4_4";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsKeyCompleted:average"] = "df6_4_5";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putAllsCompleted:average"] = "df6_4_6";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsValueForKeyCompleted:average"] = "df6_4_7";

  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:createTime:average"] = "df6_4_1t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putTime:average"] = "df6_4_2t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:destroyTime:average"] = "df6_4_3t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:getTime:average"] = "df6_4_4t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsKeyTime:average"] = "df6_4_5t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:putAllsTime:average"] = "df6_4_6t";
  lookingfor["Partitioned Region /axle_trading_ExecutionOrder Statistics:containsValueForKeyTime:average"] = "df6_4_7t";

  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:createsCompleted:average"] = "df6_7_1";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putsCompleted:average"] = "df6_7_2";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:destroysCompleted:average"] = "df6_7_3";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:getsCompleted:average"] = "df6_7_4";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsKeyCompleted:average"] = "df6_7_5";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putAllsCompleted:average"] = "df6_7_6";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsValueForKeyCompleted:average"] = "df6_7_7";

  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:createTime:average"] = "df6_7_1t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putTime:average"] = "df6_7_2t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:destroyTime:average"] = "df6_7_3t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:getTime:average"] = "df6_7_4t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsKeyTime:average"] = "df6_7_5t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:putAllsTime:average"] = "df6_7_6t";
  lookingfor["Partitioned Region /axle_trading_TradingOrder Statistics:containsValueForKeyTime:average"] = "df6_7_7t";
}
/^[a-zA-Z]/ {
  section  = substr($0,1,index($0,",")-1);
}
/^  / {
  statistic = $1;
  for (i=2; i<=NF; i++) {
    fieldandvalue = $i;
    equals = index(fieldandvalue,"=");
    if (equals > 0) {
      fieldname = substr(fieldandvalue,1,equals-1);
      value = substr(fieldandvalue,equals+1);
      outputname = lookingfor[section ":" statistic ":" fieldname];
      if (outputname != "") {
        values[outputname] = value;
      }
    }
  }
}
END {
  df6_1_count = values["df6_1_1"] + values["df6_1_2"] + values["df6_1_3"] + values["df6_1_4"] + values["df6_1_5"] + values["df6_1_6"] + values["df6_1_7"];
  df6_1_time = values["df6_1_1t"] + values["df6_1_2t"] + values["df6_1_3t"] + values["df6_1_4t"] + values["df6_1_5t"] + values["df6_1_6t"] + values["df6_1_7t"];
  if (df6_1_count > 0) { df6_1 = (df6_1_time / 1000000) / df6_1_count; } else { df6_1 = 0; }
  print "df6_1.value " df6_1;
  
  df6_2_count = values["df6_2_1"] + values["df6_2_2"] + values["df6_2_3"] + values["df6_2_4"] + values["df6_2_5"] + values["df6_2_6"] + values["df6_2_7"];
  df6_2_time = values["df6_2_1t"] + values["df6_2_2t"] + values["df6_2_3t"] + values["df6_2_4t"] + values["df6_2_5t"] + values["df6_2_6t"] + values["df6_2_7t"];
  if (df6_2_count > 0) { df6_2 = (df6_2_time / 1000000) / df6_2_count; } else { df6_2 = 0; }
  print "df6_2.value " df6_2;
  
  df6_3_count = values["df6_3_1"] + values["df6_3_2"] + values["df6_3_3"] + values["df6_3_4"] + values["df6_3_5"] + values["df6_3_6"] + values["df6_3_7"];
  df6_3_time = values["df6_3_1t"] + values["df6_3_2t"] + values["df6_3_3t"] + values["df6_3_4t"] + values["df6_3_5t"] + values["df6_3_6t"] + values["df6_3_7t"];
  if (df6_3_count > 0) { df6_3 = (df6_3_time / 1000000) / df6_3_count; } else { df6_3 = 0; }
  print "df6_3.value " df6_3;
  
  df6_4_count = values["df6_4_1"] + values["df6_4_2"] + values["df6_4_3"] + values["df6_4_4"] + values["df6_4_5"] + values["df6_4_6"] + values["df6_4_7"];
  df6_4_time = values["df6_4_1t"] + values["df6_4_2t"] + values["df6_4_3t"] + values["df6_4_4t"] + values["df6_4_5t"] + values["df6_4_6t"] + values["df6_4_7t"];
  if (df6_4_count > 0) { df6_4 = (df6_4_time / 1000000) / df6_4_count; } else { df6_4 = 0; }
  print "df6_4.value " df6_4;
  
  df6_5_count = values["df6_5_1"] + values["df6_5_2"] + values["df6_5_3"] + values["df6_5_4"] + values["df6_5_5"] + values["df6_5_6"] + values["df6_5_7"];
  df6_5_time = values["df6_5_1t"] + values["df6_5_2t"] + values["df6_5_3t"] + values["df6_5_4t"] + values["df6_5_5t"] + values["df6_5_6t"] + values["df6_5_7t"];
  if (df6_5_count > 0) { df6_5 = (df6_5_time / 1000000) / df6_5_count; } else { df6_5 = 0; }
  print "df6_5.value " df6_5;
  
  df6_6_count = values["df6_6_1"] + values["df6_6_2"] + values["df6_6_3"] + values["df6_6_4"] + values["df6_6_5"] + values["df6_6_6"] + values["df6_6_7"];
  df6_6_time = values["df6_6_1t"] + values["df6_6_2t"] + values["df6_6_3t"] + values["df6_6_4t"] + values["df6_6_5t"] + values["df6_6_6t"] + values["df6_6_7t"];
  if (df6_6_count > 0) { df6_6 = (df6_6_time / 1000000) / df6_6_count; } else { df6_6 = 0; }
  print "df6_6.value " df6_6;
  
  df6_7_count = values["df6_7_1"] + values["df6_7_2"] + values["df6_7_3"] + values["df6_7_4"] + values["df6_7_5"] + values["df6_7_6"] + values["df6_7_7"];
  df6_7_time = values["df6_7_1t"] + values["df6_7_2t"] + values["df6_7_3t"] + values["df6_7_4t"] + values["df6_7_5t"] + values["df6_7_6t"] + values["df6_7_7t"];
  if (df6_7_count > 0) { df6_7 = (df6_7_time / 1000000) / df6_7_count; } else { df6_7 = 0; }
  print "df6_7.value " df6_7;
  
}
'
