package com.anz.markets.disco.modules;

import com.anz.markets.efx.ngaro.collections.EnumObjMap;
import com.anz.markets.efx.ngaro.collections.EnumObjTable;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.function.Consumer;

/**
 * Detects if a venues market prices are jammed.
 * <p>
 * Tick based:
 * 1.	If a market is inverted (with itself)
 * 2.	Count the number of bid and ask (independently) updates on the rest of the markets in that currency (markets which are inputs for disco)
 * 3.	Count will rest to 0, if market un-inverts or if the bid or ask changes (independently)
 * 4.	Once a threshold exceeds, then remove the bid or ask that has exceeded the limit
 * <p>
 * Time based:
 * 1.	If a market is inverted (with itself)
 * 2.	Time the period that the price has not changed on the bid and ask (independently)
 * 3.	Time will rest to 0, if market un-inverts or if the bid or ask changes (independently)
 * 4.	Once a threshold is reached, then remove the bid or ask that has exceeded the limit
 */
public class JamDetector {

    private final Logger logger = LoggerFactory.getLogger(JamDetector.class);

    private class JamConfig {
        int tickCount;
        long timePeriodNanos;

        public JamConfig() {
            reset();
        }

        public void reset() {
            tickCount = Integer.MAX_VALUE;
            timePeriodNanos = Long.MAX_VALUE;
        }

        public boolean hasTickCountDetector() {
            return tickCount != Integer.MAX_VALUE;
        }

        public boolean hasTimeDetector() {
            return timePeriodNanos != Long.MAX_VALUE;
        }

    }

    public enum JamStatus {
        CLEAR, MONITORING, JAMMED;
    }

    public class JamSideState {
        final JamState jamState;
        final OrderSide side;
        final PriorityQueue<JamSideState> timeoutMonitor;
        final EnumObjMap<Instrument, List<JamSideState>> tickCountMonitor;
        double price;
        long lastChangedTime;
        long queuedTimeoutTime;
        int otherGoodCount;
        JamStatus statusTime = JamStatus.CLEAR;
        JamStatus statusTick = JamStatus.CLEAR;

        public JamSideState(final JamState jamState, final OrderSide side,
                            final PriorityQueue<JamSideState> timeoutMonitor,
                            final EnumObjMap<Instrument, List<JamSideState>> tickCountMonitor) {
            this.jamState = jamState;
            this.side = side;
            this.timeoutMonitor = timeoutMonitor;
            this.tickCountMonitor = tickCountMonitor;
        }

        public boolean isJammed() {
            return statusTick == JamDetector.JamStatus.JAMMED || statusTime == JamDetector.JamStatus.JAMMED;
        }

        public void reset(final long t) {
            final boolean wasJammed = isJammed();

            lastChangedTime = t;

            if (statusTick != JamStatus.CLEAR) {
                if (statusTick == JamStatus.MONITORING && jamState.config.hasTickCountDetector()) {
                    tickCountMonitor.get(jamState.instrument).remove(this);
                }
                statusTick = JamStatus.CLEAR;
                otherGoodCount = 0;
            }

            if (statusTime != JamStatus.CLEAR) {
                if (statusTime == JamStatus.MONITORING) {
                    timeoutMonitor.remove(this);
                    queuedTimeoutTime = 0;
                }
                statusTime = JamStatus.CLEAR;
            }

            if (wasJammed && !isJammed()) {
                logger.info("JAMMED {} is now CLEARED: {} {}.", side, jamState.market, jamState.instrument);
            }
        }

        public void monitor(final long t) {
            if (statusTick == JamStatus.CLEAR) {
                statusTick = JamStatus.MONITORING;
                if (jamState.config.hasTickCountDetector()) {
                    tickCountMonitor.computeIfAbsent(jamState.instrument, x -> new ArrayList<>()).add(this);
                }
            }
            if (statusTime == JamStatus.CLEAR) {
                if (jamState.config.hasTimeDetector() && queuedTimeoutTime == 0) {
                    queuedTimeoutTime = t + jamState.config.timePeriodNanos;
                    statusTime = JamStatus.MONITORING;
                    timeoutMonitor.add(this);
                }
            }
        }

    }

    public class JamState {
        final Instrument instrument;
        final Market market;

        final JamConfig config = new JamConfig();

        final JamSideState bidState = new JamSideState(this, OrderSide.BID, bidTimoutMonitor, bidTickCountMonitoring);
        final JamSideState askState = new JamSideState(this, OrderSide.OFFER, askTimoutMonitor, askTickCountMonitoring);

        public JamState(final Market market, final Instrument instrument) {
            this.market = market;
            this.instrument = instrument;
        }

        public boolean bidJammed() {
            return bidState.isJammed();
        }

        public boolean askJammed() {
            return askState.isJammed();
        }

    }

    private final PriorityQueue<JamSideState> bidTimoutMonitor = new PriorityQueue<>(Comparator.comparingLong(x -> x.queuedTimeoutTime));
    private final PriorityQueue<JamSideState> askTimoutMonitor = new PriorityQueue<>(Comparator.comparingLong(x -> x.queuedTimeoutTime));
    private final EnumObjMap<Instrument, List<JamSideState>> bidTickCountMonitoring = new EnumObjMap<>(Instrument.class);
    private final EnumObjMap<Instrument, List<JamSideState>> askTickCountMonitoring = new EnumObjMap<>(Instrument.class);
    private final EnumObjTable<Market, Instrument, JamState> jamStates = new EnumObjTable<>(Market.class, Instrument.class);
    private final Consumer<JamSideState> newJamConsumer;

    public JamDetector(Consumer<JamSideState> newJamConsumer) {
        this.newJamConsumer = newJamConsumer;
    }

    public void resetConfig() {
        jamStates.forEach((market, instrument, jamState) -> jamState.config.reset());
    }

    public void addConfig(final Market market, final Instrument instrument, final int tickCount, final long timePeriodNanos) {
        final JamState jamState = jamStates.computeIfAbsent(market, instrument, () -> new JamState(market, instrument));
        if (tickCount <= 0) {
            jamState.config.tickCount = Integer.MAX_VALUE;
        } else {
            jamState.config.tickCount = tickCount;
        }
        if (timePeriodNanos <= 0) {
            jamState.config.timePeriodNanos = Long.MAX_VALUE;
        } else {
            jamState.config.timePeriodNanos = timePeriodNanos;
        }
    }

    public JamState getState(final Market market, final Instrument instrument) {
        return jamStates.computeIfAbsent(market, instrument, () -> new JamState(market, instrument));
    }

    public JamState addSnapshot(final long t, final Market market, final Instrument instrument, double bid, double ask) {
        final boolean isInverted = bid > ask;
        final JamState jamState = jamStates.computeIfAbsent(market, instrument, () -> new JamState(market, instrument));

        final boolean bidChanged = bid != jamState.bidState.price;
        final boolean askChanged = ask != jamState.askState.price;

        if (bidChanged) {
            jamState.bidState.reset(t);
        }
        if (askChanged) {
            jamState.askState.reset(t);
        }

        reviseTimeMonitors(t, bidTimoutMonitor);
        reviseTimeMonitors(t, askTimoutMonitor);

        if (isInverted) {
            jamState.bidState.monitor(t);
            jamState.askState.monitor(t);
        } else {
            jamState.bidState.reset(t);
            jamState.askState.reset(t);
            if (bidChanged) {
                reviseTickMonitors(instrument, bidTickCountMonitoring);
            }
            if (askChanged) {
                reviseTickMonitors(instrument, askTickCountMonitoring);
            }
        }
        jamState.bidState.price = bid;
        jamState.askState.price = ask;

        return jamState;
    }

    private void reviseTimeMonitors(final long t, final PriorityQueue<JamSideState> timeoutMonitor) {
        while (timeoutMonitor.size() > 0 && timeoutMonitor.peek().queuedTimeoutTime <= t) {
            final JamSideState jamSideState = timeoutMonitor.poll();
            jamSideState.queuedTimeoutTime = 0;
            if (jamSideState.statusTime == JamStatus.MONITORING) {
                if (t - jamSideState.lastChangedTime >= jamSideState.jamState.config.timePeriodNanos) {
                    if (!jamSideState.isJammed()) {
                        jamSideState.statusTime = JamStatus.JAMMED;
                        newJamConsumer.accept(jamSideState);
                        logger.error("Detected JAMMED {} {} based on time criterion: {} {}.", jamSideState.side, jamSideState.price, jamSideState.jamState.market, jamSideState.jamState.instrument);
                    } else {
                        jamSideState.statusTime = JamStatus.JAMMED;
                    }
                } else {
                    jamSideState.queuedTimeoutTime = jamSideState.lastChangedTime + jamSideState.jamState.config.timePeriodNanos;
                    bidTimoutMonitor.add(jamSideState);
                }
            }
        }
    }

    private void reviseTickMonitors(final Instrument instrument, final EnumObjMap<Instrument, List<JamSideState>> tickCountMonitoring) {
        final List<JamSideState> pending = tickCountMonitoring.get(instrument);
        if (pending != null) {
            for (int i = pending.size() - 1; i >= 0; i--) {
                final JamSideState jamSideState = pending.get(i);
                jamSideState.otherGoodCount++;
                if (jamSideState.otherGoodCount >= jamSideState.jamState.config.tickCount) {
                    if (!jamSideState.isJammed()) {
                        jamSideState.statusTick = JamStatus.JAMMED;
                        newJamConsumer.accept(jamSideState);
                        logger.error("Detected JAMMED {} {} based on tick criterion: {} {}.", jamSideState.side, jamSideState.price, jamSideState.jamState.market, jamSideState.jamState.instrument);
                    } else {
                        jamSideState.statusTick = JamStatus.JAMMED;
                    }
                    pending.remove(i);
                }
            }
        }
    }

}
