package com.anz.markets.efx.fox.codec.pojo.codec;

import java.util.Objects;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.api.TimerExpiryHandler;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.fox.codec.pojo.model.TimerExpiry;
import com.anz.markets.efx.ngaro.codec.MessageDecoder;
import com.anz.markets.efx.ngaro.core.Garbage;

@Garbage(Garbage.Type.ANY)
final class PojoTimerExpiryDecoder implements MessageDecoder<SorMessage> {

    private final Supplier<? extends TimerExpiryHandler> handlerSupplier;

    public PojoTimerExpiryDecoder(final Supplier<? extends TimerExpiryHandler> handlerSupplier) {
        this.handlerSupplier = Objects.requireNonNull(handlerSupplier);
    }

    @Override
    public boolean decode(final SorMessage sorMessage) {
        if (sorMessage instanceof TimerExpiry) {
            return decode((TimerExpiry) sorMessage);
        }
        return false;
    }

    public boolean decode(final TimerExpiry message) {
        final TimerExpiryHandler handler = handlerSupplier.get();
        handler.onMessageStart(message.header.source, message.header.sourceSeq);
        handler.onBody(new TimerExpiryHandler.Body() {

            @Override
            public long triggeredTime() {
                return message.body.triggeredTime;
            }

            @Override
            public long timerId() {
                return message.body.timerId;
            }

            @Override
            public TimerGroup timerGroup() {
                return message.body.timerGroup;
            }
        });
        handler.onMessageComplete();
        return true;
    }

    private PojoTimerExpiryDecoder() {
        throw new RuntimeException("No PojoTimerExpiryDecoder for you!");
    }
}
