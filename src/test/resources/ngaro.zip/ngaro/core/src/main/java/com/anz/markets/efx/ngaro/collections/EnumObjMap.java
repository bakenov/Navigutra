package com.anz.markets.efx.ngaro.collections;

import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class EnumObjMap<K extends Enum<K>, V> implements Map<K, V> {

    private final V EMPTY = null;
    private final K[] keyUniverse;
    private final V[] entries;
    private int size;
    private final int capacity;
    private final Class<K> keyType;
    private final Optional<Class<V>> valueType;

    public EnumObjMap(final Class<K> keyType,
                      final Class<V> valueType) {
        this(keyType, valueType, null);
    }

    public EnumObjMap(final Class<K> keyType) {
        this(keyType, null, null);
    }

    public EnumObjMap(final Class<K> keyType,
                      final Supplier<V> supplier) {
        this(keyType, null, supplier);
    }

    public EnumObjMap(final Class<K> keyType,
                      final Class<V> valueType,
                      final Supplier<V> supplier) {
        this.valueType = valueType == null ? Optional.empty() : Optional.of(valueType);
        this.keyType = keyType;
        this.keyUniverse = keyType.getEnumConstants();
        this.capacity = keyUniverse.length;
        this.entries = (V[]) new Object[capacity];
        if (supplier != null) {
            for (final K key : keyUniverse) {
                put(key, supplier.get());
            }
        }
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public Class<K> getKeyType() {
        return keyType;
    }

    public boolean containsKey(K key) {
        return entries[key.ordinal()] != EMPTY;
    }

    @Override
    public boolean containsKey(final Object key) {
        return containsKey((K) key);
    }

    @Override
    public boolean containsValue(final Object value) {
        if (value == null) {
            return false;
        }
        for (int i = 0; i < capacity; i++) {
            if (value.equals(this.entries[i])) {
                return true;
            }
        }
        return false;
    }

    @Override
    public V get(final Object key) {
        return entries[((K) key).ordinal()];
    }

    public boolean compareAndPut(K key, V value, BiPredicate<V, V> predicate) {
        final boolean result = predicate.test(get(key), value);
        put(key, value);
        return result;
    }

    @Override
    public V put(K key,
                 V value) {
        if (!containsKey(key)) {
            size++;
        }
        final V prevValue = entries[key.ordinal()];
        entries[key.ordinal()] = value;
        return prevValue;
    }

    @Override
    public V computeIfAbsent(K key,
                             Function<? super K, ? extends V> mappingFunction) {
        GcFriendlyAssert.notNull(mappingFunction);
        V v;
        if ((v = get(key)) == EMPTY) {
            V newValue;
            if ((newValue = mappingFunction.apply(key)) != EMPTY) {
                put(key, newValue);
                return newValue;
            }
        }
        return v;
    }

    @Override
    public V remove(final Object key) {
        if (containsKey(key)) {
            size--;
            return put((K) key, EMPTY);
        }
        return EMPTY;
    }

    public void clear() {
        for (int i = 0; i < capacity; i++) {
            entries[i] = EMPTY;
        }
        size = 0;
    }

    @SuppressWarnings("CPD-START") // cpd is not very smart - i thinks keys() and forEach() are the same.
    public final void keys(Consumer<K> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (entries[i] != EMPTY) {
                    action.accept(this.keyUniverse[i]);
                }
            }
        }
    }

    public void forEachSubset(K keyUniverseSubset[], BiConsumer<? super K, ? super V> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (K k : keyUniverseSubset) {
                final int idx = k.ordinal();
                if (entries[idx] != EMPTY) {
                    action.accept(this.keyUniverse[idx], entries[idx]);
                }
            }
        }
    }

    /**
     * @see if you are operating over a defined subset of the key universe then consider using forEachSubset for performance.
     */
    @Override
    public void forEach(BiConsumer<? super K, ? super V> action) {
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (entries[i] != EMPTY) {
                    action.accept(this.keyUniverse[i], entries[i]);
                }
            }
        }
    }

    public void forEachIf(Predicate<? super K> keyPredicate,
                          BiConsumer<? super K, ? super V> action) {
        GcFriendlyAssert.notNull(keyPredicate);
        GcFriendlyAssert.notNull(action);
        if (size > 0) {
            for (int i = 0; i < capacity; ++i) {
                if (entries[i] != EMPTY) {
                    if (keyPredicate.test(keyUniverse[i])) {
                        action.accept(keyUniverse[i], entries[i]);
                    }
                }
            }
        }
    }

    @SuppressWarnings("CPD-END")

    public boolean removeIf(final BiPredicate<K, V> filter) {
        GcFriendlyAssert.notNull(filter);
        boolean rv = false;
        for (int i = 0; i < capacity; i++) {
            if (entries[i] != EMPTY) {
                if (filter.test(this.keyUniverse[i], entries[i])) {
                    remove(this.keyUniverse[i]);
                    rv = true;
                }
            }
        }
        return rv;
    }

    @NotGcFriendly
    public String toString() {
        final ToStringHelpers.CollectMapValues toStringCollector = new ToStringHelpers.CollectMapValues();
        forEach(toStringCollector);
        return toStringCollector.toString();
    }

    /**
     * Put all items in the list with given key function.
     *
     * @param values    Values in list
     * @param keyGetter a function to retrieve key from item in the list
     * @return this map
     */
    public EnumObjMap<K, V> putAll(final List<V> values,
                                   final Function<V, K> keyGetter) {

        for (int i = 0; i < values.size(); i++) {
            final V v = values.get(i);
            this.put(keyGetter.apply(v), v);
        }
        return this;
    }

    @Override
    public void putAll(final Map<? extends K, ? extends V> m) {
        throw new IllegalAccessError("NOT SUPPORTED");
    }

    @Override
    public Set<K> keySet() {
        throw new IllegalAccessError("NOT SUPPORTED");
    }

    @NotGcFriendly
    @Override
    public Collection<V> values() {
        final Map<K, V> map = new HashMap<>(entries.length);
        forEach((k, v) -> map.put(k, v));
        return map.values();
    }

    @NotGcFriendly
    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        final Map<K, V> map = new HashMap<>(entries.length);
        forEach((k, v) -> map.put(k, v));
        return map.entrySet();
    }

    public Optional<Class<V>> getValueType() {
        return valueType;
    }
}
