package com.anz.markets.prophet.marketdata.filter;

import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import org.junit.Test;

public class StaleMarketDataFilterBWTest extends AbstractStaleMarketDataFilterForBwJmhTest {

    private static final int REPS = 20_000;
    private static final int THRESHOLD = 500;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();

    @Test
    public void test_AllocationNotExceeded_Test() {
        helper.testAllocationNotExceeded(
                this::testPerformFilter,
                REPS, REPS,
                THRESHOLD
        );
    }
}