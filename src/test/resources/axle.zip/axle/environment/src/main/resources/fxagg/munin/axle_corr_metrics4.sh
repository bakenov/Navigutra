#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

axle_corr_metrics - Plugin to monitor the Axle Correlator Metrics 4 - Events per Second

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Stephen Murphy (stephen.murphy@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=axle
 #%# capabilities=autoconf

=cut

# . $MUNIN_LIBDIR/plugins/plugin.sh

. ~/apama/bin/apama_env > /dev/null

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then
    echo 'graph_title Axle Correlator Metrics 4 - Events per Second'
    echo 'graph_args -l 0'
    echo 'graph_category axle'
    echo 'graph_scale no'
    echo 'main_rate.label events per second (Main)'
    echo 'main_rate.draw LINE2'
    echo 'main_rate.colour FF0000'		# RED
    echo 'pub_rate.label events per second (Publisher)'
    echo 'pub_rate.draw LINE2'
    echo 'vag1_rate.label events per second (VAG1)'
    echo 'vag1_rate.draw LINE2'
    echo 'vag2_rate.label events per second (VAG2)'
    echo 'vag2_rate.draw LINE2'
    exit 0
fi

CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logs/Correlator-FxAgg.pid
PUB_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logspublisher/Correlator-Publisher.pid
PRICING_PUB_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logspricingpub/Correlator-PricingPublisher.pid
VAG1_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logsvag1/Correlator-VAG1.pid
VAG2_CORRELATOR_PIDFILE=~/axle/fxagg/fxagg-core/logsvag2/Correlator-VAG2.pid

CORRELATOR_PORT=15903
PUB_CORRELATOR_PORT=15904
PRICING_PUB_CORRELATOR_PORT=15905
VAG1_CORRELATOR_PORT=15911
VAG2_CORRELATOR_PORT=15912

# function parameters: PIDFILE PORT NAME
function getvalue {
	PIDFILE=$1
	PORT=$2
	NAME=$3
	# If there is no pidfile present OR there is a pidfile but no corresponding process then return undefined
	if [ ! -f ${PIDFILE} ] || [ ! -d /proc/`cat ${PIDFILE}` ]; then
		echo "${NAME}_rate.value U"
	else
		# get new engine stats
		${APAMA_HOME}/bin/engine_watch -r -o -p ${PORT} | sed 's/,/ /g'  > /tmp/engine_watch_${NAME}.new
		read uptime contexts monitors submonitors javaapps listeners sublisteners eventtypes inputqueue received routequeue routed consumers outputqueue created sent processed mostBackedUpContext mostBackedUpQueue slowestRx slowestRxQueue < /tmp/engine_watch_${NAME}.new

		# get the old engine stats
		if [ ! -f /tmp/engine_watch_${NAME}.old ]
		then
			echo "${NAME}_rate.value U"
		else
			read uptime0 contexts0 monitors0 submonitors0 javaapps0 listeners0 sublisteners0 eventtypes0 inputqueue0 received0 routequeue0 routed0 consumers0 outputqueue0 created0 sent0 processed0 mostBackedUpContext0 mostBackedUpQueue0 slowestRx0 slowestRxQueue0 < /tmp/engine_watch_${NAME}.old

			# was correlator restarted - stale data?
			if [ "$uptime" -le "$uptime0" ]
			then
				echo "${NAME}_rate.value U"
			else
				# don't divide by zero
				if [ "$processed" -eq "$processed0" ]
				then
					rate=0
				else
					rate=`echo "($processed - $processed0) * 1000 / ($uptime - $uptime0)" | bc`
				fi

				# output the value
				echo "${NAME}_rate.value $rate"
			fi
		fi

		# save old data
		mv -f /tmp/engine_watch_${NAME}.new /tmp/engine_watch_${NAME}.old
	fi
}

# print the values for all the correlators
getvalue $CORRELATOR_PIDFILE $CORRELATOR_PORT main
getvalue $PUB_CORRELATOR_PIDFILE $PUB_CORRELATOR_PORT pub
getvalue $PRICING_PUB_CORRELATOR_PIDFILE $PRICING_PUB_CORRELATOR_PORT pricing_pub
getvalue $VAG1_CORRELATOR_PIDFILE $VAG1_CORRELATOR_PORT vag1
getvalue $VAG2_CORRELATOR_PIDFILE $VAG2_CORRELATOR_PORT vag2

