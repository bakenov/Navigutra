package com.anz.markets.efx.fox.acceptance.tests;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.fox.codec.api.TimerGroup;
import com.anz.markets.efx.fox.codec.pojo.matcher.TimerExpiryMatcher;
import com.anz.markets.efx.fox.api.domain.VenueRepository;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.trading.codec.pojo.matcher.HeartbeatMatcher;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import static org.assertj.core.api.Assertions.assertThat;

@RunWith(Spockito.class)
public class ReceiveHeartbeat_Then_Venue_Is_Up_Test {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReceiveHeartbeat_Then_Venue_Is_Up_Test.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private VenueRepository venueRepository;
    private PropertyApplier systemProperties = new SystemPropertyApplier();


    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");
        systemProperties.set("venue.timeout.millis", "2000");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        venueRepository = application.getApplicationContext().getBean(VenueRepository.class,"venueRepository");
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_receive_venue_heartbeat_and_make_venue_online() throws Exception {
        final SorEndpoint sorEndpoint = acceptanceContext.sorEndpoint();

        Heartbeat heartbeat = sorEndpoint.createHeartbeat();
        heartbeat.body.senderCompId = "GB:lg-fastc";

        sorEndpoint.tradingRequest().add(heartbeat);

        final HeartbeatMatcher heartbeatMatcher = HeartbeatMatcher.build()
                .header().matches(HeartbeatMatcher.source().gt(0))
                .header().matches(HeartbeatMatcher.sourceSeq().gt(0L))
                .body().matches(HeartbeatMatcher.senderCompId().eq(heartbeat.body.senderCompId))
                .body().matches(HeartbeatMatcher.messageId().gt(0L));

        Asserter.of(acceptanceContext.eventProcessingEndpoint().commandsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(heartbeatMatcher)
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        assertThat(venueRepository.lookup(Venue.FAST).online()).isTrue();

        acceptanceContext.eventProcessingEndpoint().eventsQueue().clear();

        Asserter.of(acceptanceContext.eventProcessingEndpoint().eventsQueue())
                .matching(TimerExpiryMatcher.build()
                        .body().matches(TimerExpiryMatcher.timerGroup().eq(TimerGroup.VENUE_MISSED_HEARTBEAT)))
                .awaitMatchAndGetLast(4, TimeUnit.SECONDS);

        assertThat(venueRepository.lookup(Venue.FAST).online()).isFalse();

    }
}
