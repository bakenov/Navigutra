package com.anz.axle.lg.adapter.d3.acceptance;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

import org.agrona.concurrent.BackoffIdleStrategy;

import com.google.common.collect.Lists;
import de.digitec.d3.pricing.streaming.ErrorMessage;
import de.digitec.d3.pricing.streaming.StreamingException;
import de.digitec.d3.pricing.streaming.StreamingService;
import de.digitec.d3.pricing.streaming.StreamingServiceListener;
import de.digitec.d3.pricing.streaming.UpdateMessage;

import com.anz.lg.messaging.event.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;

public class StubbedStreamingService implements StreamingService {
    private volatile boolean connected;
    private final Queue<SubscriptionRequest> subscriptionRequestQueue;
    private final Queue<UpdateMessage> updateMessageQueue;
    private final Queue<ErrorMessage> errorMessageQueue;
    private final Queue<Throwable> throwableQueue;
    private final List<StreamingServiceListener> listeners = Lists.newCopyOnWriteArrayList();
    private final EventLoopService eventLoop;
    private final Runnable onSubscribeHandler;

    public StubbedStreamingService(final Queue<SubscriptionRequest> subscriptionRequestQueue,
                                   final Queue<UpdateMessage> updateMessageQueue,
                                   final Queue<ErrorMessage> errorMessageQueue,
                                   final Queue<Throwable> throwableQueue,
                                   final Runnable onSubscribeHandler) {
        this.subscriptionRequestQueue = Objects.requireNonNull(subscriptionRequestQueue);
        this.updateMessageQueue = Objects.requireNonNull(updateMessageQueue);
        this.errorMessageQueue = Objects.requireNonNull(errorMessageQueue);
        this.throwableQueue = Objects.requireNonNull(throwableQueue);
        this.onSubscribeHandler = Objects.requireNonNull(onSubscribeHandler);

        final EventLoopStep updateMessagePollingStep = () -> {
            final UpdateMessage updateMessage = updateMessageQueue.poll();
            if (updateMessage != null) {
                listeners.forEach(streamingServiceListener -> streamingServiceListener.processUpdate(updateMessage));
                return true;
            } else {
                return false;
            }
        };
        final EventLoopStep errormMessagePollingStep = () -> {
            final ErrorMessage errorMessage = errorMessageQueue.poll();
            if (errorMessage != null) {
                listeners.forEach(streamingServiceListener -> streamingServiceListener.processError(errorMessage));
                return true;
            } else {
                return false;
            }
        };
        final EventLoopStep throwablePollingStep = () -> {
            final Throwable throwable = throwableQueue.poll();
            if (throwable != null) {
                listeners.forEach(streamingServiceListener -> streamingServiceListener.processServiceException(throwable));
                return true;
            } else {
                return false;
            }
        };

        eventLoop = new EventLoopService(
                "StubbedStreamingService",
                10, TimeUnit.SECONDS, new BackoffIdleStrategy(100,100,0, TimeUnit.MICROSECONDS.toNanos(100)),
                updateMessagePollingStep,
                errormMessagePollingStep,
                throwablePollingStep
        );
    }

    @Override
    public void connect() throws IOException {
        connected = true;
    }

    @Override
    public boolean isConnected() {
        return connected;
    }

    @Override
    public void disconnect() {
        connected = false;
    }

    @Override
    public void stop() {
        eventLoop.stop();
    }

    @Override
    public void addServiceListener(final StreamingServiceListener streamingServiceListener) {
        listeners.add(streamingServiceListener);
    }

    @Override
    public void removeServiceListener(final StreamingServiceListener streamingServiceListener) {
        listeners.remove(streamingServiceListener);
    }

    @Override
    public void subscribe(final String subscriptionId, final String symbol) throws StreamingException {
        subscriptionRequestQueue.add(SubscriptionRequest.forSubscribe(subscriptionId, symbol));
        onSubscribeHandler.run();
    }

    @Override
    public void unsubscribe(final String subscriptionId) throws StreamingException {
        subscriptionRequestQueue.add(SubscriptionRequest.forUnsubscribe(subscriptionId));
    }

    @Override
    public void run() {
        eventLoop.start();
    }
}
