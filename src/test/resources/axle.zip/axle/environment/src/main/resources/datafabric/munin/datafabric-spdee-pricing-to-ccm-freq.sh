#!/bin/bash
# -*- sh -*-

: << =cut

=head1 NAME

datafabric-spdee-pricing-to-ccm-freq - Plugin to monitor the SPDEE Pricing to CCM Frequency (All)

=head1 CONFIGURATION

default

=back

=head1 AUTHOR

Rupert Jones (rupert.jones@anz.com)

=head1 LICENSE

Unknown license

=head1 MAGIC MARKERS

 #%# family=spdee
 #%# capabilities=autoconf

=cut

TAIL=/usr/bin/tail

SLEEP_SECONDS=5


if [ "$1" = 'autoconf' ]; then
    echo yes
    exit 0
fi

if [ "$1" = "config" ]; then

    echo 'graph_title SPDEE Pricing Frequency'
    echo 'graph_category spdee'
    echo 'graph_scale no'
    echo 'freqQuoteBook.label QuoteBook to CCM'
    echo 'freqQuoteBook.draw LINE2'
    echo 'freqAggBook.label AggBook to CCM'
    echo 'freqAggBook.draw LINE2'
    exit 0
fi

DATAFABRIC_PIDFILE=`ls -1 ~/logs/datafabric/*CacheServer.pid 2> /dev/null | head -1`

# If there is no pidfile present OR
# there is a pidfile but no corresponding process
# then return undefined
if [ "${DATAFABRIC_PIDFILE}" = "" ] ; then
        echo "freqAggBook.value U"
        echo "freqQuoteBook.value U"
        exit 0
fi

DATAFABRIC_PID=$(cat ${DATAFABRIC_PIDFILE})
if [ ! -d /proc/${DATAFABRIC_PID} ] ; then
        echo "freqAggBook.value U"
        echo "freqQuoteBook.value U"
        exit 0
fi

LOGFILE=`ls -1 -tr ~/logs/datafabric/*CacheServer.aggregated.performance.log | tail -1`

if [ -f "$LOGFILE" ]; then
# Awk program for processing aggregated.performance.log
egrep 'pricing.*-to-ccm,,' $LOGFILE | tail -100 | awk -F, '
BEGIN {
        freqAggBook=0;
        freqQuoteBook=0;
}

/pricing.agg-book-to-ccm/ {freqAggBook=$19}
/pricing.quote-book-to-ccm/ {freqQuoteBook=$19}

END {
        print "freqAggBook.value " freqAggBook;
        print "freqQuoteBook.value " freqQuoteBook;
}
'
fi

