package com.anz.markets.prophet.pricer.wholesale.spreads;


import com.anz.markets.prophet.WarmingByteWatcherRegressionTestHelper;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.domain.marketdata.impl.FilterDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.pricer.wholesale.DriverInstrumentWholesaleBookManagerTest;
import com.anz.markets.prophet.pricer.wholesale.WholesaleBook;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.io.IOException;

@Ignore("smoking gun here....")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MarketGapSpreadAdjustmentStrategyBWTest {

    public static final FilteredMarketDataSnapshot MARKETDATA_WSP_U_AUDUSD_075 = (new MarketGapDefinitionsTest()).createFilteredMarketDataSnapshot(Market.WSP_U, Instrument.AUDUSD, FilterDecision.PASS, 0.75, 0.001);

    private final MarketGapSpreadAdjustmentStrategy marketGapSpreadAdjustmentStrategy = new MarketGapSpreadAdjustmentStrategy();

    private static final int REPS = 200_000, THRESHOLD = 1000;
    private final WarmingByteWatcherRegressionTestHelper helper = new WarmingByteWatcherRegressionTestHelper();
    private WholesaleBook wholesaleBook = new WholesaleBook(Market.WSP_A, Instrument.AUDUSD);

    public MarketGapSpreadAdjustmentStrategyBWTest() throws IOException {
        marketGapSpreadAdjustmentStrategy.applyConfiguration(new DriverInstrumentWholesaleBookManagerTest().indexedConfigurationData);
    }

    public void scenario_SpreadBasedBookFormation() {
        wholesaleBook.reset();
        wholesaleBook.initInstrument(Instrument.AUDUSD);
        WholesaleBookFactorsImpl wholesaleBookFactors = wholesaleBook.getWholesaleBookFactors();
        wholesaleBookFactors.setBaseSpread(0.1);
        wholesaleBookFactors.setModelSpread(1.1);
        wholesaleBookFactors.addConfigSpread(Level.QTY_1M, 0.4);
        wholesaleBookFactors.addConfigSpread(Level.QTY_2M, 0.5);
        wholesaleBookFactors.addConfigSpread(Level.QTY_4M, 0.6);
        wholesaleBookFactors.addConfigSpread(Level.QTY_10M, 0.7);
        wholesaleBookFactors.addConfigSpread(Level.QTY_15M, 0.8);
        wholesaleBookFactors.addConfigSpread(Level.QTY_30M, 0.9);

        wholesaleBookFactors.setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_1M).setModelSpread(0.4);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_2M).setModelSpread(0.5);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_4M).setModelSpread(0.6);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_10M).setModelSpread(0.7);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_15M).setModelSpread(0.8);
        wholesaleBookFactors.getSpreadFactorsModel().get(Level.QTY_30M).setModelSpread(0.9);

        marketGapSpreadAdjustmentStrategy.applyMarketDataSnapshot(MARKETDATA_WSP_U_AUDUSD_075);
        marketGapSpreadAdjustmentStrategy.execute(wholesaleBook);
    }

    @Test
    public void test_SpreadBasedBookFormation() {
        helper.testAllocationNotExceeded(
                this::scenario_SpreadBasedBookFormation,
                REPS, REPS,
                THRESHOLD
        );
    }

}
