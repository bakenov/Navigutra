package com.anz.axle.lg.adapter.hsp.chronicleitch;

import org.agrona.collections.Int2ObjectHashMap;
import org.agrona.collections.Long2ObjectHashMap;

import com.anz.markets.efx.pricing.codec.api.EntryType;

public class SymbolOrderIdSideLookUp {
    private final Long2ObjectHashMap<Int2ObjectHashMap<EntryType>> cache = new Long2ObjectHashMap<>();

    public void cache(final long instrumentId, final int orderId, final EntryType side) {
        if (instrumentId != 0 && orderId > 0 && side != null) {
            final Int2ObjectHashMap<EntryType> orderIdSide = cache.computeIfAbsent(instrumentId, instId -> new Int2ObjectHashMap<>());
            orderIdSide.put(orderId, side);
        }
    }

    public EntryType remove(final long instrumentId, final int orderId) {
        if (instrumentId != 0 && orderId > 0) {
            final Int2ObjectHashMap<EntryType> orderIdSide = cache.get(instrumentId);
            if (orderIdSide != null) {
                return orderIdSide.remove(orderId);
            }
        }
        return null;
    }

    public EntryType lookUpSide(final long instrumentId, final int orderId) {
        if (instrumentId != 0 && orderId > 0) {
            final Int2ObjectHashMap<EntryType> orderIdSide = cache.get(instrumentId);
            if (orderIdSide != null) {
                return orderIdSide.get(orderId);
            }
        }
        return null;
    }
}
