package com.anz.markets.efx.fox.firewall.metric;

import java.util.function.Function;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.anz.markets.efx.fox.firewall.TestOrderFactory;
import com.anz.markets.efx.fox.firewall.api.RuleMatcher;
import com.anz.markets.efx.fox.firewall.matcher.OrderMatcher;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteValueCache;
import com.anz.markets.efx.trading.codec.api.NewOrderSingleDecoder;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderMatcherTest {
    @Mock
    private Function<String, String> userToDesc;
    @Mock
    private RuleMatcher ruleMatcher;
    private OrderMatcher orderMatcher;
    private TestOrderFactory orderFactory;

    @BeforeEach
    void setUp() {
        orderFactory = new TestOrderFactory();
        orderMatcher = new OrderMatcher(new ByteValueCache<>(AsciiString::toString), userToDesc, ruleMatcher);
    }

    @Test
    void test() {
        //given
        final String region = "GB";
        final String targetStrategy = "MID";
        final String portfolio = "XEFX";
        final String username = "anufriea";
        final String desk = "someDesk";
        final SecurityType securityType = SecurityType.FXSPOT;
        final Tenor tenor = Tenor.SP;
        final String symbol = "AUDUSD";
        final double orderQty = 1000_000;
        final Venue[] venues = new Venue[] {Venue.FXALLMB, Venue.EBSHEDGE};
        final String venuesString = "FXALLMB,EBSHEDGE";

        final NewOrderSingleDecoder order = orderFactory.createOrder(region, targetStrategy, portfolio, username, securityType, tenor, symbol, orderQty, venuesString);
        when(userToDesc.apply(username)).thenReturn(desk);

        //when
        orderMatcher.test(order);

        //then
        verify(ruleMatcher).match(region, desk, targetStrategy, portfolio, username, venuesString, securityType, tenor, symbol);
    }
}