package com.anz.markets.efx.fox.acceptance.api;

import java.io.Closeable;
import java.util.Queue;

public interface CommandExecutionEndpoint extends Closeable {
    Queue<?> commandsQueue();
    Queue<?> eventsQueue();

    @Override
    default void close() {}
}
