package com.anz.markets.efx.ngaro.collections;

@FunctionalInterface
public interface ObjDoublePredicate<T> {

    boolean test(T t, double v);
}
