package com.anz.markets.prophet.domain.marketdata.impl;

import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OrderSide;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.octtech.bw.ByteWatcherRegressionTestHelper;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FilteredMarketDataSnapshotImplBWTest {

    private static final int REPS = 100_000;

    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final FilteredMarketDataSnapshotImpl filteredMarketDataSnapshot = FilteredMarketDataSnapshotImpl.forAggBook();

    public FilteredMarketDataSnapshotImplBWTest() {
        filteredMarketDataSnapshot.setInstrument(Instrument.AUDUSD);
        filteredMarketDataSnapshot.setMarket(Market.WSP_U);

        MarketDataNewOrderImpl marketDataNewOrder1 = (MarketDataNewOrderImpl) filteredMarketDataSnapshot.getBidEventList().addFromSupplier();
        marketDataNewOrder1.setInstrument(Instrument.AUDUSD);
        marketDataNewOrder1.setMarket(filteredMarketDataSnapshot.getMarket());
        marketDataNewOrder1.setSide(OrderSide.BID);
        marketDataNewOrder1.setPrice(1.0);
        marketDataNewOrder1.setQuantity(1_000_000.0);

        MarketDataNewOrderImpl marketDataNewOrder2 = (MarketDataNewOrderImpl) filteredMarketDataSnapshot.getBidEventList().addFromSupplier();
        marketDataNewOrder2.setInstrument(Instrument.AUDUSD);
        marketDataNewOrder2.setMarket(filteredMarketDataSnapshot.getMarket());
        marketDataNewOrder2.setSide(OrderSide.BID);
        marketDataNewOrder2.setPrice(1.1);
        marketDataNewOrder2.setQuantity(2_000_000.0);

        MarketDataNewOrderImpl marketDataOfferOrder1 = (MarketDataNewOrderImpl) filteredMarketDataSnapshot.getBidEventList().addFromSupplier();
        marketDataOfferOrder1.setInstrument(Instrument.AUDUSD);
        marketDataOfferOrder1.setMarket(filteredMarketDataSnapshot.getMarket());
        marketDataOfferOrder1.setSide(OrderSide.OFFER);
        marketDataOfferOrder1.setPrice(1.2);
        marketDataOfferOrder1.setQuantity(1_000_000.0);

        MarketDataNewOrderImpl marketDataOfferOrder2 = (MarketDataNewOrderImpl) filteredMarketDataSnapshot.getBidEventList().addFromSupplier();
        marketDataOfferOrder2.setInstrument(Instrument.AUDUSD);
        marketDataOfferOrder2.setMarket(filteredMarketDataSnapshot.getMarket());
        marketDataOfferOrder2.setSide(OrderSide.OFFER);
        marketDataOfferOrder2.setPrice(1.3);
        marketDataOfferOrder2.setQuantity(2_000_000.0);

    }

    private void scenario1_filters() {
        for (int i = 0; i < REPS; i++) {
            filteredMarketDataSnapshot.setFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED, FilterDecision.FAIL);
            if (filteredMarketDataSnapshot.getFilterOutcome() == FilterDecision.FAIL) {
                if (filteredMarketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_BOOK_CROSSED) == FilterDecision.FAIL) {
                    filteredMarketDataSnapshot.getFilterOutcome(MarketDataFilterType.MARKET_STALE);
                }
            }
        }
    }

    private void scenario2_topOfBookMid() {
        for (int i = 0; i < REPS; i++) {
            filteredMarketDataSnapshot.getMidRate();
        }
    }

    private void scenario3Spread() {
        for (int i = 0; i < REPS; i++) {
            filteredMarketDataSnapshot.getSpread();
        }
    }

    private void scenario4TopOfBookOffer() {
        for (int i = 0; i < REPS; i++) {
            filteredMarketDataSnapshot.getTopOfBookOffer();
        }
    }

    private void scenario5TopOfBookBid() {
        for (int i = 0; i < REPS; i++) {
            filteredMarketDataSnapshot.getTopOfBookBid();
        }
    }

    @Test
    public void aaa_Warmup() {
        scenario1_filters();
        scenario2_topOfBookMid();
        scenario3Spread();
        scenario4TopOfBookOffer();
        scenario5TopOfBookBid();
    }

    @Test
    public void test__AllocationScenario1_filters() {
        helper.testAllocationNotExceeded(
                this::scenario1_filters,
                0 // no allocation!
        );
    }

    @Test
    public void test__AllocationScenario2_topOfBookMid() {
        helper.testAllocationNotExceeded(
                this::scenario2_topOfBookMid,
                0 // no allocation!
        );
    }

    @Test
    public void test__AllocationScenario3_Spread() {
        //                AllocationRecorder.addSampler(new Sampler() {
        //                    public void sampleAllocation(int count, String desc, Object newObj, long size) {
        //                        System.out.println("I just allocated the object " + newObj + " of type " + desc + " whose size is " + size);
        //                        if (count != -1) { System.out.println("It's an array of size " + count); }
        //                    }
        //                });
        //        scenario3Spread();
        helper.testAllocationNotExceeded(
                this::scenario3Spread,
                0 // no allocation!
        );
    }

    @Test
    public void test__AllocationScenario4_TopOfBookOffer() {
        helper.testAllocationNotExceeded(
                this::scenario4TopOfBookOffer,
                0 // no allocation!
        );
    }

    @Test
    public void test__AllocationScenario5_TopOfBookBid() {
        helper.testAllocationNotExceeded(
                this::scenario5TopOfBookBid,
                0 // no allocation!
        );
    }

}