package com.anz.markets.disco.data;

import com.anz.markets.disco.utils.Symbol;
import com.anz.markets.prophet.chronicle.api.ProphetBytes;
import com.anz.markets.prophet.chronicle.api.ProphetMarshallable;

public class MutableSignal implements Signal, ProphetMarshallable {

    private final StringBuilder tmp = new StringBuilder(127);

    private SignalType signalType;
    private double value = Double.NaN;
    private Symbol conditionCode = Symbol.EMPTY;

    public MutableSignal() {
        ;
    }

    public MutableSignal(SignalType signalType) {
        this.signalType = signalType;
    }

    @Override
    public SignalType getSignalType() {
        return signalType;
    }

    public void setSignalType(final SignalType signalType) {
        this.signalType = signalType;
    }

    @Override
    public double getValue() {
        return value;
    }

    public void setValue(final double value) {
        this.value = value;
    }

    @Override
    public Symbol getConditionCode() {
        return conditionCode;
    }

    public void setConditionCode(final Symbol conditionCode) {
        this.conditionCode = conditionCode;
    }

    @Override
    public void readMarshallable(final ProphetBytes in) {
        signalType = SignalType.valueOf(in.readByte());
        value = in.readDouble();
        in.readUTF8(tmp);
        conditionCode = Symbol.get(tmp);
    }

    @Override
    public void writeMarshallable(final ProphetBytes out) {
        out.writeByte(signalType.getId());
        out.writeDouble(value);
        out.writeUTF8((CharSequence) conditionCode.getValue());
    }

    @Override
    public String toString() {
        return signalType.name() + "{" + (float) value + "," + conditionCode + "}";
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }
        final MutableSignal that = (MutableSignal) o;
        return Double.compare(that.value, value) == 0 &&
                signalType == that.signalType &&
                conditionCode == that.conditionCode;
    }

}