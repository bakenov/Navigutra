package com.anz.axle.lg.adapter.acceptance.shared;

import java.util.Objects;
import java.util.Queue;

import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

public interface SharedAcceptanceContext {

    Queue<PricingMessage> pricingMessageQueue();
    Queue<TradingMessage> tradingResponseMessageQueue();
    Queue<TradingMessage> tradingRequestMessageQueue();
    PrecisionClock precisionClock();
    LongIdFactory tradingMessageIdGenerator();

    /** Class that can be used as base class if SharedAcceptanceContext neeeds to be extended */
    class Delegate implements SharedAcceptanceContext {
        private final SharedAcceptanceContext delegate;
        public Delegate(final SharedAcceptanceContext delegate) {
            this.delegate = Objects.requireNonNull(delegate);
        }

        @Override
        public Queue<PricingMessage> pricingMessageQueue() {
            return delegate.pricingMessageQueue();
        }

        @Override
        public Queue<TradingMessage> tradingResponseMessageQueue() {
            return delegate.tradingResponseMessageQueue();
        }

        @Override
        public Queue<TradingMessage> tradingRequestMessageQueue() {
            return delegate.tradingRequestMessageQueue();
        }

        @Override
        public PrecisionClock precisionClock() {
            return delegate.precisionClock();
        }

        @Override
        public LongIdFactory tradingMessageIdGenerator() {
            return delegate.tradingMessageIdGenerator();
        }
    }
}
