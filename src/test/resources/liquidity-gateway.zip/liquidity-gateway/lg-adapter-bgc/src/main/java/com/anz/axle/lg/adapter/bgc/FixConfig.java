package com.anz.axle.lg.adapter.bgc;

import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;

import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import quickfix.DefaultMessageFactory;
import quickfix.FieldNotFound;
import quickfix.FileStoreFactory;
import quickfix.LogFactory;
import quickfix.Message;
import quickfix.MessageFactory;
import quickfix.SessionID;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.axle.lg.adapter.bgc.quickfix.BgcSnapshotFullRefreshHandler;
import com.anz.axle.lg.adapter.bgc.quickfix.LogonToAdminHandler;
import com.anz.axle.lg.adapter.fix.FixEngine;
import com.anz.axle.lg.adapter.fix.LogDestination;
import com.anz.axle.lg.adapter.quickfix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.quickfix.CreateSessionHandler;
import com.anz.axle.lg.adapter.quickfix.FixApplication;
import com.anz.axle.lg.adapter.quickfix.FixMessageDispatcher;
import com.anz.axle.lg.adapter.quickfix.FixMessageSender;
import com.anz.axle.lg.adapter.quickfix.MessageType;
import com.anz.axle.lg.adapter.quickfix.ToAdminHandler;
import com.anz.axle.lg.adapter.quickfix.TypedFixMessageHandler;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.queue.Queue;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    @Bean
    public SessionID pricingSessionId(@Value("${bgc.fix.beginstring}:${bgc.fix.pricing.sendercompid}->${bgc.fix.pricing.targetcompid}") final String pricingSessionIdString) {
        return new SessionID(pricingSessionIdString);
    }

    @Bean
    public FixMessageDispatcher fixPricingMessageDispatcher(final PrecisionClock precisionClock) {

        final TypedFixMessageHandler pricingLogonMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGON);
        final TypedFixMessageHandler pricingLogoutMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.LOGOUT);
        final TypedFixMessageHandler pricingSequenceResetHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.SEQUENCE_RESET);
        final TypedFixMessageHandler pricingHeartbeatMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.HEARTBEAT);
        final TypedFixMessageHandler pricingTestRequestMessageHandler = TypedFixMessageHandler.noop(precisionClock, MessageType.TEST_REQUEST);
        return new FixMessageDispatcher(
                pricingLogonMessageHandler,
                pricingLogoutMessageHandler,
                pricingHeartbeatMessageHandler,
                pricingSequenceResetHandler,
                pricingTestRequestMessageHandler);
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler() {

        final Logger LOGGER = LoggerFactory.getLogger(ApplicationLogonHandler.class);
        return new ApplicationLogonHandler() {
            @Override
            public void onLogon(final SessionID sessionId) {
                LOGGER.info("PricingPublishingSession has been logged on");
            }
            @Override
            public void onLogout(final SessionID sessionId) {
                LOGGER.info("PricingPublishingSession has been logged out");
            }
        };
    }

    @Bean
    public FixMessageSender fixMessageSender(final SessionID pricingSessionId) {
        return new FixMessageSender(pricingSessionId);
    }

    @Bean
    public PriceRounder priceConverter(@Value("${rounding.decimal.place.default}") final int defaultDecimalPlaceToRound,
                                       @Value("#{${rounding.decimal.place.symbols}}") final Map<Integer, Set<String>> decimalPlaceToSymbols) {
        return new PriceRounder(decimalPlaceToSymbols, defaultDecimalPlaceToRound);
    }

    @Bean
    public SnapshotFullRefreshHandler bgcSnapshotFullRefreshHandler(final Consumer<Message> fixMessageSender,
                                                                    final PriceRounder priceRounder) {
        return new BgcSnapshotFullRefreshHandler(fixMessageSender, priceRounder, new DefaultInstrumentKeyLookup());
    }

    @Bean
    public Queue<Message> fixPricingMessageQueue(@Value("${bgc.fix.pricing.queue.capacity}") final int pricingQueueCapacity,
                                                 final MetricRepository<Metric, Venue> metricRepository) {
        return new MonitoredQueue<>(new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(pricingQueueCapacity)),
                (metric, value, element) -> metricRepository.getOrCreate(MonitoredQueueMetric.PRICING.apply(metric), null).record(value));
    }

    @Bean
    public EventLoopStep fixPricingEventLoopStep(final Queue<Message> fixPricingMessageQueue,
                                                 final FixMessageDispatcher fixPricingMessageDispatcher) {
        final Consumer<Message> messageProcessor = message -> {
            try {
                fixPricingMessageDispatcher.accept(message);
            } catch (final FieldNotFound fieldNotFound) {
                LOGGER.error("FixMessageDispatcher fieldNotFound exception", fieldNotFound);
            }
        };
        return EventLoopStep.whenFinalisationNotRequired(() -> fixPricingMessageQueue.poller().processNext(messageProcessor));
    }

    @Bean
    public FixEngine fixEngine(final Properties applicationProperties,
                               @Value("${bgc.fix.pricing.username}") final String pricingUsername,
                               @Value("${bgc.fix.pricing.password}") final String pricingPassword,
                               final Queue<Message> fixPricingMessageQueue,
                               final ApplicationLogonHandler applicationLogonHandler,
                               @Value("${bgc.fix.log.destination}") final LogDestination logDestination) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/bgc-quickfix.ini"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final SessionSettings sessionSettings = new SessionSettings(configuredRuntimeResource.getInputStream());
        final FileStoreFactory fileStoreFactory = new FileStoreFactory(sessionSettings);
        final LogFactory logFactory = logDestination.logFactory(sessionSettings);
        final MessageFactory messageFactory = new DefaultMessageFactory();

        final Function<SessionID, Queue<Message>> eventQueueLookup = sessionID -> fixPricingMessageQueue;

        final ToAdminHandler toAdminHandler = new LogonToAdminHandler(pricingUsername, pricingPassword);
        final FixApplication fixApplication = new FixApplication(eventQueueLookup, toAdminHandler, applicationLogonHandler, CreateSessionHandler.NO_OP);

        final SocketInitiator fixPricingInitiator = new SocketInitiator(fixApplication, fileStoreFactory, sessionSettings, logFactory, messageFactory);

        return new FixEngine("BGCMIDFX-QUOTE", fixPricingInitiator);
    }
}
