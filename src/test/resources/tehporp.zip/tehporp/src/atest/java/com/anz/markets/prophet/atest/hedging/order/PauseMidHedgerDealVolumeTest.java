package com.anz.markets.prophet.atest.hedging.order;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MidHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PassiveHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.SlidingWindowDealVolumeConfigImpl;
import com.anz.markets.prophet.domain.*;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURGBP;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.GBPUSD;
import static com.anz.markets.prophet.domain.Instrument.USDCAD;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.BGCMIDFX;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Market.EBS;
import static com.anz.markets.prophet.domain.Market.FXALLMB;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * AXPROPHET-838 Introduce Execution Frequency(i.e Hedge Deals and Client Deals as signal for delaying hedging decisions for MID Hedgers Only
 * fillQuantity - greater than or EQUAL to this config then trigger delay
 * AXPROPHET-898 - introduce config to determine which triggers to delay. "" string means all MID-HEDGERS(i.e EP and VAR)
 */
@RestartBeforeTest(reason = "As hedger states are left hanging")
@Requirement(value = {Requirement.Ref.HEDGING_AXPROPHET_838})
public class PauseMidHedgerDealVolumeTest extends BaseAcceptanceSpecification {
    NewOrder newOrder;

    // will default empty string to all mid-hedgers.
    private final static String STAND_DOWN_TRIGGERS = "";

    @Test
    public void multiDealVolumeWindowTriggeredOnReceivedTrade() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 499_999, 2000, 4000, "MID_BGC_EP|MID_BGC_VAR", TradingTimeZone.GLOBAL),
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 499_999, 2000, 2000, "MID_BGC_EP|MID_BGC_VAR", TradingTimeZone.LDN),
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 499_999, 2000, 3000, "MID_BGC_EP|MID_BGC_VAR", TradingTimeZone.LDN)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(TradingTimeZone.LDN);
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, BGCMIDFX)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled which BREACHES both trade volume windows
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so will be SLEEPING. Choose LONGEST delay period(3sec). (GLOBAL ignored since LDN config exists)
            // Therefore do NOT place out any orders until t+3.5
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.PAUSED));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // Cannot place order until delay period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_000);
        }
        then:
        // t+3.5sec delay period over
        {
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_EP, HedgePauseState.NOT_PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.NOT_PAUSED));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    // empty string as standDownTrigger defaults to all mid-hedgers only
    public void standDownTriggerBlank() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, Instrument.AUDUSD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(4_000_000)
                                    .setOrderQuantity(1_000_000)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING)).getLast();
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so will be SLEEPING. Therefore do NOT place out any orders until t+4.5
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.PAUSED));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // receive client trade to increase risk above Passive Hedger's min risk
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        // since Passive Hedger NOT delayed, expect Passive Hedge order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.PAS_EBS_EP, HedgeTriggerState.SELLING)).getLast();
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
        and:
        // Cannot place MID Hedger order until delay period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_000);
        }
        then:
        // t+4.5sec delay period over. Both EP and VAR triggers met but only one order is placed (EP TRIGGERED order)
        {
            // since was sleeping, the hedge decisions will progress through the IDLE, SELL_REQ, then SELLING
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    // configure standDownTrigger as Mid_Ep only.  Still expect Mid_Var to trigger
    public void standDownMidEpOnly() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2000, 3000, "MID_BGC_EP", TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so MID_BGC_EP will be SLEEPING.
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.expect(HedgePauseSignal.class, exactly(1), isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_EP, HedgePauseState.PAUSED));
            prophet.notExpect(HedgePauseSignal.class, isPauseHedgeTriggerType(HedgePauseSignalSource.DEAL_VOLUME, HedgeTriggerType.MID_BGC_VAR, HedgePauseState.PAUSED));
        }
        and:
        // however var trigger will place out order instead
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_VAR, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    // While TWAP waiting for end of window, Stand Down is triggered. TWAP hedgers once Stand Down ends.
    public void twapTriggeredFirstThenStandDown() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2_000, 6_000, "MID_BGC_EP|MID_BGC_VAR|AGR_AXL_TWAP", TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(3_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        // Mid Hedger places order
        // TWAP also can hedge but must wait till end of OrderRateTimePeriod at t+3
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so MID Hedger AND TWAP will be SLEEPING. Therefore do NOT place out any orders until t+7.5
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SLEEPING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SLEEPING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // Mid Hedger cannot place order until sleep period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 6_000);
        }
        then:
        // t+7.5sec delay period over. Both EP and VAR triggers met but only one order is placed (EP TRIGGERED order)
        {
            // because were sleeping, the hedge decisions will progress through the IDLE, SELL_REQ, then SELLING
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.BGCMIDFX));
        }
        and:
        // since TWAP stand down expired, TWAP places order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.AXL));
        }
    }

    @Test
    // While TWAP waiting for end of window, Stand Down is triggered. After Stand Down ends, TWAP min risk not met
    public void twapReevaulatesAfterStandDownConcludes() {
        double lowWaterMark = 500_000;
        double highWaterMark = 1_600_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2_000, 6_000, "MID_BGC_EP|MID_BGC_VAR|AGR_AXL_TWAP", TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(3_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        // Mid Hedger places order
        // TWAP also can hedge but must wait till end of OrderRateTimePeriod at t+3
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore Mid Hedger should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so MID Hedger AND TWAP will be SLEEPING. Therefore do NOT place out any orders until t+7.5
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SLEEPING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SLEEPING));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // receive client trade reducing risk below TWAP minRisk requirement
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -500_000, 0.75000));
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));
        }
        and:
        // Mid Hedger cannot place order until sleep period is over
        {
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 6_000);
        }
        then:
        // t+7.5sec delay period over. Both EP and VAR triggers met but only one order is placed (EP TRIGGERED order)
        {
            // because we were sleeping, the hedge decisions will progress through the IDLE, SELL_REQ, then SELLING
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.BGCMIDFX));
        }
        when:
        // t+8s since TWAP stand down expired @t+7.5s, on the next one sec chime TWAP re-evaluates
        // original OrderRateLimit window met but now minRisk not met so do not hedge
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 5_500);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SELLING));
            prophet.notExpect(NewOrder.class);
        }
    }

    @Test
    // TWAP minRisk met during Stand Down period
    public void standDownTriggeredFirstThenTWAP() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2_000, 4_000, "MID_BGC_EP|MID_BGC_VAR|AGR_AXL_TWAP", TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                            new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD)
                                    .setMaximumSpread(0.0002)
                                    .setMinimumQuantity(1_000_000)
                                    .setMinimumRisk(3_500_000)
                                    .setOrderRateLimit(5_000_000)
                                    .setOrderRateTimePeriodMS(5_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_AGGRESSIVE));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        // Mid Hedger places order
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so MID Hedger AND TWAP will be SLEEPING. Therefore do NOT place out any orders until t+5.5
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SLEEPING));
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SLEEPING));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+2sec client trade received to increase risk above TWAP minRisk
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        // Since TWAP is already in SLEEPING state, do NOT start OrderRateTimePeriod i.e TWAP does not place order at t+7
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // Mid hedger Cannot place order until delay period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_500);
        }
        then:
        // t+5.5sec delay period over. Both EP and VAR triggers met but only one order is placed (EP TRIGGERED order)
        // TWAP min risk met and since NOT in SLEEPING state, TWAP can place order at end of OrderRateTimePeriod (i.e @t+11)
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.MID_BGC_EP, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.BGCMIDFX));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD, Market.AXL));
        }
        and:
        // t+11.0s end of TWAP OrderRateTimePeriod. Now able to hedge
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 5_500);
        }
        then:
        {
            prophet.expect(HedgeDecision.class, exactly(1), isHedgeDecision(AUDUSD, HedgeTriggerType.AGR_AXL_TWAP, HedgeTriggerState.SELLING));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD, Market.AXL));
        }
    }

    @Test
    public void duringSleepRiskGoesAboveHighWaterMark() {
        double highWaterMark = 2_500_000;
        double lowWaterMark = 1_600_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50000)  // set var large.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is also lower than LowWaterMark therefore should NOT hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionBelow(AUDUSD, lowWaterMark));

            // But trade volume breached, so will be SLEEPING. Sleep until t+4.5
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+2.5 during SLEEP period, grad position increases above HIGH-WATERMARK again.
        // Therefore hedger should hedge to bring grad position below LOW-WATERMARK once sleep has concluded
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_100_000, 0.75000));
        }
        then:
        {
            // gradPosition is ABOVE High watermark
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, highWaterMark));
        }
        when:
        // during SLEEP, grad position falls below HIGH-WATERMARK but still ABOVE LOW WATERMARK
        // Therefore hedger should STILL hedge to bring grad position below LOW-WATERMARK once sleep has concluded
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -600_000, 0.75000));
        }
        then:
        {
            // gradPosition is BELOW High watermark and ABOVE Low watermark
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition gradientPos = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == AUDUSD).findFirst().get();
            assertThat(Math.abs(gradientPos.getGradientPositionInNotional()) < highWaterMark &&
                    Math.abs(gradientPos.getGradientPositionInNotional()) > lowWaterMark, is(true));
        }
        and:
        // Cannot place order until delay period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2_000);
        }
        then:
        // t+4.5sec delay period over. Order is placed (EP TRIGGERED order)
        {
            // because were sleeping, the hedge decisions will progress through the IDLE, SELL_REQ, then SELLING
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void duringDelayPeriodExtendDelayPeriod() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC, counterparty", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+1.5sec order 500k filled. Trade Volume breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        // But Trade Volume breached. Therefore do NOT place out any orders until t+4.5sec
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+3.0sec during delay period receive counterparty trade 0.5mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1500));
            prophet.receive(tdd.client_trade_001(AUDUSD, 500_000, 0.75, "counterparty"));

        }
        then:
        // Trade Volume received in interval exceeds limit. Delay until t+6sec
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // t+6sec delay period over, do no hedge before then
        {
            // delay for 3sec
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 3_000);
        }
        then:
        // t+6sec delay period over, allowed to hedge
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void duringDelayPeriodDoNoExtendDelayPeriod() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC, counterparty", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+1.5sec order 500k filled. Trade Volume breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        // But Trade Volume breached. Therefore do NOT place out any orders until t+4.5sec
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+4sec during delay period receive counterparty trade 0.5mio
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(2500));
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
            prophet.receive(tdd.client_trade_001(AUDUSD, 500_000, 0.75, "counterparty"));

        }
        then:
        // Trade Volume received in interval does NOT exceed limit. End of delay period still @t+4.5sec
        {
            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // t+4.5sec delay period, do no hedge before then
        {
            // delay for 3sec
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 500);
        }
        then:
        // t+4.5sec delay period over, allowed to hedge
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void multiDealVolumeWindows() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL),
                            new SlidingWindowDealVolumeConfigImpl("counterparty", Instrument.AUDUSD, 999_999, 2000, 4000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES first Trade Volume window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so will be SLEEPING. Therefore do NOT place out any orders until t+4.5
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+2.5 receive Counterparty Trade which breaches second Trade Volume window
        // Therefore do NOT place out any orders until t+6.5
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75, "counterparty"));
        }
        and:
        // Cannot place order until delay period is over at t+6.5sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 4_000);
        }
        then:
        // t+6.5sec delay period over. Allowed to hedge
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void verifyDealVolumeIsTracked() {
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC, counterparty", Instrument.AUDUSD, 1_500_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(500_000)
                                    .setRiskTriggerHighWaterMark(1_500_000)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getSide(), is(HedgeOrderSide.BUY));
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec BUY order 0.5mio filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // t+1.5sec SELL counterparty trade received which breaches limit
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));

            prophet.receive(tdd.client_trade_001(AUDUSD, -1_000_001, 0.75, "counterparty"));
        }
        then:
        // cancel outstanding mid hedger order
        {
            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(AUDUSD, BGCMIDFX));
        }
    }

    @Test
    public void cancelAllMidHedgersOrdersForInstrumentMinTTl() {
        double highWaterMark = 1_500_000.0;
        NewOrder bgcGBPUSDOrder;
        NewOrder bgcEURGBPOrder;
        NewOrder fxallGBPUSDOrder;
        NewOrder fxallEURGBPOrder;

        CancelOrder bgcGBPUSDCancel;
        CancelOrder bgcEURGBPCancel;
        CancelOrder fxallGBPUSDCancel;
        CancelOrder fxallEURGBPCancel;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("counterpartyGBPUSD", Instrument.GBPUSD, 100_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL),
                            new SlidingWindowDealVolumeConfigImpl("counterpartyEURGBP", Instrument.EURGBP, 50_000, 1000, 2000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.EURGBP)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.GBPUSD)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN),
                            new MidHedgerConfigImpl(Market.FXALLMB, Instrument.EURGBP)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_500_000.0)
                                    .setOrderQuantity(1_000_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                            )
                    ));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_FXALL));
            prophet.receive(tdd.marketDataSnapshot(AXL, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(AXL, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(AXL, GBPUSD, 1.25000));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURUSD, 1.05000));
            prophet.receive(tdd.marketDataSnapshot(CNX, EURGBP, 0.85000));
            prophet.receive(tdd.marketDataSnapshot(CNX, GBPUSD, 1.25000));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(GBPUSD, -800_000, 1.25000));
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(GBPUSD, HedgeTriggerType.MID_BGC_EP));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(EURGBP, 12_000_000, 0.85000));
        }
        then:
        // gradient position meets high watermark level for both currencies
        {
            OptimalPositions gradientPositions = prophet.expect(OptimalPositions.class, atLeast(1)).getLast();
            final OptimalPosition eurGBPOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == EURGBP).findFirst().get();
            assertThat(Math.abs(eurGBPOp.getGradientPositionInNotional()) >= highWaterMark, is(true));

            final OptimalPosition gbpUSDOp = gradientPositions.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == GBPUSD).findFirst().get();
            assertThat(Math.abs(Math.abs(gbpUSDOp.getGradientPositionInNotional())) >= highWaterMark &&
                    gbpUSDOp.getGradientPositionInNotional() < 0, is(true));
        }
        and:
        // BOTH hedger places orders for both instruments
        {
            bgcGBPUSDOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD, BGCMIDFX)).getFirst();
            bgcEURGBPOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP, BGCMIDFX)).getFirst();
            fxallGBPUSDOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD, FXALLMB)).getFirst();
            fxallEURGBPOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP, FXALLMB)).getFirst();
        }
        when:
        // receive counterparty trade such that GBPUSD trade volume is breached. GBPUSD delay until t+3sec
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(bgcGBPUSDOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(bgcEURGBPOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(fxallGBPUSDOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(fxallEURGBPOrder));

            prophet.receive(tdd.client_trade_001(GBPUSD, -100_001, 1.25000, "counterpartyGBPUSD"));
        }
        then:
        // ALL GBPUSD orders across mid hedgers should be cancelled
        // however minTTL of 1ms has not been met yet.
        {
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(GBPUSD));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(EURGBP));
        }
        when:
        // t+1ms minTTL met so cancel all GBPUSD orders
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(1));
        }
        then:
        {
            bgcGBPUSDCancel = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(GBPUSD, BGCMIDFX)).getFirst();
            fxallGBPUSDCancel = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(GBPUSD, FXALLMB)).getFirst();
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(EURGBP));
        }
        when:
        {
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(bgcGBPUSDOrder, bgcGBPUSDCancel, 0.0, 0.0));
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(fxallGBPUSDOrder, fxallGBPUSDCancel, 0.0, 0.0));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        when:
        // t+0.5sec receive counterparty trade such that EURGBP trade volume is breached. Delay until t+2.5sec
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(499));
            prophet.receive(tdd.client_trade_001(EURGBP, -50_001, 0.85000, "counterpartyEURGBP"));
        }
        then:
        // ALL EURGBP orders across mid hedgers should be cancelled
        {
            bgcEURGBPCancel = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(EURGBP, BGCMIDFX)).getFirst();
            fxallEURGBPCancel = prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(EURGBP, FXALLMB)).getFirst();
        }
        when:
        {
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(bgcEURGBPOrder, bgcEURGBPCancel, 0.0, 0.0));
            prophet.receive(tdd.hedgeOrderAcknowledgeCancel(fxallEURGBPOrder, fxallEURGBPCancel, 0.0, 0.0));
        }
        then:
        {
            prophet.notExpect(NewOrder.class);
        }
        and:
        // EURGBP delay over at t+2.5sec. Do not expect any orders until then
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 2000);
        }
        then:
        // t+2.5sec EURGBP delay period over, allowed to hedge EURGBP
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP, BGCMIDFX));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(EURGBP, FXALLMB));
            prophet.notExpect(NewOrder.class, isOrderInstrument(EURUSD));
        }
        and:
        // GBPUSD delay over at t+3sec. Do not expect any orders until then
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 500);
        }
        then:
        // t+3.0sec GBPUSD delay period over, allowed to hedge GBPUSD
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD, BGCMIDFX));
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(GBPUSD, FXALLMB));
        }
    }

    @Test
    public void cancelOrdersOfStandDownTriggers() {
        NewOrder bgcMidHedgerOrder;
        NewOrder ebsPassiveHedgeOrder;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC, counterparty", Instrument.USDCAD, 100_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, USDCAD)
                                    .setRiskTriggerLowWaterMark(500_000)
                                    .setRiskTriggerHighWaterMark(1_000_000)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    ))
                    .setPassiveHedgerConfigs(Arrays.asList(
                            new PassiveHedgerConfigImpl(Market.EBS, USDCAD)
                                    .setReferenceMarket(Market.AXL)
                                    .setMaximumTargetMarketPriceImprovementPips(-0.5)
                                    .setArbitrageProtectionDistancePips(0.2)
                                    .setAdditionalSpreadPips(-0.5)
                                    .setPriceSamples(30)
                                    .setPriceSampleInterval(1000)
                                    .setMinimumRisk(1_000_000)
                                    .setOrderQuantity(1_250_000)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_PASSIVE_EBS));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, USDCAD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, USDCAD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(EBS, USDCAD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(USDCAD, -1_000_000, 0.750000));
        }
        then:
        {
            bgcMidHedgerOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD, BGCMIDFX)).getLast();
            ebsPassiveHedgeOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(USDCAD, EBS)).getLast();
        }
        when:
        // receive counterparty trade which breaches limit
        {
            prophet.receive(tdd.hedgeOrderConfirmed(bgcMidHedgerOrder));
            prophet.receive(tdd.hedgeOrderConfirmed(ebsPassiveHedgeOrder));
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));

            prophet.receive(tdd.client_trade_001(USDCAD, -100_001, 0.75, "counterparty"));
        }
        // cancel Mid Hedger order only
        then:
        {
            prophet.expect(CancelOrder.class, exactly(1), isCancelOrderInstrument(USDCAD, BGCMIDFX));
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(USDCAD, EBS));
        }
    }

    @Test
    public void verifyTrackingOfConfiguredInstrument() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            // monitor instrument is USDCAD
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC, counterparty", Instrument.USDCAD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled. AUD/USD total filled 1mio. However AUD/USD is not configured
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
        }
        when:
        // receive counterparty trade for AUD/USD(i.e NOT USD/CAD)
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));

            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000_000, 0.75, "counterparty"));
        }
        then:
        // do not cancel mid hedger order as AUD/USD is not tracked
        {
            prophet.notExpect(CancelOrder.class, isCancelOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void turnOnHedgerDuringDelayPeriod() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 1_000_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setRiskTriggerLowWaterMark(lowWaterMark)
                                    .setRiskTriggerHighWaterMark(highWaterMark)
                                    .setOrderQuantity(500_000)
                                    .setVarTriggerHighVar(50)  // set var small.
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+0.5sec order 500k filled
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge.
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(500_000.0));
        }
        when:
        // t+1.5sec order 500k filled which BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        {
            // gradPosition is still higher than LowWaterMark therefore should hedge.
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            // But trade volume breached, so will be SLEEPING. Therefore do NOT place out any orders until t+4.5
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // first hedger is disabled
        // then hedger is enabled which resets hedger i.e returns hedger back to IDLE and cancels delay period
        {
            prophet.receive(tdd.disableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_000, 0.75005));
        }
        then:
        // hedger places order immediately
        {
            // IDLE, SELL_REQ, then SELLING
            final HedgeDecision status = prophet.expect(HedgeDecision.class, exactly(3), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP)).getLast();
            assertThat(status.getHedgeTriggerState(), is(HedgeTriggerState.SELLING));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    // Prod behaviour where hedger receives Trade first and then Order Event
    // Trade Volume breached but do NOT cancel the order that the incoming Trade is filling
    public void receiveTradeBeforeOrderEventAndBreach() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 900_000, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
                    .setMidHedgerConfigs(Arrays.asList(
                            new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                    .setVarTriggerHighVar(80000)
                                    .setRiskTriggerLowWaterMark(800_000.0)
                                    .setRiskTriggerHighWaterMark(1_200_000)
                                    .setOrderQuantity(1_000_000)
                                    .setTradingTimeZone(TradingTimeZone.LDN)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 1_500_000, 0.750000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // receive Trade first(before order event)
        {
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillTrade(newOrder, 0.75);
        }
        then:
        // Trade reduces position below low water mark. Since trade is converted to OrderEvent, the hedger knows it caused the position change
        // Trade Volume breached but do NOT cancel the outstanding order(as the received Trade represents filling of that trade)
        {
            // the FullFill should transition us to IDLE and then breach subsequently transitions to SLEEPING
            prophet.notExpect(CancelOrder.class);
            List<HedgeDecision> hedgeDecision = prophet.expect(HedgeDecision.class, exactly(2), isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            assertThat(hedgeDecision.get(0).getHedgeTriggerState(), is(HedgeTriggerState.IDLE));
            assertThat(hedgeDecision.get(1).getHedgeTriggerState(), is(HedgeTriggerState.SLEEPING));
        }
        when:
        // receive actual Order Event (this is a duplicate and should be ignored)
        {
            prophet.clearOutputBuffer();
            prophet.receiveHedgeOrderFullFillOrderEvent(newOrder, 0.75);
        }
        then:
        {
            prophet.notExpect(HedgeDecision.class, isHedgeTriggerType(AUDUSD, HedgeTriggerType.MID_BGC_EP));
            prophet.notExpect(NewOrder.class);
            prophet.notExpect(CancelOrder.class);
        }
    }

    @Test
    public void resetOnReceiptOfNewConfiguration() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;
        final ConfigurationDataDefault config = tdd.configuration_hedging_001()

                .setMidHedgerConfigs(Arrays.asList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                .setRiskTriggerLowWaterMark(lowWaterMark)
                                .setRiskTriggerHighWaterMark(highWaterMark)
                                .setOrderQuantity(1_000_000)
                                .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ));

        setup:
        {
            prophet.receive(config
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    )));
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+0.5sec order filled and so BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to want to hedge.  But cannot as breached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+1.0sec receive new configuration(4 sec delay), the control signal is reset and so hedger hedges again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(config
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 999_999, 2000, 4000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    )),false);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+1.5sec order filled and so BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to want to hedge.  But cannot as breached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        and:
        // Cannot place order until delay period is over
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(() -> prophet.notExpect(NewOrder.class), 4_000);
        }
        then:
        // t+5.5sec delay period over
        {
            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void disableViaNoConfiguration() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;
        final ConfigurationDataDefault config = tdd.configuration_hedging_001()
                .setMidHedgerConfigs(Arrays.asList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                .setRiskTriggerLowWaterMark(lowWaterMark)
                                .setRiskTriggerHighWaterMark(highWaterMark)
                                .setOrderQuantity(1_000_000)
                                .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ));

        setup:
        {
            prophet.receive(config
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+0.5sec order filled and so BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to want to hedge.  But cannot as breached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+1.0sec receive new configuration(trade volume config removed), the control signal is reset and so hedger hedges again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(config.setSlidingWindowDealVolumeConfigs(Arrays.asList()), false);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+1.5sec order filled and so BREACHES trade volume limit
        // However Trade Volume check is disabled i.e no config
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }

    @Test
    public void disableViaZeroDelayConfiguration() {
        double highWaterMark = 1_600_000;
        double lowWaterMark = 500_000;
        final ConfigurationDataDefault config = tdd.configuration_hedging_001()
                .setMidHedgerConfigs(Arrays.asList(
                        new MidHedgerConfigImpl(Market.BGCMIDFX, Instrument.AUDUSD)
                                .setRiskTriggerLowWaterMark(lowWaterMark)
                                .setRiskTriggerHighWaterMark(highWaterMark)
                                .setOrderQuantity(1_000_000)
                                .setVarTriggerHighVar(1_000_000_000) // a high value to effectively disable
                                .setTradingTimeZone(TradingTimeZone.LDN)
                ));

        setup:
        {
            prophet.receive(config
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 999_999, 2000, 3000, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    ))
            );
            prophet.receive(tdd.enableHedger(Portfolio.HEDGER_MID_BGC));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74998, 0.75002, now()));
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(CNX, AUDUSD, 0.74998, 0.75002, now()));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(AUDUSD, 3_000_000, 0.75000));
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+0.5sec order filled and so BREACHES trade volume limit
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to want to hedge.  But cannot as breached
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.notExpect(NewOrder.class, isOrderInstrument(AUDUSD));
        }
        when:
        // t+1.0sec receive new configuration(delay set to 0), the control signal is reset and so hedger hedges again
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(config
                    .setSlidingWindowDealVolumeConfigs(Arrays.asList(
                            new SlidingWindowDealVolumeConfigImpl("HEDGER_MID_BGC", Instrument.AUDUSD, 900_000, 2000, 0, STAND_DOWN_TRIGGERS, TradingTimeZone.GLOBAL)
                    )), false);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD)).getLast();
            assertThat(newOrder.getQuantity(), is(1_000_000.0));
        }
        when:
        // t+1.5sec order filled and so BREACHES trade volume limit
        // However delay set to 0
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.MILLISECONDS.toMillis(500));
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.75);
        }
        then:
        // gradPosition is still higher than LowWaterMark. Continue to hedge sincy delay is 0
        {
            prophet.expect(OptimalPositions.class, atLeast(1), isGradientPositionAbove(AUDUSD, lowWaterMark));

            prophet.expect(NewOrder.class, exactly(1), isOrderInstrument(AUDUSD));
        }
    }
}
