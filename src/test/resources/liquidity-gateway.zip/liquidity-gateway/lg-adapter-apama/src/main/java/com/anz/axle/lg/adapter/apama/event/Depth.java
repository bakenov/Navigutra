package com.anz.axle.lg.adapter.apama.event;

import java.util.List;
import java.util.Map;

import com.apama.event.parser.DictionaryFieldType;
import com.apama.event.parser.EventType;
import com.apama.event.parser.Field;
import com.apama.event.parser.FloatFieldType;
import com.apama.event.parser.IntegerFieldType;
import com.apama.event.parser.SequenceFieldType;
import com.apama.event.parser.StringFieldType;

public class Depth {
    public static final String EVENT_NAME = "com.apama.marketdata.Depth";

    public static final Field<String> FIELD_SYMBOL = GeneralApamaEventFields.FIELD_SYMBOL;

    public static final Field<List<Double>> FIELD_BID_PRICES = new Field<>("bidPrices", new SequenceFieldType<>(FloatFieldType.TYPE));
    public static final Field<List<Double>> FIELD_ASK_PRICES = new Field<>("askPrices", new SequenceFieldType<>(FloatFieldType.TYPE));
    public static final Field<List<Double>> FIELD_MID_PRICES = new Field<>("midPrices", new SequenceFieldType<>(FloatFieldType.TYPE));
    public static final Field<List<Long>> FIELD_BID_QUANTITIES = new Field<>("bidQuantities", new SequenceFieldType<>(IntegerFieldType.TYPE));
    public static final Field<List<Long>> FIELD_ASK_QUANTITIES = new Field<>("askQuantities", new SequenceFieldType<>(IntegerFieldType.TYPE));
    public static final Field<Map<String, String>> FIELD_EXTRA_PARAMS = new Field<>("extraParams", new DictionaryFieldType<>(StringFieldType.TYPE, StringFieldType.TYPE));

    public static final EventType EVENT_TYPE = initEventType();

    private static EventType initEventType() {
        return new EventType(EVENT_NAME,
                FIELD_SYMBOL,
                FIELD_BID_PRICES,
                FIELD_ASK_PRICES,
                FIELD_MID_PRICES,
                FIELD_BID_QUANTITIES,
                FIELD_ASK_QUANTITIES,
                FIELD_EXTRA_PARAMS);
    }
}
