package com.anz.markets.efx.ngaro.sbe;

import java.util.Objects;

import com.anz.markets.efx.ngaro.codec.StringDecoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.LongCodec;

/**
 * Encoder for fixed length string.
 * <p/>
 * This class is thread safe. NOTE however that the {@link FixedStringTarget} passed to the constructor may not be
 * thread safe and hence this decoder instance may also not be thread safe.
 *
 * @param <E> the type of the enclosing encoder returned by encode methods for chained encoding
 */
public class FixedStringEncoder<E> implements StringEncoder<E> {

    private static final byte NULL = 0;

    private final E enclosingEncoder;
    private final FixedStringTarget target;
    private final int length;

    public FixedStringEncoder(final E enclosingEncoder, final FixedStringTarget target, final int length) {
        this.enclosingEncoder = Objects.requireNonNull(enclosingEncoder);
        this.target = Objects.requireNonNull(target);
        this.length = length;
        if (length < 0) {
            throw new IllegalArgumentException("Negative length: " + length);
        }
    }

    @Override
    public E encodeEmpty() {
        for (int i = 0; i < length; i++) {
            target.putByte(i, NULL);
        }
        return enclosingEncoder;
    }

    @Override
    public E encode(final CharSequence source, final int sourceOffset, final int length) {
        final int fixedLen = this.length;
        final int len = Math.min(length, fixedLen);
        for (int i = 0; i < len; i++) {
            final byte b = (byte)source.charAt(sourceOffset + i);
            target.putByte(i, b);
        }
        for (int i = len; i < fixedLen; i++) {
            target.putByte(i, NULL);
        }
        return enclosingEncoder;
    }

    @Override
    public <S> E encode(final S source, final ByteReader<? super S> reader, final int sourceOffset, final int length) {
        final int fixedLen = this.length;
        final int len = Math.min(length, fixedLen);
        for (int i = 0; i < len; i++) {
            final byte b = reader.readByte(source, sourceOffset + i);
            target.putByte(i, b);
        }
        for (int i = len; i < fixedLen; i++) {
            target.putByte(i, NULL);
        }
        return enclosingEncoder;
    }

    @Override
    public E encodeFrom(final StringDecoder stringDecoder) {
        stringDecoder.decodeTo(target, FixedStringTarget.BYTE_WRITER, 0, length);
        return enclosingEncoder;
    }

    @Override
    public E encodeLong(final long value) {
        LongCodec.encodeSigned(value, target, FixedStringTarget.BYTE_WRITER);
        return enclosingEncoder;
    }
}