package com.anz.markets.prophet.atest.pricing._9_forward_points;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.general.InstrumentConfig;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientPriceThrottleConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.InstrumentConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MarketConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.market.MarketConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.spread.ClientSpreadConfig;
import com.anz.markets.prophet.config.business.domain.tabular.pricing.throttling.ClientPriceThrottleConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.Tenor;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.spot.SpotDateImpl;
import org.apache.logging.log4j.Level;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.anz.markets.prophet.domain.Region.GB;

public class ForwardPoints_Tolerance_Check_Test extends BaseAcceptanceSpecification {

    // https://jira.service.anz/browse/AXPROPHET-672
    // Superseded by https://jira.service.anz/browse/AXPROPHET-967

    private static final String FWD_POINT_FAILED_VALIDATION_REGEX = ".*Exception processing message.*";

    @Test
    public void positiveBidForwardPointExceedsTolerance() {

        final Instrument driverPairA = Instrument.EURUSD;

        given:
        {
            // receive SPOT tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, 0.0, 0.0, LocalDate.now().plusDays(2), LocalDate.now().plusDays(2), Tenor.SPOT));
            // receive 1W tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, 6.01d, 6.09d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_DIVERGENCE_ALLOWANCE, 0.3d))  // default 0.d
            );

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, driverPairA, 1.14000, 0.0004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            // receive 1W tenor fwd points such that BID exceeds max allowance
            prophet.receive(tdd.forwardPoint(driverPairA, 71.6d, 71.67d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));
        }
        then:
        // java.lang.IllegalArgumentException: Forward point has failed validation due to large change in implied interest rate differential
        // old iird=1.027489348, new iird=1.327493734, change threshold=0.3).
        {
            prophet.expect(Level.ERROR, matches(FWD_POINT_FAILED_VALIDATION_REGEX));
        }
    }

    @Test
    // AXPROPHET-1245
    public void positiveBidForwardPointExceedsToleranceFromUM() throws Exception {

        final Instrument driverPairA = Instrument.EURUSD;

        precondition:
        {
            prophet.startUmProbes(tdd.configuration_pricing_base(), true);
        }
        given:
        {
            // receive/send spot tenor fwd points
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, 0.0, 0.0, LocalDate.now().plusDays(2), LocalDate.now().plusDays(2), Tenor.SPOT));
            // receive 1W tenor fwd points
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, 6.01d, 6.09d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_DIVERGENCE_ALLOWANCE, 0.3d))  // default 0.d
            );

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, driverPairA, 1.14000, 0.0004));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            // receive 1W tenor fwd points such that BID exceeds max allowance
            prophet.receiveFWDFromUM(tdd.forwardPoint(driverPairA, 71.6d, 6.09d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));
        }
        then:
        // java.lang.IllegalArgumentException: Forward point has failed validation due to large change in implied interest rate differential
        // old iird=1.027489348, new iird=1.327493734, change threshold=0.3).
        {
            prophet.expect(Level.ERROR, matches(FWD_POINT_FAILED_VALIDATION_REGEX));
        }
    }

    @Test
    public void negativeAskForwardPointExceedsTolerance() {

        final Instrument driverPairA = Instrument.USDJPY;

        given:
        {
            // receive/send spot tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, 0.0, 0.0, LocalDate.now().plusDays(2), LocalDate.now().plusDays(2), Tenor.SPOT));
            // receive/send spot next tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, -7.43d, -7.28d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));

            prophet.receive(tdd.configuration_pricing_base()
                    .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.PRICING_FWD_DIVERGENCE_ALLOWANCE, 0.3d))  // default 0.d
            );

            prophet.receive(tdd.marketDataSnapshot(Market.CNX, driverPairA, 113.45, 0.04));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.forwardPoint(driverPairA, -72.70d, -72.56d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(9), Tenor.ONE_WEEK));
        }
        then:
        // java.lang.IllegalArgumentException: Forward point has failed validation due to large change in implied interest rate differential
        // old iird=0.966540326, new iird=0.666506328, change threshold=0.3).
        {
            prophet.expect(Level.ERROR, matches(FWD_POINT_FAILED_VALIDATION_REGEX));
        }
    }

    @Test
    // AXPROPHET-1230
    public void doNotCheckForNDFInstruments() {

        final Instrument driverPairA = Instrument.USDIN1_1M;

        given:
        {
            ConfigurationDataDefault configurationDataDefault = tdd.configuration_pricing_base();

            final List<ClientSpreadConfig> clientSpreadConfigs = new ArrayList<>(configurationDataDefault.getClientSpreadConfigs());
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 8.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 10.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 12.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_B, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_C, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
            clientSpreadConfigs.add(new ClientSpreadConfigImpl(Market.WSP_Z, Instrument.USDIN1_1M, com.anz.markets.prophet.domain.Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 6.0));
            configurationDataDefault.setClientSpreadConfigs(clientSpreadConfigs);

            final List<MarketConfig> marketConfigs = new ArrayList<>(configurationDataDefault.getMarketConfigs());
            marketConfigs.add(new MarketConfigImpl(Market.EBS).setRegion(GB).setInstrument(Instrument.USDIN1_1M).setEnabled(true));
            configurationDataDefault.setMarketConfigs(marketConfigs);
            configurationDataDefault.addAggBook(Market.WSP_U, Instrument.USDIN1_1M, TradingTimeZone.GLOBAL, Region.GB, Market.EBS);

            final List<InstrumentConfig> instrumentConfigs = new ArrayList<>(configurationDataDefault.getInstrumentConfigs());
            instrumentConfigs.add(new InstrumentConfigImpl(Instrument.USDIN1).setSpotDecimalPlaces(2).setSpotFractionalPip(1).setFwdPtsDecimalPlaces(2).setFwdPtsFractionalPip(0).setAllInDecimalPlaces(3).setAllInFractionalPip(0).setPrecisionMultiplier(1).setSpreadMultiplier(0));
            configurationDataDefault.setInstrumentConfigs(instrumentConfigs);

            final List<ClientPriceThrottleConfig> throttleConfigs = new ArrayList<>(configurationDataDefault.getClientPriceThrottleConfigs());
            throttleConfigs.add(new ClientPriceThrottleConfigImpl(Market.ANY, Currency.USD, Currency.INR)
                    .setNoActivityHeartbeatFrequencyMs(20000)
                    .setStartStopTimePeriodMS(0)
                    .setLimit(2)
                    .setTimePeriod(2)
                    .setMinimumPriceDeltaFractionOfSpread(0.01)
                    .setMinimumPriceDeltaFractionOfPreviousSpread(0.01)
                    .setOverrideLimit(2)
                    .setOverrideTimePeriod(2)
                    .setOverrideMinimumPriceDeltaFractionOfMid(0.000001)
                    .setMinimumPriceDeltaFractionOfPreviousSpread(0.001));
            configurationDataDefault.setClientPriceThrottleConfigs(throttleConfigs);

            prophet.receive(configurationDataDefault);
            prophet.receive(new SpotDateImpl(Instrument.USDIN1_1M, LocalDate.now().plusDays(2)));

            // receive/send spot tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, 0.0, 0.0, LocalDate.now().plusDays(2), LocalDate.now().plusDays(2), Tenor.SPOT));
            // receive/send spot next tenor fwd points
            prophet.receive(tdd.forwardPoint(driverPairA, 27.0d, 29.0d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Market.EBS, Instrument.USDIN1_1M, 71.650, 0.02));
            prophet.clearOutputBuffer();
            prophet.incrementTime(TimeUnit.SECONDS.toMillis(1));
            prophet.receive(tdd.forwardPoint(driverPairA, 250.0d, 252.0d, LocalDate.now().plusDays(2), LocalDate.now().plusDays(32), Tenor.ONE_MONTH));
        }
        then:
        {
            prophet.notExpect(Level.ERROR, matches(FWD_POINT_FAILED_VALIDATION_REGEX));
        }
    }
}
