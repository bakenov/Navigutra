package com.anz.axle.adapters.wssdeal.jms;

import anz.markets.messaging.endpoint.intf.AbstractSource;
import anz.markets.messaging.types.PDMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.SessionAwareMessageListener;

import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

public class JmsMessageListener extends AbstractSource<String> implements SessionAwareMessageListener<TextMessage> {
    private static final Logger LOG = LoggerFactory.getLogger(JmsMessageListener.class);
    private static final String  SOURCE_SYSTEM_HEADER= "META_sourceSystem";
    private static final String  SOURCE_SYSTEM= "WALLSTREET";

    @Override
    public void onMessage(TextMessage message, Session session) throws JMSException {
        LOG.info(String.format("Received Message - %s", message.getText()));
        final String id = getId(message);
        try {
            String sourceSystem = message.getStringProperty(SOURCE_SYSTEM_HEADER);
            if(!SOURCE_SYSTEM.equalsIgnoreCase(sourceSystem)){
                LOG.info(String.format("Message filtered on metadata. Source system found [%s] expected [%s].",sourceSystem, SOURCE_SYSTEM));
                return;
            }
            if (!getSink().onMessage(new PDMessage<String>(id, message.getText()))) {
                LOG.info(String.format("JMS Message not consumed - id=%s", id));
            }else {
                LOG.info(String.format("JMS Message consumed - id=%s", id));
            }
        } catch (JMSException ex) {
            LOG.error(String.format("JMS Exception while processing message %s", message.getText()), ex);
        }   catch (Throwable th){
            LOG.error(String.format("Problem while processing message %s", message.getText()), th);
        }
        session.commit();
    }

    private String getId(TextMessage message) throws JMSException {
        return message.getJMSMessageID();
    }
}
