package com.anz.axle.lg.adapter.bgc;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.agrona.concurrent.IdleStrategy;
import org.agrona.concurrent.ManyToOneConcurrentArrayQueue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import com.anz.axle.lg.config.IdleStrategyFactory;
import com.anz.axle.lg.config.IdleStrategyId;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MetricDomain;
import com.anz.axle.lg.metric.MetricLoggingConfig;
import com.anz.axle.lg.metric.MetricRepositoryFactory;
import com.anz.axle.lg.publisher.BackPressureStrategy;
import com.anz.axle.lg.publisher.ExponentialBackoffBackPressureStrategy;
import com.anz.axle.microtime.NanoClock;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.servicelifecycle.Service;
import com.anz.lg.messaging.event.EventLoopService;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.messaging.transport.api.Connection;
import com.anz.markets.efx.messaging.transport.api.PollingStrategy;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.queue.DefaultQueue;
import com.anz.markets.efx.queue.Queue;

@Configuration
public class CommonConfig {
    public static final String MAIN_EVENT_LOOP_NAME = "MainEventLoop";

    @Bean
    public PrecisionClock precisionClock() {
        return NanoClock.nanoClockUTC();
    }

    @Bean
    public MetricRepository<Metric, Venue> metricRepository() {
        return MetricRepositoryFactory.defaultMetricRepository();
    }

    @Bean
    public ScheduledExecutorService scheduledExecutorService() {
        return Executors.newSingleThreadScheduledExecutor(new ThreadFactoryBuilder().setNameFormat("async-%d").build());
    }

    @Bean
    public BackPressureStrategy backPressureStrategy(@Value("${messaging.backPressure.backoff.initialNanos}") final long initialBackoffNanos,
                                                     @Value("${messaging.backPressure.backoff.maxNanos}") final long maxBackoffNanos,
                                                     @Value("${messaging.backPressure.backoff.factor}") final int backoffFactor) {
        return new ExponentialBackoffBackPressureStrategy(System::nanoTime, initialBackoffNanos, maxBackoffNanos, backoffFactor);
    }

    @Bean
    public Queue<Runnable> mainEventLoopQueue(@Value("${main.event.loop.queue.capacity}") final int queueCapacity) {
        return new DefaultQueue<>(new ManyToOneConcurrentArrayQueue<>(queueCapacity));
    }

    @Bean
    public IdleStrategy idleStrategy(final @Value("${main.event.loop.idle.strategy}") IdleStrategyId idleStrategyId,
                                     final @Value("${main.event.loop.idle.strategy.backoff.maxSpins}") long backOffMaxSpins,
                                     final @Value("${main.event.loop.idle.strategy.backoff.maxYields}") long backOffMaxYields,
                                     final @Value("${main.event.loop.idle.strategy.backoff.maxParkPeriodUs}") long backOffMaxParkPeriodUs) {
        return IdleStrategyFactory.create(idleStrategyId, backOffMaxSpins, backOffMaxYields, backOffMaxParkPeriodUs);
    }

    @Bean
    public EventLoopStep mainLoopMonitoringStep(final MetricRepository<Metric, Venue> metricRepository) {
        return EventLoopStep.whenFinalisationRequired(() -> {metricRepository.getOrCreate(Metric.MAIN_LOOP_ITERATION_CNT, null).record(1); return false;});
    }

    @Bean
    public Service mainEventLoop(@Qualifier("fixPricingEventLoopStep") final EventLoopStep fixPricingEventLoopStep,
                                 final EventLoopStep mainLoopMonitoringStep,
                                 final Queue<Runnable> mainEventLoopQueue,
                                 final Connection connection,
                                 final @Value("${messaging.polling.strategy.conductor}") PollingStrategy.Conductor conductor,
                                 final IdleStrategy idleStrategy) {
        if (conductor != PollingStrategy.Conductor.APPLICATION)
            throw new IllegalArgumentException("messaging.polling.strategy.conductor must be set to APPLICATION");
        final Consumer<Runnable> runnableProcessor = Runnable::run;
        return new EventLoopService(
                MAIN_EVENT_LOOP_NAME,
                10, TimeUnit.SECONDS, idleStrategy,
                fixPricingEventLoopStep,
                EventLoopStep.whenFinalisationRequired(() -> mainEventLoopQueue.poller().processNext(runnableProcessor)),
                EventLoopStep.whenFinalisationNotRequired(() -> connection.pollingStrategy().processNext()),
                mainLoopMonitoringStep);
    }

    @Bean
    public ScheduledFuture<?> mainEventLoopMetricReporterJob(final MetricRepository<Metric, Venue> metricRepository,
                                                             final Queue<Runnable> mainEventLoopQueue,
                                                             final ScheduledExecutorService scheduledExecutorService,
                                                             @Value("${metrics.reporting.period.sec}") final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(MetricDomain.MAIN_LOOP, metricRepository);
        final Runnable metricsReporter = () -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository);
        return scheduledExecutorService.scheduleWithFixedDelay(() -> mainEventLoopQueue.appender().enqueue(metricsReporter), periodSeconds, periodSeconds, TimeUnit.SECONDS);
    }

    @Bean
    public ScheduledFuture<?> concurrentMetricMetricReporterJob(final MetricRepository<Metric, Venue> metricRepository,
                                                                final ScheduledExecutorService scheduledExecutorService,
                                                                @Value("${metrics.reporting.period.sec}") final int periodSeconds) {
        final MetricRepository<Metric, Venue> domainScopedMetricRepository = MetricRepositoryFactory.domainScoped(MetricDomain.CONCURRENT, metricRepository);
        return scheduledExecutorService.scheduleWithFixedDelay(() -> MetricLoggingConfig.logAndResetAll(domainScopedMetricRepository), periodSeconds, periodSeconds, TimeUnit.SECONDS);
    }
}
