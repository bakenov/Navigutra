package com.anz.markets.prophet.atest.hedging.firewall;

import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.config.business.domain.tabular.impl.AggressiveTwapHedgerConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.HedgeFirewallConfigImpl;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import org.apache.logging.log4j.Level;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.Test;

import java.util.Arrays;
import java.util.EnumSet;

import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.AGGREGATED_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_ORDER_SENT_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_HOUR;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_LOSS_PER_MIN;
import static com.anz.markets.prophet.domain.HedgeFirewallType.REVAL_PNL_PROFIT_PER_DAY;
import static com.anz.markets.prophet.domain.HedgeFirewallType.UNREALISED_POSITION_PER_30_SEC;
import static com.anz.markets.prophet.domain.Instrument.AUDJPY;
import static com.anz.markets.prophet.domain.Instrument.AUDUSD;
import static com.anz.markets.prophet.domain.Instrument.EURSEK;
import static com.anz.markets.prophet.domain.Instrument.EURUSD;
import static com.anz.markets.prophet.domain.Instrument.USDJPY;
import static com.anz.markets.prophet.domain.Market.AXL;
import static com.anz.markets.prophet.domain.Market.CNX;
import static com.anz.markets.prophet.domain.Portfolio.HEDGER_AGGRESSIVE;
import static com.anz.markets.prophet.domain.Region.GB;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.BREACHED;
import static com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus.Status.NOT_BREACHED;
import static java.lang.Double.NEGATIVE_INFINITY;
import static java.lang.Double.NaN;
import static java.lang.Double.POSITIVE_INFINITY;
import static java.util.Arrays.asList;
import static java.util.concurrent.TimeUnit.HOURS;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

@Requirement({Ref.HEDGING_FIREWALL_4_9_12, Ref.HEDGING_FIREWALL_4_9_13, Ref.HEDGING_FIREWALL_4_9_14, Ref.PROFIT_AND_LOSS_4_2_8, Ref.PROFIT_AND_LOSS_4_2_9})
public class AggregatedPnlLossFirewallTest extends ForEachHedgePortfolioBaseAcceptanceSpecification {

    // todo:
    // NaN pnl should update hedge firewall status as breached.

    @Test
    public void shouldLogErrorWhenNoMidRate() {
        when:
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9));
        }
        then:
        {
            prophet.expect(Level.ERROR, matches(".*could not evaluate .* no mid rate for AUD"));
        }
    }

    @Test
    public void shouldNotReactToClientDeal() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001());
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.94332, 0.00004, now()));
            prophet.receive(tdd.client_trade_001(1_000_000_000, 0.9));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class);
        }
    }

    @Test
    public void shouldEmitNotConfiguredWhenReceiveTradeButNotConfiguration() {
        when:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList()));
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.94332, 0.00004, now()));
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.9));
        }
        then:
        {
            final EnumSet<HedgeFirewallType> pnlFirewallTypes = EnumSet.of(
                    AGGREGATED_PNL_LOSS_PER_MIN,
                    AGGREGATED_PNL_LOSS_PER_HOUR,
                    AGGREGATED_PNL_LOSS_PER_DAY,
                    AGGREGATED_PNL_PROFIT_PER_DAY);

            for (final HedgeFirewallType hedgeFirewallType : pnlFirewallTypes) {
                final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(hedgeFirewallType, portfolio)).getFirst();
                assertThat(status.getStatus(), is(HedgeFirewallStatus.Status.NOT_CONFIGURED));
                assertThat(status.getPortfolio(), is(portfolio));
            }
        }
    }

    @Test
    public void shouldSendUnbreachedStatusWhenBreachedPnlSlidesOutOf1MinWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -499.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));

            // AXPROPHET-927 Should have no impact on existing scenario
            prophet.receive(tdd.biasPosition(Currency.AUD, 3_000_000));
        }
        when:
        // t+0
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.95090));
        }
        // pnl of 0
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // @t+30 seed pnl 0 at reval time
        {
            prophet.incrementTime(30 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // t+30, first trade not breached.
        {
            // pnl of -100
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.95100));
        }
        then:
        // pnl -100 => not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // t+50, instantaneous pnl update with new mid rate - not yet breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
            // pnl of -200
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95080));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+51, instantaneous pnl update with new mid rate - breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);
            // pnl of -500
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95050));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -500, -500, -500, 0, -499.99));
        }
        when:
        // t+60, past reval - pnl is crystallised. breached remains.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(9 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+61, pnl is crystallised and does not move when mid moves. breached remain.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95100));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+90, pnl @t+0 of 0 and -100 slide out of window
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(29 * 1_000);
        }
        then:
        {   // t+50 Agg P/L = -200 (HIGH)
            // t+51 Agg P/L = -500 (LOW)
            // LOSS = 300 => NOT BREACHED

            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, NOT_BREACHED, -300, 0, -500, -200, -499.99));
        }
    }

    @Test
    public void shouldSendBreachedStatusWhenPnlSlidesOutOf1HourWindow() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_HOUR, -99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95090));
        }
        when:
        // t+0, first trade not breached.
        {
            // pnl of 0
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, -1_000_000, 0.95090));
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_HOUR, BREACHED, portfolio));
        }
        when:
        // t+20, instantaneous pnl update with new mid rate - not yet breached.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(20 * 1_000);
            // pnl of +200
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.95070));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio));
        }
        when:
        // t+30, past reval - +200 pnl is crystallised.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio));
        }
        when:
        // t+40, receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(10 * 1_000);
            // pnl of -100.  Aggregated Pnl is 200 + (-100) = +100
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 1_000_000, 0.95080));
        }
        then:
        // not breached.
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio));
        }
        when:
        // t+60mins, pnl @t+0 of 0 slides out of window.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(HOURS.toMillis(1) - SECONDS.toMillis(39));
            prophet.incrementTime(SECONDS.toMillis(1));
        }
        then:
        {   // t+20 Agg P/L = +200 (HIGH)
            // t+40 Agg P/L = +100 (LOW)
            // LOSS = 100 => BREACHED

            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio, BREACHED, -100, 0, 100, 200, -99));
        }
    }

    @Test
    public void shouldTriggerMinHourAndDayTogether() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -499.99, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_HOUR, -499.99, true),
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_DAY, -499.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.9509));
            prophet.clearOutputBuffer();
        }
        when:
        // t+0 seed 0 pnl after 30sec
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 5_000_000, 0.9509));
            prophet.incrementTime(30 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio));
        }
        when:
        // t+30, first trade is breached.
        {
            // pnl of -500
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDUSD, 5_000_000, 0.9510));
        }
        then:
        // breached per min
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -500, -500, -500, 0, -499.99));
        }
        and:
        // breached per hour
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio, BREACHED, -500, -500, -500, 0, -499.99));
        }
        and:
        // breached per day
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_DAY, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_DAY, portfolio, BREACHED, -500, -500, -500, 0, -499.99));
        }
        when:
        // t+90, not breached on per min.
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(60 * 1_000);
        }
        then:
        // breached per min is reset
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, NOT_BREACHED, NaN, 0, -500.00, -500.00, -499.99));
        }
        and:
        // breached per hour remains
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_HOUR, portfolio));
        }
        and:
        // breached per day remains
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_DAY, portfolio));
        }
    }

    @Test
    public void shouldSendBreachedStatusForDirectPair() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -100, true)
            )));
        }
        firewallBreached();
    }

    public void firewallBreached() {
        when:
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, 100.920));
            prophet.receive(tdd.hedge_trade_001(portfolio, USDJPY, 1_000_000, 100.920));
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // reval 30sec later to seed pnl 0 in buffer
        {
            prophet.incrementTime(30 * 1_000);
        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            // Mid movement must cause PNL change by AT LEAST 10USD, else will be ignored
            prophet.receive(tdd.marketDataSnapshot(CNX, USDJPY, 100.918));
            prophet.receive(tdd.hedge_trade_001(portfolio, USDJPY, 1_000_000, 100.930));
        }
        then:
        {
            // pnl = -1_000_000 * 100.93 / (100.918) + 1_000_000 = -118.9084
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -118.91, -118.91, -118.91, 0, -100));
        }
    }

    @Test
    public void shouldResetViaManualResetFacility() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -100, true)
            )));
        }
        firewallBreached();
        when:
        // firewall reset
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.createHedgerFirewallReset(portfolio, AGGREGATED_PNL_LOSS_PER_MIN));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }
        firewallBreached();
    }

    @Test
    public void shouldResetWhenHedgerTurnedOn() {
        setup:
        {
            prophet.receive(tdd.configuration_hedging_001()
                    .setAggressiveTwapHedgerConfigs(Arrays.asList(
                        new AggressiveTwapHedgerConfigImpl(AXL, Instrument.AUDUSD).setMaximumSpread(0.00002).setMinimumQuantity(500_000L).setMinimumRisk(1_250_000).setOrderRateLimit(2_000_000).setOrderRateTimePeriodMS(3_000)
                    ))
                    .setHedgeFirewallConfigs(asList(
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, HedgeFirewallType.SUSPICIOUS_DISCREPANCY, NaN, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ORDER_SENT_PER_MIN, POSITIVE_INFINITY, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER, POSITIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_ACTIVE_ORDER_PER_INSTRUMENT, POSITIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, MAXIMUM_TRADE_VOLUME_PER_HOUR, POSITIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_MIN, -100, true),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, AGGREGATED_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),

                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_MIN, NEGATIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_HOUR, NEGATIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_LOSS_PER_DAY, NEGATIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REVAL_PNL_PROFIT_PER_DAY, POSITIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, REALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false),
                            new HedgeFirewallConfigImpl(HEDGER_AGGRESSIVE, GB, UNREALISED_POSITION_PER_30_SEC, POSITIVE_INFINITY, false)
                    ))
            );
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }

        firewallBreachedUsingHedger();

        when:
        // firewall reset when Hedger is TURNED ON
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.enableHedger(HEDGER_AGGRESSIVE));
        }
        then:
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status.getStatus(), Matchers.is(NOT_BREACHED));
            assertThat(status.getDescription().toString(), Matchers.is(HedgeFirewallStatusImpl.FIREWALL_RESET));
        }

        firewallBreachedUsingHedger();
    }

    public void firewallBreachedUsingHedger() {
        double maxSpread = 0.00002;
        double sellHedgeOrderPrice = 0.74998 - maxSpread;
        NewOrder newOrder;

        when:
        // t+0 hedger places out SELL 2mio order
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshotWithBidOffer(AXL, AUDUSD, 0.74996, 0.74998, now()));
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.74997));
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        and:
        // t+3 after order rate time period
        {
            prophet.incrementTime(3_000);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getPrice(), is(sellHedgeOrderPrice));
            assertThat(newOrder.getQuantity(), is(2000000d));
        }
        when:
        // Hedge order filled
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.74996);
        }
        then:
        // pnl = (2_000_000 * 0.74996) - (2_000_000 * 0.74997)  = -20  => NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // 30sec later pnl reval occurs and is pnl is locked in
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(30_000);
            prophet.receive(tdd.client_trade_001(AUDUSD, 2_000_000, 0.75000));
        }
        and:
        // t+33 i.e order rate time period expired
        {
            prophet.incrementTime(3_000);
        }
        then:
        {
            newOrder = prophet.expect(NewOrder.class, exactly(1)).getLast();
            assertThat(newOrder.getPrice(), is(sellHedgeOrderPrice));
            assertThat(newOrder.getQuantity(), is(2000000d));
        }
        when:
        // Hedge order filled
        {
            prophet.clearOutputBuffer();
            prophet.receive(tdd.hedgeOrderConfirmed(newOrder));
            prophet.receiveHedgeOrderFullFill(newOrder, 0.74996);
        }
        then:
        // reval pnl -20
        // instantaneous pnl = (2_000_000 * 0.74996) - (2_000_000 * 0.74997)  = -20  => TOTAL -40 NOT BREACHED
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(1 * 1_000);
            // Mid movement must cause PNL change by AT LEAST 10USD, else will be ignored
            prophet.receive(tdd.marketDataSnapshot(CNX, AUDUSD, 0.75002));
        }
        then:
        // reval pnl -20
        // pnl = (2_000_000 * 0.74996) - (2_000_000 * 0.75002)  = -120 => TOTAL -140 BREACHED
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -120.0, -140.0, -140, -20, -100));
        }
    }

    @Test
    public void shouldSendBreachedStatusForCrossPair() {
        final Instrument crosspair = AUDJPY;
        final Instrument driverPairA = Instrument.AUDUSD;
        final Instrument driverpairB = Instrument.USDJPY;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -99.99, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.74500));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 113.700));
        }
        when:
        // t+0, receive hedge trade 1
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, crosspair, 1_000_000, 84.700));
            // AUD: +1mio AUD     | +0.74500mio USD
            // JPY: -84.7mio JPY  | -84.7/113.7 mio USD
            // PnL = 57.17
        }
        then:
        // pnl 57.17 => not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }

        when:
        // t+5, new mid rate on AUD/USD
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 0.74490));
            // AUD: +1mio AUD     | +0.74490mio USD
            // JPY: -84.7mio JPY  | -84.7/113.7 mio USD
            // PnL = -42.83201407
        }
        then:
        {
            // breached
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, exactly(1), isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -100.00, -42.83, -42.83, 57.17, -99.99));
        }
    }

    // TODO: When triangulating USD/SEK, we should be using EUR/SEK fill rate and NOT the market mid
    @Test
    public void shouldSendBreachedStatusForCrossPairEUR() {

        final Instrument driverPairA = EURUSD;
        final Instrument driverpairB = EURSEK;

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -100, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(driverPairA, 1.07185));
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 9.78435));
        }
        when:
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, -1_000_000, 9.78400));
            // EUR: -1mio EUR       | -1.07185mio USD
            // SEK: -9.784mio SEK   | +9.784mio * (1.07185/9.78435) mio USD
            // PnL = -38.34
        }
        then:
        // pnl -38.34 => not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        // t+30, pnl cystalised
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(30 * 1_000);

        }
        then:
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio));
        }

        when:
        // t+61, mid rate updated for EURSEK. And Receive hedge trade 2
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(31 * 1_000);
            prophet.receive(tdd.marketDataSnapshot(driverpairB, 9.78492));
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, -1_000_000, 9.78400));
            // EUR: -1mio EUR       | -1.07185mio USD
            // SEK: -9.784mio SEK   | +9.784mio * (1.07185/9.78481) mio USD
            // PnL = -100.7777274
            // Aggregated PnL = -38.34 + (-100.78) = -139.12
        }
        then:
        // breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -100.78, -139.12, -139.12, -38.34, -100));
        }
    }

    @Test
    public void pnlCalculationMultiPairs() {

        setup:
        {
            prophet.receive(tdd.configuration_hedging_001().setHedgeFirewallConfigs(asList(
                    new HedgeFirewallConfigImpl(portfolio, GB, AGGREGATED_PNL_LOSS_PER_MIN, -58.00, true)
            )));
            prophet.receive(tdd.marketDataSnapshot(EURUSD, 1.07185));
            prophet.receive(tdd.marketDataSnapshot(EURSEK, 9.78435));
            prophet.receive(tdd.marketDataSnapshot(AUDUSD, 0.74500));
            prophet.receive(tdd.marketDataSnapshot(USDJPY, 113.700));
            prophet.clearOutputBuffer();
        }
        when:
        // t+0, receive hedge trade 1
        {
            prophet.receive(tdd.hedge_trade_001(portfolio, AUDJPY, 1_000_000, 84.700));
            // AUD: +1mio AUD     | +0.74500mio USD
            // JPY: -84.7mio JPY  | -84.7/113.7 mio USD
            // PnL = 57.17
        }
        then:
        // pnl 57.17 => not breached
        {
            prophet.notExpect(HedgeFirewallStatus.class, isHedgeFirewallStatus(AGGREGATED_PNL_LOSS_PER_MIN, BREACHED, portfolio));
        }
        when:
        {
            prophet.clearOutputBuffer();
            prophet.incrementTime(5 * 1_000);
            prophet.receive(tdd.hedge_trade_001(portfolio, EURSEK, -1_000_000, 9.78382));
            // EUR: -1mio EUR       | -1.07185mio USD
            // SEK: +9.78382mio SEK   | +9.78382mio * (1.07185/9.78435) mio USD
            // PnL = -58.06
            // Total PnL = 57.17 + (-58.06) = -0.89
        }
        then:
        // breached
        {
            final HedgeFirewallStatus status = prophet.expect(HedgeFirewallStatus.class, isHedgeFirewallType(AGGREGATED_PNL_LOSS_PER_MIN, portfolio)).getFirst();
            assertThat(status, isHedgeFirewallPnlStatus(AGGREGATED_PNL_LOSS_PER_MIN, portfolio, BREACHED, -58.06, -0.89, -0.89, 57.17, -58.00));
        }
    }
}
