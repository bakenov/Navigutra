package com.anz.markets.prophet.chronicle.config;

import com.anz.markets.prophet.domain.chronicle.Header;

public enum StartAt {
    START {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.firstIndex();
        }
    },
    END {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.lastIndex();
        }
    },
    INDEX {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.configIndex();
        }
    },
    EVENTID {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.findIndex(Header::getEventId, true);
        }
    },
    EVENTID_CLOSEST {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.findIndex(Header::getEventId, false);
        }
    },
    CORE_RX_TIMESTAMP_CLOSEST {
        @Override
        public void moveToStartIndex(final StartAtSeeker seeker) {
            seeker.findIndex(Header::getStartTimeStampNS, false);
        }
    };

    public abstract void moveToStartIndex(final StartAtSeeker seeker);
}
