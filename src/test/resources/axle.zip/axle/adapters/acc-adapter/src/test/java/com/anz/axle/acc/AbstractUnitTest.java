package com.anz.axle.acc;

import com.anz.axle.util.MockLoggingAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.After;
import org.junit.Before;


/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
public abstract class AbstractUnitTest {
    protected Mockery context;
    private Level originalLevel = Logger.getRootLogger().getLevel();
    protected MockLoggingAppender mockLogAppender;

    @Before
    public void alwaysBeforeEach() {
        context = new Mockery() {
            {
                setImposteriser(ClassImposteriser.INSTANCE);
            }
        };
        mockLogAppender = new MockLoggingAppender();
        Logger.getLogger("com.anz.axle.acc").addAppender(mockLogAppender);
    }

    @After
    public void alwaysAfterEach() {
        context.assertIsSatisfied();
    }

    public void checking(Expectations e) {
        context.checking(e);
    }

    public <E> E mock(Class<E> clazz) {
        return context.mock(clazz);
    }

    public <E> E mock(Class<E> clazz, String name) {
        return context.mock(clazz, name);
    }
}
