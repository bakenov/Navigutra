package com.anz.markets.prophet.config.business.domain.indexed;

import com.anz.markets.prophet.config.business.domain.tabular.impl.PriceSpikeFirewallConfig;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.efx.ngaro.collections.EnumObjMap;

import java.util.ArrayList;
import java.util.List;

public class PriceSpikeFirewallConfigs {
    public final EnumObjMap<Instrument, List<PriceSpikeFirewallConfig>> map = new EnumObjMap<>(Instrument.class);

    public PriceSpikeFirewallConfigs(final List<PriceSpikeFirewallConfig> priceSpikeFirewallConfigs) {
        priceSpikeFirewallConfigs.forEach(priceSpikeFirewallConfig -> {
            map.computeIfAbsent(priceSpikeFirewallConfig.instrument, instrument -> new ArrayList<>()).add(priceSpikeFirewallConfig);
        });
        // put these in order of min(threshold ratios)
        map.forEach((instrument, list) -> {
            list.sort((o1, o2) -> Double.compare(
                    Math.min(o1.globalIndicativeDeviationThresholdRatio, o1.instrumentOnlyIndicativeDeviationThresholdRatio),
                    Math.min(o2.globalIndicativeDeviationThresholdRatio, o2.instrumentOnlyIndicativeDeviationThresholdRatio))
            );
        });
    }
}
