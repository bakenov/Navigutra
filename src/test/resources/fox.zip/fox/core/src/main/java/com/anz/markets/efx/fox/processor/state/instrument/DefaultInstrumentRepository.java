package com.anz.markets.efx.fox.processor.state.instrument;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.agrona.collections.Long2ObjectHashMap;
import org.agrona.collections.Object2ObjectHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.codec.api.InstrumentConfigDecoder;
import com.anz.markets.efx.ngaro.api.InstrumentKey;

public class DefaultInstrumentRepository implements InstrumentRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(DefaultInstrumentRepository.class);

    private final Map<String, List<String>> crossSymbolToDrivingSymbols;
    private final Map<String, List<String>> drivingSymbolToCrosses;

    private final Long2ObjectHashMap<DefaultInstrument> instruments = new Long2ObjectHashMap<>();

    public DefaultInstrumentRepository(final Map<String, List<String>> crossSymbolToDrivingSymbols) {
        this.crossSymbolToDrivingSymbols = Objects.requireNonNull(crossSymbolToDrivingSymbols);
        this.drivingSymbolToCrosses = new Object2ObjectHashMap<>();

        crossSymbolToDrivingSymbols.forEach((crossSymbol, drivingSymbols) -> {
            drivingSymbols.forEach(drivingSymbol -> drivingSymbolToCrosses.computeIfAbsent(drivingSymbol, symbol -> new ArrayList<>()).add(crossSymbol));
        });
    }

    @Override
    public Instrument lookup(final long instrumentId) {
        return instruments.get(instrumentId);
    }

    @Override
    public Instrument apply(final InstrumentConfigDecoder instrumentConfigDecoder) {
        final InstrumentConfigDecoder.Body body = instrumentConfigDecoder.body();
        final long instrumentId = body.instrumentId();
        final DefaultInstrument foundInstrument = instruments.get(instrumentId);
        if (foundInstrument == null) {
            final InstrumentKey instrumentKey = InstrumentKey.of(instrumentId);
            final DefaultInstrument instrument = new DefaultInstrument(instrumentKey, body.pipSizeDivisor(), body.enabled());
            instruments.put(instrumentId, instrument);
            addToDrivenInstruments(instrument);
            addDrivingInstruments(instrument);

            //LOGGER.info("Created {}", instrument);

            return instrument;
        } else {
            foundInstrument
                    .pipSizeDivisor(body.pipSizeDivisor())
                    .enabled(body.enabled());

            //LOGGER.info("Updated {}", foundInstrument);
            return foundInstrument;
        }
    }

    private void addToDrivenInstruments(final Instrument instrument) {
        final List<String> crosses = drivingSymbolToCrosses.get(instrument.key().symbol());
        if (crosses != null) {
            for (int i = 0; i < crosses.size(); i++) {
                final String cross = crosses.get(i);
                final long crossInstrumentId = InstrumentKey.instrumentId(cross, instrument.key().securityType(), instrument.key().tenor());
                final Instrument crossInstrument = instruments.get(crossInstrumentId);
                if (crossInstrument != null) {
                    crossInstrument.addDrivingInstrument(instrument);
                }
            }
        }
    }

    private void addDrivingInstruments(final Instrument instrument) {
        final List<String> drivingSymbols = crossSymbolToDrivingSymbols.get(instrument.key().symbol());
        if (drivingSymbols != null) {
            for (int i = 0; i < drivingSymbols.size(); i++) {
                final String drivingSymbol = drivingSymbols.get(i);
                final long drivingInstrumentId = InstrumentKey.instrumentId(drivingSymbol, instrument.key().securityType(), instrument.key().tenor());
                final Instrument drivingInstrument = instruments.get(drivingInstrumentId);
                if (drivingInstrument != null) {
                    instrument.addDrivingInstrument(drivingInstrument);
                }
            }
        }
    }

}
