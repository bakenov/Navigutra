package com.anz.axle.lg.adapter.citi.quickfix;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import quickfix.Message;
import quickfix.field.QuoteType;

import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.adapter.fix.SubscriptionManager;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.util.FixedSourceSequencer;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.codec.StringToIntAsciiCache;
import com.anz.markets.efx.ngaro.codec.StringToIntCache;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;
import com.anz.markets.efx.ngaro.core.ObjectPool;
import com.anz.markets.efx.pricing.codec.snapshot.state.VenueRequestKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.axle.lg.util.FormattedTimeParser;
import com.anz.axle.lg.util.test.FixMessageFactory;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.api.PricingEncoderSupplier;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshEncoder;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.pricing.codec.pojo.test.MockitoPricingEncoder;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CitiMassQuoteHandlerTest {
    private static final String SENDER_COMP_ID = "GB:CITI";
    private static final String COMP_ID = "GB:lg-citi";
    private static final FormattedTimeParser FORMATTED_TIME_PARSER = new FormattedTimeParser();
    private static final long CURRENT_TIME = 34523453;
    private static final long MSG_SEQ_NUM = 4319;
    private static final String MSG_SEQ_NUM_STRING = "4319";
    private static final String SENDING_TIME_STRING = "20161129-06:23:35.982";
    private static final long SENDING_TIME_NANOS = FORMATTED_TIME_PARSER.parseNanos(SENDING_TIME_STRING);
    private static final String SYMBOL = "CAD/CHF";
    private static final String NORMALISED_SYMBOL = "CADCHF";
    private static final String CURRENCY = "CAD";
    private static final SecurityType SECURITY_TYPE = SecurityType.FXSPOT;
    private static final InstrumentKey INSTRUMENT_KEY = InstrumentKey.of(NORMALISED_SYMBOL, SECURITY_TYPE, Tenor.SP);
    private static final String QUOTE_REQ_ID = "1234567";
    private static final int QUOTE_REQ_ID_INT = Integer.parseInt(QUOTE_REQ_ID);
    private static final long SUBSCRIPTION_ID = Long.parseLong(QUOTE_REQ_ID);
    private static final int QUOTE_ID_LEN = 45;
    private MockitoPricingEncoder encoders = new MockitoPricingEncoder();
    private FixMessageFactory messageFactory;
    private VenueRequestKeyLookup requestKeyLookup = mock(VenueRequestKeyLookup.class);
    private PricingEncoderSupplier encoderSupplier = mock(PricingEncoderSupplier.class);
    private PricingEncoderLookup pricingEncoderLookup = mock(PricingEncoderLookup.class);
    private PrecisionClock precisionClock = mock(PrecisionClock.class);
    private SubscriptionManager subscriptionManager = mock(SubscriptionManager.class);
    private MarketDataSubscription marketDataSubscription = mock(MarketDataSubscription.class);
    private ObjectPool<MutableAsciiString> asciiStringPool = new ObjectPool<>(mutableAsciiStringConsumer -> new FixedLengthAsciiString(QUOTE_ID_LEN), 100);
    private AtomicInteger mdEntryIdValue = new AtomicInteger(0);
    private StringToIntCache mdEntryIdCache = new StringToIntAsciiCache(asciiStringPool, QUOTE_ID_LEN, mdEntryIdValue::incrementAndGet, 100000, 8);
    private SourceSequencer sourceSequencer = new FixedSourceSequencer(23,50L);

    @Mock
    private Consumer<EnumerableSetEncoder<SnapshotFullRefreshEncoder.Body, Flag>> flagsAppender;
    private CitiMassQuoteHandler citiMassQuoteHandler;
    private InOrder inOrder;

    @Before
    public void setUp() throws Exception {
        citiMassQuoteHandler = new CitiMassQuoteHandler(requestKeyLookup, pricingEncoderLookup, precisionClock, subscriptionManager, SENDER_COMP_ID, COMP_ID, flagsAppender, sourceSequencer);
        messageFactory = new FixMessageFactory("/conf/FIX44-citi.xml");
        when(encoderSupplier.snapshotFullRefresh()).thenReturn(encoders.snapshotEncoder);
        when(pricingEncoderLookup.lookup(any())).thenReturn(encoderSupplier);
        inOrder = inOrder(
                encoders.pricingEncoders,
                encoders.snapshotEncoder,
                encoders.snapshotEncoder.messageStart(sourceSequencer.sourceId(), sourceSequencer.nextSequence()),
                encoders.snapshotBody.senderCompId(),
                encoders.snapshotBody.referenceSpotDate(),
                encoders.snapshotBody.tradeDate(),
                encoders.snapshotBody.settlDate(),
                encoders.snapshotBody.mdFlags(),
                encoders.snapshotEntries_next,
                encoders.snapshotEntries_body,
                encoders.snapshotEntries_body.mdEntryFlags(),
                encoders.snapshotHops,
                encoders.snapshotHops_next,
                encoders.snapshotHops_body,
                encoders.snapshotHops_body.hopCompId(),
                encoders.messageEncoder);

        when(requestKeyLookup.lookup(INSTRUMENT_KEY)).thenReturn(RequestKey.of(Venue.CITI, INSTRUMENT_KEY));
        when(precisionClock.nanos()).thenReturn(CURRENT_TIME);
        when(subscriptionManager.lookupByRequestId(QUOTE_REQ_ID_INT)).thenReturn(marketDataSubscription);
        when(marketDataSubscription.id()).thenReturn(SUBSCRIPTION_ID);
        when(marketDataSubscription.symbol()).thenReturn(SYMBOL);
        when(marketDataSubscription.instrumentKey()).thenReturn(INSTRUMENT_KEY);
        when(marketDataSubscription.stringToIntCache()).thenReturn(mdEntryIdCache);
    }

    @Test
    public void shouldProcessMassQuoteWithOneEntry() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "i",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CITI_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CITI_MD_S",
                "117=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p",
                "537=", "2",
                "131=", QUOTE_REQ_ID,
                "296=", "1",
                "302=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p--aalYp5xe1.hTn6p",
                "304=", "1",
                "295=", "1",
                "299=","683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0",
                "55=", NORMALISED_SYMBOL,
                "15=", CURRENCY,
                "60=", "20171208-06:16:03.555",
                "64=", "20171212",
                "134=", "6400000.00",
                "135=", "1400000.00",
                "188=", "0.77439",
                "190=", "0.7749",
                "132=", "0.77439",
                "133=", "0.77491",
                "10=", "160");
        //when
        citiMassQuoteHandler.accept(snapshotMessage);

        //then
        verifySnapshot(2, true);
        verifyEntry(EntryType.BID,   0.77439, 6400000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntry(EntryType.OFFER, 0.77491, 1400000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntriesComplete();
        verifyHops();
    }

    @Test
    public void shouldProcessMassQuoteWithMultipleEntries() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "i",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CITI_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CITI_MD_S",
                "117=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p",
                "537=", "2",// QuoteType=TRABEABLE
                "131=", QUOTE_REQ_ID,
                "296=", "1",
                "302=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p--aalYp5xe1.hTn6p",
                "304=", "1",
                "295=", "3",
                "299=","683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0",
                "55=", NORMALISED_SYMBOL,
                "15=", CURRENCY,
                "60=", "20171208-06:16:03.555",
                "64=", "20171212",
                "134=", "1100000.00",
                "135=", "7700000.00",
                "188=", "0.77411",
                "190=", "0.77477",
                "132=", "0.77411",
                "133=", "0.77477",
                "299=","683174913##12CADCHF-1S--aalYp5xe1.hTn6p--1",
                "55=", NORMALISED_SYMBOL,
                "15=", CURRENCY,
                "60=", "20171208-06:16:03.555",
                "64=", "20171212",
                "134=", "2200000.00",
                "135=", "6600000.00",
                "188=", "0.77422",
                "190=", "0.77466",
                "132=", "0.77422",
                "133=", "0.77466",
                "299=","683174913##12CADCHF-1S--aalYp5xe1.hTn6p--2",
                "55=", NORMALISED_SYMBOL,
                "15=", CURRENCY,
                "60=", "20171208-06:16:03.555",
                "64=", "20171212",
                "134=", "3300000.00",
                "135=", "5500000.00",
                "188=", "0.77433",
                "190=", "0.77455",
                "132=", "0.77433",
                "133=", "0.77455",
                "10=", "203");
        //when
        citiMassQuoteHandler.accept(snapshotMessage);

        //then
        verifySnapshot(6, true);
        verifyEntry(EntryType.BID,   0.77411, 1100000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntry(EntryType.OFFER, 0.77477, 7700000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntry(EntryType.BID,   0.77422, 2200000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--1"));
        verifyEntry(EntryType.OFFER, 0.77466, 6600000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--1"));
        verifyEntry(EntryType.BID,   0.77433, 3300000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--2"));
        verifyEntry(EntryType.OFFER, 0.77455, 5500000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--2"));
        verifyEntriesComplete();
        verifyHops();
    }


    @Test
    public void shouldProcessMassQuoteIndicativeFlag() throws Exception {
        final Message snapshotMessage = messageFactory.msg(
                "8=", "FIX.4.4",
                "9=", "179",
                "35=", "i",
                "34=", MSG_SEQ_NUM_STRING,
                "49=", "GB_CITI_MD_T",
                "52=", SENDING_TIME_STRING,
                "56=", "GB_CITI_MD_S",
                "117=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p",
                "537=", Integer.toString(QuoteType.INDICATIVE),
                "131=", QUOTE_REQ_ID,
                "296=", "1",
                "302=", "683174913##12CADCHF-1S--aalYp5xe1.hTn6p--aalYp5xe1.hTn6p",
                "304=", "1",
                "295=", "1",
                "299=","683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0",
                "55=", NORMALISED_SYMBOL,
                "15=", CURRENCY,
                "60=", "20171208-06:16:03.555",
                "64=", "20171212",
                "134=", "6400000.00",
                "135=", "1400000.00",
                "188=", "0.77439",
                "190=", "0.7749",
                "132=", "0.77439",
                "133=", "0.77491",
                "10=", "158");
        //when
        citiMassQuoteHandler.accept(snapshotMessage);

        //then
        verifySnapshot(2, false);
        verifyEntry(EntryType.BID,   0.77439, 6400000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntry(EntryType.OFFER, 0.77491, 1400000.00, mdEntryIdCache.put("683174913##12CADCHF-1S--aalYp5xe1.hTn6p--0"));
        verifyEntriesComplete();
        verifyHops();
    }

    private void verifySnapshot(final int entriesCount,
                                final boolean tradeable) {
        if (!tradeable) {
            inOrder.verify(encoders.snapshotBody.mdFlags()).add(Flag.INDICATIVE);
        }
        inOrder.verify(encoders.snapshotBody).marketId(Venue.CITI);
        inOrder.verify(encoders.snapshotBody).instrumentId(INSTRUMENT_KEY.instrumentId());

        inOrder.verify(encoders.snapshotBody.senderCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotBody).messageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotBody).sendingTime(SENDING_TIME_NANOS);
        if (entriesCount == 0) {
            inOrder.verify(encoders.snapshotBody).entriesEmpty();
        } else {
            inOrder.verify(encoders.snapshotBody).entriesStart(entriesCount);
        }
    }


    private void verifyEntry(final EntryType side,
                             final double price,
                             final double quantity,
                             final int entryId) {
        inOrder.verify(encoders.snapshotEntries_body).mdMkt(Venue.CITI);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryType(side);
        inOrder.verify(encoders.snapshotEntries_body).mdEntrySize(quantity);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryPx(price);
        inOrder.verify(encoders.snapshotEntries_body).mdEntryId(entryId);
        inOrder.verify(encoders.snapshotEntries_body).quoteEntryId(entryId);
    }

    private void verifyEntriesComplete() {
        inOrder.verify(encoders.snapshotEntries_next).entriesComplete();
    }

    private void verifyHops() {
        inOrder.verify(encoders.snapshotHops).hopsStart(2);
        inOrder.verify(encoders.snapshotHops_next).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(SENDER_COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(SENDING_TIME_NANOS);
        inOrder.verify(encoders.snapshotHops_body).next();
        inOrder.verify(encoders.snapshotHops_body.hopCompId()).encode(COMP_ID);
        inOrder.verify(encoders.snapshotHops_body).hopMessageId(MSG_SEQ_NUM);
        inOrder.verify(encoders.snapshotHops_body).hopReceivingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopSendingTime(CURRENT_TIME);
        inOrder.verify(encoders.snapshotHops_body).hopsComplete();
        inOrder.verify(encoders.messageEncoder).messageComplete();
    }
}