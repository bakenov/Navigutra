package chroniclefix.poc;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import software.chronicle.fix.cfg.ConnectionType;

import com.anz.axle.lg.adapter.fast.chroniclefix.generated.parsers.MessageParser;

public class Playback {
    private static Logger LOG = LoggerFactory.getLogger(Playback.class);

    public static void main(String[] args) throws Exception {
        String hostPort = args[0];
        String senderCompID = args[1];
        String targetCompID = args[2];
        ConnectionType connectionType = ConnectionType.valueOf(args[3]);
        String cqDir = args[4];

        // TODO: control rate
        MessageParser messageParser = new MessageParser();
        TimeUnit internalTimeUnit = messageParser.coreFieldParser().internalTimeUnit();
//        FixSessionContext sessionContext = new DynamicTimestampResolutionFixSessionContext(SystemTimeProvider.INSTANCE, internalTimeUnit, internalTimeUnit);
        software.chronicle.fix.tools.PlaybackTCP playback = new software.chronicle.fix.tools.PlaybackTCP(hostPort, senderCompID, targetCompID, connectionType);
        playback.playBack(cqDir);
    }
}
