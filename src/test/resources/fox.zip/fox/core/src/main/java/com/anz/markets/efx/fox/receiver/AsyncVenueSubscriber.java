package com.anz.markets.efx.fox.receiver;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.queue.Queue;

public class AsyncVenueSubscriber implements VenueSubscriber.Async {
    private final Queue<Runnable> runnableQueue;
    private final Map<Venue, Runnable> runnableMap;

    public AsyncVenueSubscriber(final Queue<Runnable> runnableQueue,
                                final VenueSubscriber venueSubscriber) {
        this.runnableQueue = Objects.requireNonNull(runnableQueue);
        Objects.requireNonNull(venueSubscriber);

        runnableMap = new HashMap<>();
        Arrays.stream(Venue.values()).forEach(venue -> runnableMap.put(venue, () -> venueSubscriber.subscribe(venue)));
    }

    @Override
    public void subscribe(final Venue venue) {
        runnableQueue.appender().enqueue(runnableMap.get(venue));
    }
}
