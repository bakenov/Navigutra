package com.anz.axle.adapters.ndf2trep.config;


import com.anz.axle.applicationboot.EnvironmentResolver;
import com.anz.axle.spring.config.NestedPropertiesFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;
import java.util.Properties;

@Configuration
public class PropertiesConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(PropertiesConfig.class);

    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer(@Qualifier("applicationProperties") final Properties properties) {
        final PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        propertySourcesPlaceholderConfigurer.setProperties(properties);

        properties.forEach((key, value) -> LOGGER.info("{} = {}", key, value));

        return propertySourcesPlaceholderConfigurer;
    }

    @Bean
    public NestedPropertiesFactoryBean applicationProperties() throws IOException {
        final NestedPropertiesFactoryBean propertiesFactoryBean = new NestedPropertiesFactoryBean();
        propertiesFactoryBean.setIgnoreResourceNotFound(true);
        propertiesFactoryBean.setEnv(EnvironmentResolver.environment());
        propertiesFactoryBean.setLocations(new String[]{
                "file:${user.home}/axle/etc/axle-host-environment.properties",
                "file:${user.home}/axle/etc/axle-${master.${env}.environment}.properties",
                "file:${user.home}/axle/etc/axle-${env}.properties",
                "classpath:conf/ndf2trep-default.properties", //common config for all instances and all environments
                "classpath:conf/ndf2trep-${env}.properties",
                "classpath:conf/ndf2trep-${instance}-default.properties", //common config for specific instance for all environments
                "classpath:conf/ndf2trep-${instance}-${env}.properties", //environment and instance specific config
                "file:${user.home}/axle/etc/axle.properties"
        });
        return propertiesFactoryBean;
    }
}
