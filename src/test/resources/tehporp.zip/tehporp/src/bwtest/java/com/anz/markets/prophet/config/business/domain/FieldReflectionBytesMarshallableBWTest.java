package com.anz.markets.prophet.config.business.domain;

import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.google.common.collect.Lists;
import net.openhft.lang.io.ByteBufferBytes;
import net.openhft.lang.io.IByteBufferBytes;
import org.junit.Test;
import org.octtech.bw.ByteWatcherRegressionTestHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;

public class FieldReflectionBytesMarshallableBWTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(FieldReflectionBytesMarshallableBWTest.class);
    private static final int REPS = 100_000;
    private static final int THRESHOLD = 39112; // caused by reflection and does not grow with reps.

    private final ByteWatcherRegressionTestHelper helper = new ByteWatcherRegressionTestHelper();
    private final FieldReflectionBytesMarshallableTest unitTest = new FieldReflectionBytesMarshallableTest();
    private final FieldReflectionBytesMarshallableTest.NotByteMarshallableFixture expected = new FieldReflectionBytesMarshallableTest.NotByteMarshallableFixture(true, Double.MAX_VALUE, Long.MAX_VALUE, Integer.MIN_VALUE, "a", Instrument.AUDCAD, Lists.newArrayList(Currency.AUD, Currency.USD), 2);
    private final FieldReflectionBytesMarshallableTest.NotByteMarshallableFixture actualHolder = new FieldReflectionBytesMarshallableTest.NotByteMarshallableFixture();


    private IByteBufferBytes byteBuffer = ByteBufferBytes.wrap(ByteBuffer.allocate(1000));


    public FieldReflectionBytesMarshallableBWTest() {
        warmUp();
    }

    public void test() {
        unitTest.writeAndReadAndAssert(expected, actualHolder, byteBuffer);

    }

    public void warmUp() {
        for (int i = 0; i < REPS; i++) {
            test();
        }
    }

    @Test
    public void test__Allocation() {
        helper.testAllocationNotExceeded(
                this::test,
                THRESHOLD // no allocation!
        );
    }
}
