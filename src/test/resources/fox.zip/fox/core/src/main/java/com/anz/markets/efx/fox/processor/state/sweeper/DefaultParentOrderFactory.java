package com.anz.markets.efx.fox.processor.state.sweeper;

import java.util.Objects;

import com.anz.markets.efx.fox.api.domain.InstrumentRepository;
import com.anz.markets.efx.fox.api.domain.ParentOrder;
import com.anz.markets.efx.fox.api.domain.ParentOrderRepository;
import com.anz.markets.efx.fox.processor.state.ParentOrderFactory;
import com.anz.markets.efx.ngaro.core.ObjectPool;

public class DefaultParentOrderFactory implements ParentOrderFactory.NamedFactory {
    private final String strategyName;
    private final ObjectPool<DefaultParentOrder> parentOrderPool;

    public DefaultParentOrderFactory(final String strategyName,
                                     final ParentOrderRepository.Mutable parentOrderRepository,
                                     final int initialPoolSize,
                                     final InstrumentRepository instrumentRepository) {
        this.strategyName = Objects.requireNonNull(strategyName);
        Objects.requireNonNull(parentOrderRepository);
        Objects.requireNonNull(instrumentRepository);

        parentOrderPool = new ObjectPool<>(
                releaser -> new DefaultParentOrder(
                        releaser.andThen(parentOrder -> {
                            parentOrderRepository.removeByOrderId(parentOrder.details().orderId());
                            parentOrderRepository.removeByClOrderId(parentOrder.details().senderCompId(), parentOrder.details().origClOrdId());
                        }), instrumentRepository),
                initialPoolSize);

    }

    @Override
    public ParentOrder get() {
        return parentOrderPool.borrowOrNew();
    }

    @Override
    public String name() {
        return strategyName;
    }
}
