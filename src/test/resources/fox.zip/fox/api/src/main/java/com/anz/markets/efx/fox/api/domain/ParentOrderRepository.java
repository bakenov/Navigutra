package com.anz.markets.efx.fox.api.domain;

import java.util.function.Consumer;

import com.anz.markets.efx.fox.api.eventsourcing.EventContext;
import com.anz.markets.efx.trading.codec.api.ExecutionReportDecoder;

public interface ParentOrderRepository {
    ParentOrder lookupByOrderId(long orderId);
    ParentOrder lookupByClOrderId(String compId, long clOrdId);
    void forEach(Consumer<? super ParentOrder> consumer);

    interface Mutable extends ParentOrderRepository {
        void add(long orderId, ParentOrder parentOrder);
        void add(String compId, long clOrdId, ParentOrder parentOrder);
        void removeByOrderId(long orderId);
        void removeByClOrderId(String compId, long clOrdId);
    }

    interface WithInit extends ParentOrderRepository {
        ParentOrder init(final EventContext eventContext, ExecutionReportDecoder executionReportDecoder);
    }
}
