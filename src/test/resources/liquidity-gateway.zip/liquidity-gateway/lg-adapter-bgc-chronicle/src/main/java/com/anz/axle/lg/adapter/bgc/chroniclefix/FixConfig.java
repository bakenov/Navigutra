package com.anz.axle.lg.adapter.bgc.chroniclefix;

import com.anz.axle.lg.adapter.PriceRounder;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.ExecutionReport;
import com.anz.axle.lg.adapter.bgc.chroniclefix.generated.messages.OrderCancelReject;
import com.anz.axle.lg.adapter.chroniclefix.ApplicationLogonHandler;
import com.anz.axle.lg.adapter.chroniclefix.CheckLatencyProbes;
import com.anz.axle.lg.adapter.chroniclefix.ChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.EventLoopAdapter;
import com.anz.axle.lg.adapter.chroniclefix.FixEngine;
import com.anz.axle.lg.adapter.chroniclefix.FixMessageSender;
import com.anz.axle.lg.adapter.chroniclefix.FixSessionApplication;
import com.anz.axle.lg.adapter.chroniclefix.MonitoredChronicleMessageHandler;
import com.anz.axle.lg.adapter.chroniclefix.PerformanceProbes;
import com.anz.axle.lg.adapter.chroniclefix.tools.FixLogConsumer;
import com.anz.axle.lg.adapter.fix.LogonHandler;
import com.anz.axle.lg.adapter.fix.OptionMatcher;
import com.anz.axle.lg.adapter.fix.SessionState;
import com.anz.axle.lg.config.PricingEncoderLookup;
import com.anz.axle.lg.metric.Metric;
import com.anz.axle.lg.metric.MonitoredQueueMetric;
import com.anz.axle.lg.util.LongIdFactory;
import com.anz.axle.lg.util.SourceSequencer;
import com.anz.axle.microtime.PrecisionClock;
import com.anz.axle.spring.config.ConfiguredRuntimeResource;
import com.anz.markets.efx.eventloop.EventLoopStep;
import com.anz.markets.efx.metric.MetricRepository;
import com.anz.markets.efx.ngaro.api.DefaultInstrumentKeyLookup;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.SnapshotFullRefreshHandler;
import com.anz.markets.efx.queue.MonitoredQueue;
import com.anz.markets.efx.trading.codec.api.TradingEncoderSupplier;
import net.openhft.chronicle.core.threads.EventLoop;
import net.openhft.chronicle.queue.RollCycles;
import net.openhft.chronicle.threads.EventGroup;
import net.openhft.chronicle.threads.Pauser;
import net.openhft.chronicle.wire.Marshallable;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;
import software.chronicle.fix.cfg.FixEngineCfg;
import software.chronicle.fix.cfg.FixSessionCfg;
import software.chronicle.fix.staticcode.SessionID;
import software.chronicle.fix.staticcode.msgseq.SessionMessageProvider;
import software.chronicle.fix.staticcode.msgseq.fixlog.FixLog;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

@Configuration
public class FixConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixConfig.class);

    private final String compId;
    private final String senderCompId;

    public FixConfig(@Value("${messaging.compId}") final String compId,
                     @Value("${messaging.senderCompId}") final String senderCompId) {
        this.compId = Objects.requireNonNull(compId);
        this.senderCompId = Objects.requireNonNull(senderCompId);
    }

    @Bean
    public SessionID pricingSessionId(@Value("${bgc.fix.pricing.sendercompid}") final String pricingSenderCompId,
                                      @Value("${bgc.fix.pricing.targetcompid}") final String pricingTargetCompId) {
        return new SessionID(pricingSenderCompId, pricingTargetCompId);
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler() {

        final Logger LOGGER = LoggerFactory.getLogger(ApplicationLogonHandler.class);
        return new ApplicationLogonHandler() {
            @Override
            public void onLogon(final SessionID sessionId) {
                LOGGER.info("PricingPublishingSession has been logged on");
            }
            @Override
            public void onLogout(final SessionID sessionId) {
                LOGGER.info("PricingPublishingSession has been logged out");
            }
        };
    }

    @Bean
    public PricingEncoderLookup pricingEncoderLookup() {
        return PricingEncoderLookup.NO_OP;
    }

    @Bean
    public PriceRounder priceConverter(@Value("${rounding.decimal.place.default}") final int defaultDecimalPlaceToRound,
                                       @Value("#{${rounding.decimal.place.symbols}}") final Map<Integer, Set<String>> decimalPlaceToSymbols) {
        return new PriceRounder(decimalPlaceToSymbols, defaultDecimalPlaceToRound);
    }

    @Bean
    public EventLoop chroniclePricingEventLoop() {
        EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false, "pricing-");
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter fixPricingEventLoopStep(final EventLoop chroniclePricingEventLoop) {
        return new EventLoopAdapter(chroniclePricingEventLoop);
    }

    @Bean
    public EventLoopStep fixTradingEventLoopStep() {
        return EventLoopStep.NOOP;
    }

    @Bean
    public FixMessageSender fixPricingMessageSender(final SessionID pricingSessionId, @Lazy final FixEngine fixPricingEngine) {
        return new FixMessageSender(() ->
                fixPricingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(pricingSessionId)).findFirst().get());
    }

    @Bean
    public SnapshotFullRefreshHandler bgcSnapshotFullRefreshHandler(final FixMessageSender fixPricingMessageSender,
                                                                    final PriceRounder priceRounder) {
        return new BgcSnapshotFullRefreshHandler(priceRounder, new DefaultInstrumentKeyLookup(), fixPricingMessageSender);
    }

    @Bean
    public FixEngineCfg fixEngineCfg(final Properties applicationProperties) throws Exception {
        final ConfiguredRuntimeResource configuredRuntimeResource = new ConfiguredRuntimeResource();
        configuredRuntimeResource.setTemplate(new ClassPathResource("/conf/bgcc-chroniclefix.yaml"));
        configuredRuntimeResource.setConfiguration(applicationProperties);
        configuredRuntimeResource.afterPropertiesSet();
        LOGGER.info("Configuration : {}", configuredRuntimeResource);

        final String engineCfgStr = IOUtils.toString(configuredRuntimeResource.getInputStream(), StandardCharsets.UTF_8.name());
        final FixEngineCfg engineCfg = Marshallable.fromString(engineCfgStr);
        return engineCfg;
    }

    @Bean
    public Consumer<FixLog> pricingFixLogConsumer(@Value("${bgc.fix.pricing.log_all}") final boolean enableLogging,
                                                  @Value("${bgc.fix.file.log.path}") final String logPath,
                                                  @Value("${bgc.fix.pricing.logging.base_path}") final String bashPath,
                                                  @Value("${bgc.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath + bashPath, rollCycle);
    }

    @Bean
    public SessionMessageProvider pricingSessionMessageProvider(@Value("${bgc.fix.pricing.username}") final String userName,
                                                                @Value("${bgc.fix.pricing.password}") final String password,
                                                                @Value("${appOptions:}") final String appOptions,
                                                                final FixEngineCfg fixEngineCfg) {
        final FixSessionCfg pricingSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("pricing")).findFirst().get();
        return new BgcSessionMessageProvider("Pricing", userName, password, OptionMatcher.HAS_RESET.test(appOptions), pricingSessionCfg);
    }

    @Bean
    public FixEngine fixPricingEngine(final FixEngineCfg fixEngineCfg,
                                      final SessionMessageProvider pricingSessionMessageProvider,
                                      final Consumer<FixLog> pricingFixLogConsumer,
                                      final EventLoopAdapter fixPricingEventLoopStep,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      @Value("${bgc.fix.pricing.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      @Value("${bgc.fix.pricing.session.enable:true}") final boolean enablePricingSession) throws Exception {

        final FixSessionCfg pricingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("pricing")).findFirst().get();
        pricingSession.sessionMessageProvider(pricingSessionMessageProvider);

        final FixSessionApplication fixPricingApplication = new FixPricingApplication(applicationLogonHandler);
        pricingSession.messageNotifier(fixPricingApplication);

        pricingSession.consumer(pricingFixLogConsumer);

        return FixEngine.create("BGCMIDFX-QUOTE", fixEngineCfg.createInstance(pricingSession.hostId(), fixPricingEventLoopStep), waitForLogoutTimeoutInSec, enablePricingSession);
    }

    @Bean
    public SessionID tradingSessionId(@Value("${bgc.fix.trading.sendercompid}") final String tradingSenderCompId,
                                      @Value("${bgc.fix.trading.targetcompid}") final String tradingTargetCompId) {
        return new SessionID(tradingSenderCompId, tradingTargetCompId);
    }

    @Bean
    public SessionState tradingSessionState() {
        return new SessionState("TradingSession");
    }

    @Bean
    public ApplicationLogonHandler applicationLogonHandler(@Qualifier("tradingSessionState") final Supplier<LogonHandler> tradingSessionLogonHandlerSupplier) {

        return new ApplicationLogonHandler() {
            @Override
            public void onLogon(final SessionID sessionId) {
                tradingSessionLogonHandlerSupplier.get().onLogon();
            }

            @Override
            public void onLogout(final SessionID sessionId) {
                tradingSessionLogonHandlerSupplier.get().onLogout();
            }
        };
    }

    @Bean
    public FixMessageSender fixTradingMessageSender(final SessionID tradingSessionId, @Lazy final FixEngine fixTradingEngine) {
        return new FixMessageSender(() ->
                fixTradingEngine.getConnector().sessions().stream().filter(fixSessionHandler -> fixSessionHandler.sessionID().equals(tradingSessionId)).findFirst().get());
    }

    @Bean
    public EventLoop chronicleTradingEventLoop() {
        final EventGroup eventGroup = new EventGroup(true, Pauser.millis(100), false, "trading-");
        eventGroup.start();
        return eventGroup;
    }

    @Bean
    public EventLoopAdapter fixTradingEventLoopStep(final EventLoop chronicleTradingEventLoop) {
        return new EventLoopAdapter(chronicleTradingEventLoop);
    }

    @Bean
    public Consumer<FixLog> tradingFixLogConsumer(@Value("${bgc.fix.trading.log_all}") final boolean enableLogging,
                                                  @Value("${bgc.fix.file.log.path}") final String logPath,
                                                  @Value("${bgc.fix.trading.logging.base_path}") final String bashPath,
                                                  @Value("${bgc.fix.log.queue.RollCycle}") final RollCycles rollCycle) {
        return FixLogConsumer.create(enableLogging, logPath+bashPath, rollCycle);
    }

    @Bean
    public SessionMessageProvider tradingSessionMessageProvider(@Value("${bgc.fix.trading.username}") final String userName,
                                                                @Value("${bgc.fix.trading.password}") final String password,
                                                                @Value("${appOptions:}") final String appOptions,
                                                                final FixEngineCfg fixEngineCfg) {
        final FixSessionCfg tradingSessionCfg = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        return new BgcSessionMessageProvider("Trading", userName, password, OptionMatcher.HAS_RESET.test(appOptions), tradingSessionCfg);
    }

    @Bean
    public FixEngine fixTradingEngine(final FixEngineCfg fixEngineCfg,
                                      final ApplicationLogonHandler applicationLogonHandler,
                                      final SessionMessageProvider tradingSessionMessageProvider,
                                      final Consumer<FixLog> tradingFixLogConsumer,
                                      final PrecisionClock precisionClock,
                                      final TradingEncoderSupplier tradingEncoderSupplier,
                                      final LongIdFactory tradingMessageIdGenerator,
                                      final EventLoopAdapter fixTradingEventLoopStep,
                                      final MetricRepository<Metric, Venue> metricRepository,
                                      @Value("${bgc.fix.trading.waitForLogoutTimeoutInSec}") final int waitForLogoutTimeoutInSec,
                                      @Value("${bgc.fix.trading.allowedLatencyMs}") final int allowedLatencyMs,
                                      @Value("${bgc.fix.trading.session.enable:true}") final boolean enableTradingSession,
                                      final SourceSequencer sourceSequencer) throws Exception {

        final FixSessionCfg tradingSession = fixEngineCfg.fixSessionCfgs().stream().filter(fixSessionCfg -> fixSessionCfg.name().equals("trading")).findFirst().get();
        tradingSession.sessionMessageProvider(tradingSessionMessageProvider);

        final MonitoredQueue.MetricRecorder<Venue> metricRecorder = (metric, value, element) ->
                metricRepository.getOrCreate(MonitoredQueueMetric.TRADING.apply(metric), null).record(value);
        final ChronicleMessageHandler<ExecutionReport> executionReportHandler = new MonitoredChronicleMessageHandler<>(
                new BgcExecutionReportHandler(tradingEncoderSupplier, precisionClock, senderCompId, compId, tradingMessageIdGenerator::get, sourceSequencer),
                metricRecorder);
        final ChronicleMessageHandler<OrderCancelReject> orderCancelRejectHandler = new MonitoredChronicleMessageHandler<>(
                new BgcOrderCancelRejectHandler(tradingEncoderSupplier, precisionClock, senderCompId, compId, tradingMessageIdGenerator::get, sourceSequencer),
                metricRecorder);

        final FixTradingApplication fixTradingApplication = new FixTradingApplication(executionReportHandler, orderCancelRejectHandler, applicationLogonHandler);
        tradingSession.messageNotifier(fixTradingApplication);
        tradingSession.probes(new CheckLatencyProbes(new PerformanceProbes(), allowedLatencyMs));
        tradingSession.consumer(tradingFixLogConsumer);
        return FixEngine.create("BGCMIDFX-TRADING", fixEngineCfg.createInstance(tradingSession.hostId(), fixTradingEventLoopStep), waitForLogoutTimeoutInSec, enableTradingSession);
    }

    @Bean
    public BooleanSupplier readyToSendHeartbeat(final SessionState tradingSessionState) {
        return tradingSessionState;
    }
}