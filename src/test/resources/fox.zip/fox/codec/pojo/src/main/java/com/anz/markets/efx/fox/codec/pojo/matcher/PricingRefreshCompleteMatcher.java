package com.anz.markets.efx.fox.codec.pojo.matcher;

import java.util.function.Predicate;

import com.anz.markets.efx.fox.codec.pojo.model.PricingRefreshComplete;
import com.anz.markets.efx.matcher.ComparisonMatcher;
import com.anz.markets.efx.matcher.Matcher;
import com.anz.markets.efx.matcher.Matchers;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.core.Garbage;
import static com.anz.markets.efx.matcher.Matchers.translate;

@Garbage(Garbage.Type.ANY)
public interface PricingRefreshCompleteMatcher extends Predicate<Object> {

    Matcher<PricingRefreshCompleteMatcher, Header> header();
    Matcher<PricingRefreshCompleteMatcher, PricingRefreshComplete.Body> body();

    static PricingRefreshCompleteMatcher build() {
        return new PricingRefreshCompleteMatcher() {
            private Predicate<PricingRefreshComplete> predicate = Matchers.isA(PricingRefreshComplete.class);

            @Override
            public Matcher<PricingRefreshCompleteMatcher, Header> header() {
                return matcher -> andThen(translate(pricingRefreshComplete -> pricingRefreshComplete.header, matcher));
            }

            @Override
            public Matcher<PricingRefreshCompleteMatcher, PricingRefreshComplete.Body> body() {
                return matcher -> andThen(translate(pricingRefreshComplete -> pricingRefreshComplete.body, matcher));
            }

            @Override
            public boolean test(final Object o) {
                return o instanceof PricingRefreshComplete && predicate.test((PricingRefreshComplete) o);
            }

            @Override
            public String toString() {
                return predicate.toString();
            }

            private PricingRefreshCompleteMatcher matcher() {
                return this;
            }

            private PricingRefreshCompleteMatcher andThen(final Predicate<? super PricingRefreshComplete> next) {
                predicate = Matchers.and(predicate, next);
                return this;
            }
        };
    }

    static ComparisonMatcher<PricingRefreshComplete.Body, Long> instrumentId() {
        return ComparisonMatcher.create("instrumentId", b -> b.instrumentId);
    }

    static ComparisonMatcher<PricingRefreshComplete.Body, Boolean> forceSnapshot() {
        return ComparisonMatcher.create("forceSnapshot", b -> b.forceSnapshot);
    }
}
