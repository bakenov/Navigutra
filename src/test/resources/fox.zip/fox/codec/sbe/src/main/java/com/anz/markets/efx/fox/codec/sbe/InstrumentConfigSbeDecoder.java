package com.anz.markets.efx.fox.codec.sbe;

import com.anz.markets.efx.fox.codec.api.InstrumentConfigDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderDecoder;
import com.anz.markets.efx.fox.codec.sbe.raw.YesNo;
import com.anz.markets.efx.ngaro.codec.Header;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;

public class InstrumentConfigSbeDecoder implements InstrumentConfigDecoder {
    private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder instrumentConfigDecoder = new com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder();
    private final SbeHeader header = new SbeHeader(headerDecoder);
    private final SbeBody body = new SbeBody();
    private EncodingOrder.InstrumentConfig encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;


    private int bodyLimit;

    public boolean wrap(final SbeMessage sbeMessage) {
        headerDecoder.wrap(sbeMessage.buffer(), 0);
        if (headerDecoder.templateId() != com.anz.markets.efx.fox.codec.sbe.raw.InstrumentConfigDecoder.TEMPLATE_ID) {
            clear();
            return false;
        }

        instrumentConfigDecoder.wrap(sbeMessage.buffer(), headerDecoder.encodedLength(), headerDecoder.blockLength(), headerDecoder.version());
        this.bodyLimit = instrumentConfigDecoder.limit();
        encodingOrder = EncodingOrder.InstrumentConfig.INITIAL;
        return true;
    }

    public void clear() {
        headerDecoder.wrap(null, 0);
        instrumentConfigDecoder.wrap(null, 0, 0, 0);
    }

    @Override
    public Header header() {
        return header;
    }

    @Override
    public Body body() {
        encodingOrder = EncodingOrder.InstrumentConfig.BODY;
        instrumentConfigDecoder.limit(bodyLimit);
        return body;
    }

    @Override
    public void appendTo(final StringBuilder stringBuilder) {
        instrumentConfigDecoder.appendTo(stringBuilder);
    }

    class SbeBody implements Body {

        @Override
        public long instrumentId() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.instrumentId();
        }

        @Override
        public int pipSizeDivisor() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.pipSizeDivisor();
        }

        @Override
        public boolean enabled() {
            encodingOrder.checkStrict(EncodingOrder.InstrumentConfig.BODY);
            return instrumentConfigDecoder.enabled() == YesNo.YES;
        }
    }
}