package com.anz.axle.lg.adapter.ebs;

import com.anz.axle.lg.adapter.chroniclefix.MarketDataRequestEncoder;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.MarketDataRequest_MDEntryTypesGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.components.MarketDataRequest_RelatedSymGrp_1;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDBookType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.MDUpdateType;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.MarketDataRequest;
import com.anz.axle.lg.adapter.ebs.chroniclefix.generated.messages.datamodel.DefaultMarketDataRequest;
import com.anz.axle.lg.adapter.fix.FixCFICode;
import com.anz.axle.lg.adapter.fix.MarketDataSubscription;
import com.anz.axle.lg.util.CachedFunction;
import com.anz.axle.lg.util.SymbolNormaliser;

import java.util.Objects;

import static com.anz.axle.lg.adapter.ebs.chroniclefix.generated.fields.SubscriptionRequestType.SNAPSHOT_PLUS_UPDATES;

public class EbsMarketDataRequestEncoder implements MarketDataRequestEncoder<MarketDataRequest> {
    private static final char EBS_MD_ENTRY_TYPE_ALL_AVALIABLE_TYPES = '*';
    private static final char EBS_AGGREGATED_BOOK_Y = 'Y';
    private final DefaultMarketDataRequest marketDataRequest = new DefaultMarketDataRequest();
    private final CachedFunction<String, String> symbol7Lookup = CachedFunction.of(SymbolNormaliser::toSymbol7);

    private final TenorLookup tenorLookup;

    public EbsMarketDataRequestEncoder(final TenorLookup tenorLookup) {
        this.tenorLookup = Objects.requireNonNull(tenorLookup);
        marketDataRequest.subscriptionRequestType(SNAPSHOT_PLUS_UPDATES);
    }

    @Override
    public MarketDataRequest encodeSubscribe(final long requestId, final MarketDataSubscription subscription) {
        return encode(marketDataRequest, requestId, subscription, SNAPSHOT_PLUS_UPDATES);
    }

    @Override
    public MarketDataRequest encodeUnsubscribe(final long requestId, final MarketDataSubscription subscription) {
        throw new UnsupportedOperationException();
    }

    private MarketDataRequest encode(final MarketDataRequest marketDataRequest, final long requestId, final MarketDataSubscription subscription, final char subscriptionRequestType) {

        marketDataRequest.mDReqID(marketDataRequest.mDReqID_buffer());
        marketDataRequest.mDReqID().append(requestId);
        marketDataRequest.noMDEntryTypes(1);
        final MarketDataRequest_MDEntryTypesGrp_1 entryTypesGrp_1 = marketDataRequest.marketDataRequest_MDEntryTypesGrp_1(0);
        entryTypesGrp_1.mDEntryType(EBS_MD_ENTRY_TYPE_ALL_AVALIABLE_TYPES);
        marketDataRequest.subscriptionRequestType(subscriptionRequestType);
        marketDataRequest.mDBookType(MDBookType.PRICE_DEPTH);
        marketDataRequest.marketDepth(subscription.marketDepth());
        marketDataRequest.mDUpdateType(MDUpdateType.INCREMENTAL_REFRESH);
        marketDataRequest.aggregatedBook(EBS_AGGREGATED_BOOK_Y);

        marketDataRequest.noRelatedSym(1);
        final MarketDataRequest_RelatedSymGrp_1 relatedSymGrp_1 = marketDataRequest.marketDataRequest_RelatedSymGrp_1(0);
        relatedSymGrp_1.symbol(symbol7Lookup.apply(subscription.instrumentKey().symbol()));
        relatedSymGrp_1.cFICode(FixCFICode.to(subscription.instrumentKey().securityType()));
        relatedSymGrp_1.settlType(tenorLookup.ebsTenor(subscription.instrumentKey().tenor()));

        return marketDataRequest;
    }
}
