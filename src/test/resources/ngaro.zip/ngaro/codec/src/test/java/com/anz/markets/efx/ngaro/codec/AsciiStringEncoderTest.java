package com.anz.markets.efx.ngaro.codec;

import org.junit.Test;

import com.anz.markets.efx.ngaro.core.AsciiString;
import com.anz.markets.efx.ngaro.core.ByteReader;
import com.anz.markets.efx.ngaro.core.ExpandableAsciiString;
import com.anz.markets.efx.ngaro.core.FixedLengthAsciiString;
import com.anz.markets.efx.ngaro.core.LongCodec;
import com.anz.markets.efx.ngaro.core.MutableAsciiString;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for {@link AsciiStringEncoder}
 */
public class AsciiStringEncoderTest {

    private static final Object ENCLOSING_ENCODER = new Object();

    @Test(expected = NullPointerException.class)
    public void noNullEnclosingEncoder_forSupplier() {
        AsciiStringEncoder.forSupplier(null, () -> new ExpandableAsciiString(10), 10);
    }

    @Test(expected = NullPointerException.class)
    public void noNullEnclosingEncoder_forExpandableAsciiString() {
        AsciiStringEncoder.forExpandableAsciiString(null);
    }

    @Test(expected = NullPointerException.class)
    public void noNullSupplier() {
        AsciiStringEncoder.forSupplier(ENCLOSING_ENCODER, null, 10);
    }

    @Test(expected = IllegalArgumentException.class)
    public void noNegativeMaxLength() {
        AsciiStringEncoder.forSupplier(ENCLOSING_ENCODER, () -> new ExpandableAsciiString(10), -1);
    }

    @Test(expected = NullPointerException.class)
    public void noNullMutableAsciiString() {
        AsciiStringEncoder.forMutableAsciiString(ENCLOSING_ENCODER, null, 0);
    }

    @Test(expected = NullPointerException.class)
    public void noNullExpandableAsciiString() {
        AsciiStringEncoder.forExpandableAsciiString(ENCLOSING_ENCODER, null);
    }

    @Test(expected = NegativeArraySizeException.class)
    public void noNegativeLength() {
        AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, -1);
    }

    @Test
    public void encodeEmpty() throws Exception {
        //given
        final AsciiStringEncoder<?> enc = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, 3);

        //when
        enc.encodeEmpty();

        //then
        assertEquals("result should contain empty value", null, enc.asciiString().toStringOrNull());
    }

    @Test
    public void encodeFromCharSequence() throws Exception {
        //given
        final int length = 6;
        final AsciiStringEncoder<?> enc = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, length);

        //when
        enc.encode("1234567");

        //then
        assertEquals("result should contain 123456", "123456", enc.asciiString().toStringOrNull());

        //when
        enc.encode("UVWXYZ", 3, 3);

        //then
        assertEquals("result should contain XYZ", "XYZ", enc.asciiString().toStringOrNull());
    }

    @Test
    public void encodeFromNullableCharSequence() throws Exception {
        //given
        final int length = 6;
        final AsciiStringEncoder<?> enc1 = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, length);
        final AsciiStringEncoder<?> enc2 = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, length);

        //when
        enc1.encodeNullable("1234567");

        //then
        assertEquals("result should contain 123456", "123456", enc1.asciiString().toStringOrNull());

        //when
        enc2.encodeNullable(null);

        //then
        assertEquals("result should be empty", null, enc2.asciiString().toStringOrNull());
    }

    @Test
    public void encodeFromByteReader() throws Exception {
        //given
        final int length = 6;
        final AsciiStringEncoder<?> enc = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, length);

        //when
        enc.encode("1234567", ByteReader.CHAR_SEQUENCE, length);

        //then
        assertEquals("result should contain 123456", "123456", enc.asciiString().toStringOrNull());

        //when
        enc.encode("UVWXYZ", ByteReader.CHAR_SEQUENCE, 3, 3);

        //then
        assertEquals("result should contain XYZ", "XYZ", enc.asciiString().toStringOrNull());
    }

    @Test
    public void encodeFromStringDecoder() throws Exception {
        //given
        final int length = 6;
        final AsciiStringEncoder<?> enc = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, length);
        final StringDecoder dec = AsciiStringDecoder.forCharSequence("123456");

        //when
        enc.encodeFrom(dec);

        //then
        assertEquals("result should contain 123456", "123456", enc.asciiString().toStringOrNull());
    }

    @Test
    public void encodeLong() {
        final long value = 56789564;
        final FixedLengthAsciiString asciiString = AsciiString.fixedLength(20);

        final AsciiStringEncoder<?> enc = AsciiStringEncoder.forFixedLengthAsciiString(ENCLOSING_ENCODER, asciiString);

        enc.encodeLong(value);

        assertEquals(LongCodec.decodeSigned(asciiString), value);
    }
}