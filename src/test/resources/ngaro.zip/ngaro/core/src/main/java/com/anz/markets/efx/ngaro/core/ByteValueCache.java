package com.anz.markets.efx.ngaro.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * A cache for values which can be created based on a sequence of bytes.
 * <p/>
 * This class is NOT thread safe!
 */
public class ByteValueCache<V> {

    public static final int DEFAULT_INITIAL_BUFFER_CAPACITY = 32;
    public static final int DEFAULT_CACHE_CAPACITY = 256;

    private final Function<? super AsciiString, ? extends V> valueFactory;
    private final List<MutableAsciiString> cachedBuffers;
    private final List<MutableAsciiString> unusedBuffers;
    private final List<V> cachedValues;
    private MutableAsciiString temp;

    public ByteValueCache(final Function<? super AsciiString, ? extends V> valueFactory) {
        this(valueFactory, DEFAULT_INITIAL_BUFFER_CAPACITY, DEFAULT_CACHE_CAPACITY);
    }

    public ByteValueCache(final Function<? super AsciiString, ? extends V> valueFactory, final int initialBufferCapacity, final int cacheSize) {
        this.valueFactory = Objects.requireNonNull(valueFactory);
        this.cachedValues = new ArrayList<>(cacheSize);
        this.cachedBuffers = new ArrayList<>(cacheSize);
        this.unusedBuffers = new ArrayList<>(cacheSize);
        this.temp = new ExpandableAsciiString(initialBufferCapacity);
        for (int i = 0; i < cacheSize; i++) {
            unusedBuffers.add(new ExpandableAsciiString(initialBufferCapacity));
        }
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only possible if caching of a value causes eviction of another value due to a full cache")
    public <S> V lookupOrCache(final AsciiString bytes) {
        return lookupOrCache(bytes, ByteReader.ASCII_STRING, 0, bytes.length());
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only possible if caching of a value causes eviction of another value due to a full cache")
    public <S> V lookupOrCache(final S source, final ByteReader<? super S> reader, final int length) {
        return lookupOrCache(source, reader, 0, length);
    }

    @Garbage(value = Garbage.Type.RARE, description = "Garbage only possible if caching of a value causes eviction of another value due to a full cache")
    public <S> V lookupOrCache(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        temp.set(source, reader, offset, length);
        final int index = binarySearchTempInCache();
        if (index >= 0) {
            //found in cache, simply return
            temp.clear();
            return cachedValues.get(index);
        } else {
            //not yet in cache
            final int insertIndex = -(index + 1);
            final V value = valueFactory.apply(temp);
            if (unusedBuffers.isEmpty()) {
                //cache runs out of capacity, simply replace currently cached value at insertIndex with new one
                final MutableAsciiString newTemp = cachedBuffers.set(insertIndex, temp);
                @SuppressWarnings("unused") //TODO we could notify some Consumer<? super V> that value has been evicted
                final V evicted = cachedValues.set(insertIndex, value);
                temp = newTemp;
            } else {
                //there is still capacity in the cache
                //add value at insertIndex and move all other values down by one
                cachedBuffers.add(insertIndex, temp);
                cachedValues.add(insertIndex, value);
                temp = unusedBuffers.remove(unusedBuffers.size() - 1);
            }
            temp.clear();
            return value;
        }
    }

    @Garbage(Garbage.Type.ANY)
    public void clearCache() {
        final int cacheSize = cachedBuffers.size();
        for (int i = 0; i < cacheSize; i++) {
            cachedBuffers.get(i).clear();
        }
        unusedBuffers.addAll(cachedBuffers);
        cachedBuffers.clear();
        cachedValues.clear();
    }

    public int getCacheSize() {
        return cachedValues.size();
    }

    /**
     * Checks whether a value whose bytes are equal to ones read by from {@code source} by {@code reader} is currently
     * in the cache.
     *
     * @param source the source to read the bytes from
     * @param reader the reader reading from {@code source}
     * @param length the number of bytes to read
     * @return true if an equal value currently exists in the cache, and false otherwise
     */
    public <S> boolean isCached(final S source, final ByteReader<? super S> reader, final int length) {
        return isCached(source, reader, 0, length);
    }

    /**
     * Checks whether a value whose bytes are equal to ones read by from {@code source} by {@code reader} is currently
     * in the cache.
     *
     * @param source the source to read the bytes from
     * @param reader the reader reading from {@code source}
     * @param offset the byte offset in {@code source} to read from
     * @param length the number of bytes to read
     * @return true if an equal value currently exists in the cache, and false otherwise
     */
    public <S> boolean isCached(final S source, final ByteReader<? super S> reader, final int offset, final int length) {
        temp.set(source, reader, offset, length);
        final int index = binarySearchTempInCache();
        temp.clear();
        return index >= 0;
    }

    /**
     * Checks whether an equal value is currently in the cache. This method is NOT efficient!
     *
     * @param value the value to test
     * @return true if an equal value currently exists in the cache, and false otherwise
     */
    public boolean isCached(final V value) {
        final int cacheSize = cachedValues.size();
        for (int i = 0; i < cacheSize; i++) {
            if (cachedValues.get(i).equals(value)) {
                return true;
            }
        }
        return false;
    }

    private final int binarySearchTempInCache() {
        return Collections.binarySearch(cachedBuffers, temp);
    }

}
