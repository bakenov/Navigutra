package com.anz.markets.efx.fox.codec.sbe;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.anz.markets.efx.fox.codec.api.UserConfigEncoder;
import com.anz.markets.efx.fox.codec.api.UserGroup;
import com.anz.markets.efx.fox.codec.sbe.raw.MessageHeaderEncoder;
import com.anz.markets.efx.fox.codec.sbe.raw.UserConfigDecoder;
import com.anz.markets.efx.ngaro.codec.EnumerableSetEncoder;
import com.anz.markets.efx.ngaro.codec.StringEncoder;
import com.anz.markets.efx.ngaro.sbe.MutableSbeMessage;
import com.anz.markets.efx.ngaro.sbe.SbeMessage;
import com.anz.markets.efx.ngaro.sbe.StringEncoders;

public final class SbeUserConfigEncoder implements UserConfigEncoder, UserConfigEncoder.Body {

    private static final byte NULL = 0;
    private final Supplier<? extends MutableSbeMessage> mutableMessageSupplier;
    private final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier;
    private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
    private final com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder userConfigEncoder = new com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder();

    private final SbeMessageEncoder messageEncoder = new SbeMessageEncoder();
    private final EnumerableSetEncoder<Body, UserGroup> userGroups = new SbeUserGroupSetEncoder<>(this,
            userConfigEncoder::userGroups);
    private final StringEncoder<Body> userName = StringEncoders.forFixedLength(this,
            userConfigEncoder::userName, com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.userNameLength());
    private final StringEncoder<Trailer> location = StringEncoders.forFixedLength(messageEncoder,
            userConfigEncoder::location, com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.locationLength());


    private EncodingOrder.UserConfig encodingOrder = EncodingOrder.UserConfig.INITIAL;

    SbeUserConfigEncoder(final Supplier<? extends MutableSbeMessage> mutableMessageSupplier,
                         final Supplier<? extends Consumer<? super SbeMessage>> messageConsumerSupplier) {
        this.mutableMessageSupplier = Objects.requireNonNull(mutableMessageSupplier);
        this.messageConsumerSupplier = Objects.requireNonNull(messageConsumerSupplier);
    }

    @Override
    public Body messageStart(final int source, final long sourceSeq) {
        final MutableSbeMessage message = mutableMessageSupplier.get();
        final int headerLen = headerEncoder
                .wrap(message.buffer(), 0)
                .blockLength(com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.BLOCK_LENGTH)
                .templateId(com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.TEMPLATE_ID)
                .schemaId(com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.SCHEMA_ID)
                .version(com.anz.markets.efx.fox.codec.sbe.raw.UserConfigEncoder.SCHEMA_VERSION)
                .source(source)
                .sourceSeq(sourceSeq)
                .encodedLength();
        messageEncoder.init(message, headerLen, messageConsumerSupplier.get());
        userConfigEncoder.wrap(message.buffer(), headerLen);
        encodingOrder = EncodingOrder.UserConfig.BODY;
        clearBody(headerLen);
        return this;
    }

    private void clearBody(final int offset) {
        userConfigEncoder.buffer().setMemory(offset, userConfigEncoder.sbeBlockLength(), NULL);
    }

    @Override
    public StringEncoder<Body> userName() {
        encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
        return userName;
    }

    @Override
    public EnumerableSetEncoder<Body, UserGroup> userGroups() {
        encodingOrder.checkStrict(EncodingOrder.UserConfig.BODY);
        return userGroups;
    }

    @Override
    public StringEncoder<Trailer> location() {
        encodingOrder = encodingOrder.checkAllowMoveToNext(EncodingOrder.UserConfig.TRAILER);
        return location;
    }

    private final class SbeMessageEncoder implements Trailer {
        private MutableSbeMessage message;
        private int headerLength;
        private Consumer<? super SbeMessage> messageConsumer;

        void init(final MutableSbeMessage message,
                  final int headerLength,
                  final Consumer<? super SbeMessage> messageConsumer) {
            this.message = Objects.requireNonNull(message);
            this.headerLength = headerLength;
            this.messageConsumer = Objects.requireNonNull(messageConsumer);
        }

        void reset() {
            this.messageConsumer = null;
            this.headerLength = 0;
            this.message = null;
        }

        @Override
        public void messageComplete() {
            try {
                encodingOrder.checkStrict(EncodingOrder.UserConfig.TRAILER);
                message.messageLength(headerLength + userConfigEncoder.encodedLength());
                messageConsumer.accept(message);
            } finally {
                encodingOrder = EncodingOrder.UserConfig.INITIAL;
                headerEncoder.wrap(null, 0);
                userConfigEncoder.wrap(null, 0);
                reset();
            }
        }
    }
}
