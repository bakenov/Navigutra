package com.anz.markets.prophet.atest.framework;

import com.anz.markets.prophet.atest.framework.impl.AtLeastMessageCountPredicate;
import com.anz.markets.prophet.atest.framework.impl.ExactMessageCountPredicate;
import com.anz.markets.prophet.atest.framework.impl.ProphetServerEmbeddedImpl;
import com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl;
import com.anz.markets.prophet.atest.framework.matcher.HedgeFirewallPnlStatusMatcher;
import com.anz.markets.prophet.atest.framework.matcher.HedgeFirewallTradeVolumeMatcher;
import com.anz.markets.prophet.atest.framework.matcher.IsClientPricePoint;
import com.anz.markets.prophet.atest.framework.matcher.IsMarketPricePoint;
import com.anz.markets.prophet.atest.framework.matcher.OptimalPositionMatcher;
import com.anz.markets.prophet.atest.framework.matcher.OptimalPositionsInstrumentMatcher;
import com.anz.markets.prophet.atest.framework.matcher.RiskPathMatcher;
import com.anz.markets.prophet.domain.HedgeFirewallType;
import com.anz.markets.prophet.domain.HedgePauseSignal;
import com.anz.markets.prophet.domain.HedgePauseSignalSource;
import com.anz.markets.prophet.domain.HedgePortfolioState;
import com.anz.markets.prophet.domain.HedgeTriggerType;
import com.anz.markets.prophet.domain.HedgeTriggerState;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OperatingHourSpecification;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.OrderSide;
import com.anz.markets.prophet.domain.Portfolio;
import com.anz.markets.prophet.domain.PricingFirewallType;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.ThrottlerPublishReason;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.control.HedgeCurrencyControl;
import com.anz.markets.prophet.domain.control.SkewCurrencyControl;
import com.anz.markets.prophet.domain.hedger.HedgeDecision;
import com.anz.markets.prophet.domain.marketdata.impl.FilteredMarketDataSnapshot;
import com.anz.markets.prophet.domain.order.CancelOrder;
import com.anz.markets.prophet.domain.order.NewOrder;
import com.anz.markets.prophet.domain.pnl.ProfitAndLoss;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.domain.status.HedgeStatus;
import com.anz.markets.prophet.domain.time.TestTimeSource;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatus;
import com.anz.markets.prophet.hedger.firewall.HedgeFirewallStatusImpl;
import com.anz.markets.prophet.hedger.rules.HedgePortfolioStateTransition;
import com.anz.markets.prophet.matcher.ClientPriceMatcher;
import com.anz.markets.prophet.matcher.IsRoundedTo;
import com.anz.markets.prophet.matcher.PricingFirewallTypeMatcher;
import com.anz.markets.prophet.matcher.RegExStringMatcher;
import com.anz.markets.prophet.positionrisk.Positions;
import com.anz.markets.prophet.positionrisk.hedging.volume.HedgePauseState;
import com.anz.markets.prophet.risk.GradientOptimalPosition;
import com.anz.markets.prophet.riskpath.RiskPath;
import com.anz.markets.efx.ngaro.math.DoubleTools;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.status.TimeSource;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.anz.markets.prophet.util.SystemProperties;
import com.codahale.metrics.MetricRegistry;
import org.hamcrest.Matcher;
import org.jetbrains.annotations.NotNull;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

import static com.anz.markets.prophet.atest.framework.impl.ProphetServerEmbeddedImpl.START_TIME_MS;
import static com.anz.markets.prophet.atest.framework.impl.TestDataDictionaryImpl.OPTIMAL_POSITION_CONFIG_MAP;
import static com.anz.markets.prophet.domain.HedgePortfolioState.DISABLED;
import static com.anz.markets.prophet.domain.HedgePortfolioState.ENABLED;
import static com.anz.markets.prophet.domain.HedgePortfolioState.PENDING_DISABLED;
import static java.lang.Math.abs;
import static java.util.concurrent.TimeUnit.NANOSECONDS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assume.assumeTrue;

/**
 * Provides a set of known touch points for test to interact with.
 * <p>
 * Test that derives from this class will have a live prophet server available ready for test case to interact with.
 * <p>
 * <li> prophet (prophet server) exposes a view port to interact with the prophet (eg. sending command in and out).
 * <li> tdd (test data dictionary) contains a list of test data and convenient method to construct test data.
 * <p>
 * Apart from these two access points, acceptance test should refrain from access any other things. When done this way,
 * the test can be read simply and functionalities/access are organised into known and supported point of interaction.
 */
public abstract class BaseAcceptanceSpecification {
    @Rule
    public TestName name = new TestName();

    public static final boolean RUN_ALL_PARAMETERIZE_TESTS = Boolean.valueOf("atest.runall.parameterize.tests");

    protected static final double DONT_CARE_LARGE_DOUBLE = Double.MAX_VALUE;
    protected static final int DONT_CARE_LARGE_LONG = Integer.MAX_VALUE;
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final boolean SHOW_MESSAGES_AT_END_OF_TEST = Boolean.getBoolean("prophet.acceptance.test.logMessages") || Boolean.valueOf(System.getenv("PROPHET_ATEST_LOG_MESSAGES"));
    private static final long ONE_SECOND_IN_MILLIS = TimeUnit.SECONDS.toMillis(1L);

    /**
     * Prophet server that test can interact with by sending event in and expecting output.
     */
    public static final ProphetServer prophet;
    protected static final TestDataDictionary tdd = new TestDataDictionaryImpl();
    protected static final MetricRegistry metrics = new MetricRegistry();

    private final Comparator<Output> outputComparator = (o1, o2) -> {
        final int sortedById = Long.compare(o1.header.getEventId(), o2.header.getEventId());
        if (sortedById == 0) {
            return Integer.compare(o1.source.getPriority(), o2.source.getPriority());
        }
        return sortedById;
    };

    static {
        prophet = new ProphetServerEmbeddedImpl();
    }

    private OperatingHourSpecification.State initialOperatingHourState = OperatingHourSpecification.State.OPEN;

    private void start() {
        prophet.start();

        prophet.resetAllPositions();
        prophet.resetManualSkews();
        prophet.resetAllPricingState();
        prophet.setUpDefaultSpotDates();
        prophet.receive(TradingTimeZone.LDN);

        if (initialOperatingHourState != OperatingHourSpecification.State.UNDEFINED) {
            prophet.receiveOperatingHourStateForAllEntities(initialOperatingHourState);
        }

        // this will block till events are flushed through.
        prophet.clearOutputBuffer();
        prophet.clearInputCommands();
        prophet.clearLogCapture();
        removeAllMetrics();
    }

    @Before
    public void beforeEach() throws NoSuchMethodException {
        GcFriendlyAssert.isFalse(restartForEveryMethod() && restartForAMethod(), "Please make up your mind. Do you want every method to restart server? If so remove restart annotation at method level.");

        if (restartForEveryMethod() || restartForAMethod()) {
            prophet.stop();
        } else {
            // Complement fractional seconds so times are in sync between test and prophet core time sources
            completeFractionalSeconds();
        }

        assumeTrue(correctCoreMode());

        start();
    }

    private void completeFractionalSeconds() {
        final TimeSource timeSource = Context.context().timeSource();
        if (timeSource instanceof TestTimeSource) {
            final long fractionalSecond =  timeSource.nowMillis() % ONE_SECOND_IN_MILLIS;
            if (fractionalSecond > 0) {
                final long incrementMS = ONE_SECOND_IN_MILLIS - fractionalSecond;
                logger.info("Prior test had fractional seconds left hanging. Moving time by {}ms to ensure all prophet cores are in sync with test time source.", incrementMS);
                prophet.incrementTime(incrementMS);
            }
        }
    }

    private boolean correctCoreMode() throws NoSuchMethodException {
        final RunInCoreMode annotation = this.getClass().getMethod(getTestMethodName()).getAnnotation(RunInCoreMode.class);
        if (annotation == null) {
            return true;
        } else {
            return annotation.coreMode() == SystemProperties.CORE_MODE;
        }
    }


    private boolean restartForAMethod() throws NoSuchMethodException {
        final RestartBeforeTest annotation = this.getClass().getMethod(getTestMethodName()).getAnnotation(RestartBeforeTest.class);
        if (annotation != null) {
            initialOperatingHourState = annotation.initialOperatingHourChime();
            return true;
        } else {
            return false;
        }
    }

    @NotNull
    private String getTestMethodName() {
        final int endIndex = name.getMethodName().indexOf('[');
        if (endIndex > 0) {
            return name.getMethodName().substring(0, endIndex);
        } else {
            return name.getMethodName();
        }
    }

    private boolean restartForEveryMethod() {
        final RestartBeforeTest annotation = this.getClass().getAnnotation(RestartBeforeTest.class);
        if (annotation != null) {
            initialOperatingHourState = annotation.initialOperatingHourChime();
            return true;
        } else {
            return false;
        }
    }

    private void removeAllMetrics() {
        for (String name : metrics.getNames()) {
            metrics.remove(name);
        }
    }

    @After
    public void afterEach() {
        if (!SHOW_MESSAGES_AT_END_OF_TEST) {
            return;
        }

        final List<Output> bufferedOutput = new ArrayList<>(prophet.getBufferedOutput());
        bufferedOutput.sort(outputComparator);
        if (bufferedOutput.size() == 0) {
            logger.info("No output generated during test.");
        } else {
            final int maxSize = 1000;
            logger.info("Last {} messages generated outputs during test.", maxSize);
            int index = bufferedOutput.size() > maxSize ? bufferedOutput.size() - maxSize : 0;
            for (int i = index; i < bufferedOutput.size(); i++) {
                final Output output = bufferedOutput.get(i);
                logger.info("{}[{},{}ms]: {}", output.source, output.header.getEventId(), NANOSECONDS.toMillis(output.header.getEventTimeStampNS()) - START_TIME_MS, output.data);
            }
        }
    }

    /**
     * Matcher with a built in intelligent rounder that will infer the decimal places from the expected value to do
     * the comparison.
     * <p>
     * <p>
     * e.g.,
     * expected: 2.3
     * actual: 2.33
     * <p>
     * In tihs case the actual value(2.33) will be round up to 1 decimal place because expected value(2.3) is provided
     * with one decimal place. The comparison will succeed.
     *
     * @param expected
     * @return
     */
    protected IsRoundedTo isRoundedTo(final double expected) {
        return new IsRoundedTo(expected);
    }

    // Matcher to handle floats
    // TODO: improve
    public static Matcher<Double> isNear(double expected) {
        if(Double.isNaN(expected)) {
            return is(Double.NaN);
        }
        int expectedDP = DoubleTools.decimalPlaces(expected);
        final int FLOAT_PLACES = 6;
        if(expectedDP > FLOAT_PLACES) {
            throw new RuntimeException("Cannot test a float to this many places");
        }
        return is(new IsRoundedTo(expected, expectedDP));
    }


    /**
     * Matcher that compares actual ClientPrice with given price point information.
     *
     * @param level
     * @param levelQty
     * @param bidPx
     * @param offersPx
     * @return
     */
    protected IsClientPricePoint isClientPricePoint(final int level,
                                                    final Level levelQty,
                                                    final double bidPx,
                                                    final double offersPx) {
        return new IsClientPricePoint(level, levelQty, bidPx, offersPx);
    }

    protected IsMarketPricePoint isMarketPricePoint(final int level,
                                                    final Level levelQty,
                                                    final double bidPx,
                                                    final double offersPx) {
        return new IsMarketPricePoint(level, levelQty.getQty(), bidPx, levelQty.getQty(), offersPx);
    }

    protected IsMarketPricePoint isMarketPricePoint(final int level,
                                                    final Level levelQtyBid,
                                                    final double bidPx,
                                                    final Level levelQtyOffer,
                                                    final double offersPx) {
        return new IsMarketPricePoint(level, levelQtyBid.getQty(), bidPx, levelQtyOffer.getQty(), offersPx);
    }

    protected IsMarketPricePoint isMarketPricePoint(final int level,
                                                    final double levelQty,
                                                    final double bidPx,
                                                    final double offersPx) {
        return new IsMarketPricePoint(level, levelQty, bidPx, levelQty, offersPx);
    }

    protected ClientPriceMatcher isClientPrice(final ClientPrice clientPrice) {
        return new ClientPriceMatcher(clientPrice);
    }

    protected OptimalPositionMatcher isOptimalPosition(final OptimalPosition optimalPosition) {
        return new OptimalPositionMatcher(optimalPosition, true);
    }

    protected RiskPathMatcher isRiskPath(final RiskPath riskPath) {
        return new RiskPathMatcher(riskPath);
    }

    protected Predicate<Output<RiskPath>> isRiskPath(final String tradeId, final Currency currency) {
        return o -> o.data.getTradeId().toString().startsWith(tradeId) && o.data.getCurrency() == currency;
    }

    protected HedgeFirewallPnlStatusMatcher isHedgeFirewallPnlStatus(final HedgeFirewallType type,
                                                                     final Portfolio portfolio,
                                                                     final HedgeFirewallStatus.Status status,
                                                                     final double displacementPnl,
                                                                     final double thisPnl,
                                                                     final double minPnl,
                                                                     final double maxPnl,
                                                                     final double limitPnl) {
        final HedgeFirewallStatusImpl hedgeFirewallStatus = new HedgeFirewallStatusImpl();
        hedgeFirewallStatus.setHedgeFirewallType(type);
        hedgeFirewallStatus.setStatus(status);
        hedgeFirewallStatus.setPortfolio(portfolio);
        return new HedgeFirewallPnlStatusMatcher(hedgeFirewallStatus, displacementPnl, thisPnl, minPnl, maxPnl, limitPnl);
    }


    protected HedgeFirewallTradeVolumeMatcher isHedgeFirewallTradeVolumeStatus(final Portfolio portfolio,
                                                                               final HedgeFirewallStatus.Status status,
                                                                               final double currentVolume,
                                                                               final double changeVolume,
                                                                               final double limit) {
        final HedgeFirewallStatusImpl hedgeFirewallStatus = new HedgeFirewallStatusImpl();
        hedgeFirewallStatus.setHedgeFirewallType(HedgeFirewallType.MAXIMUM_TRADE_VOLUME_PER_HOUR);
        hedgeFirewallStatus.setStatus(status);
        hedgeFirewallStatus.setPortfolio(portfolio);
        return new HedgeFirewallTradeVolumeMatcher(hedgeFirewallStatus, currentVolume, changeVolume, limit);

    }

    protected OptimalPositionMatcher hasNoOptimalPositionFor(final Instrument instrument) {
        final GradientOptimalPosition zeroOptimalPosition = new GradientOptimalPosition(OPTIMAL_POSITION_CONFIG_MAP.get(instrument));
        zeroOptimalPosition.set(0.0, 0.0, 0.0);
        return new OptimalPositionMatcher(zeroOptimalPosition, false);
    }

    protected OptimalPositionsInstrumentMatcher hasInstruments(final EnumSet<Instrument> instruments) {
        return new OptimalPositionsInstrumentMatcher(instruments);
    }

    protected Predicate<Output<FilteredMarketDataSnapshot>> isMarket(final Market market) {
        return o -> o.data.getMarket() == market;
    }

    protected Predicate<Output<FilteredMarketDataSnapshot>> isInstrumentAndMarket(final Instrument instrument, final Market market) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market;
    }

    protected Predicate<Output<ClientPrice>> isClientPriceMarket(final Market market) {
        return o -> o.data.getMarket() == market;
    }

    protected Predicate<Output<ClientPrice>> isClientPriceInstrument(final Instrument instrument) {
        return o -> o.data.getInstrument() == instrument;
    }

    protected Predicate<Output<ClientPrice>> isClientPriceInstrumentAndMkt(final Instrument instrument,
                                                                           final Market market) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market;
    }

    protected Predicate<Output<ClientPrice>> isClientPriceEventTime(final Instrument instrument,
                                                                    final Market market,
                                                                    final long externalEventTimeNS) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market && o.data.getExternalEventTimeNS() == externalEventTimeNS;
    }

    protected Predicate<Output<ClientPrice>> isClientPriceSourceId(final Instrument instrument,
                                                                    final Market market,
                                                                    final long externalSourceId) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market && o.data.getExternalSourceId() == externalSourceId;
    }

    protected Predicate<Output<WholesaleBookFactors>> isWholesaleBookFactors(final Instrument instrument) {
        return o -> o.data.getInstrument() == instrument;
    }

    protected Predicate<Output<WholesaleBookFactors>> isWholesaleBookFactors(final Market market) {
        return o -> o.data.getMarket() == market;
    }

    protected Predicate<Output<WholesaleBookFactors>> isWholesaleBookFactors(final Instrument instrument, final Market market) {
        return o -> o.data.getMarket() == market && o.data.getInstrument() == instrument;
    }

    protected Predicate<Output<ClientPrice>> isModel(final Market market) {
        return o -> o.data.getMarket() == market;
    }

    // publishable() == PriceThrottleState.TIME_PRICE
    @NotNull
    protected Predicate<Output<ClientPrice>> isThrottled(final Market market) {
        return o -> o.data.getMarket() == market && !o.data.getThrottlerPublishReason().publishable();
    }

    @NotNull
    protected Predicate<Output<ClientPrice>> isThrottled(final Market market,
                                                         final Instrument instrument) {
        return o -> o.data.getMarket() == market && !o.data.getThrottlerPublishReason().publishable() && o.data.getInstrument() == instrument;
    }

    @NotNull
    protected Predicate<Output<ClientPrice>> isPublishable(final Market market) {
        return o -> o.data.getMarket() == market && o.data.getThrottlerPublishReason().publishable();
    }

    @NotNull
    protected Predicate<Output<ClientPrice>> isPublishable(final Market market,
                                                           final Instrument instrument) {
        return o -> o.data.getMarket() == market && o.data.getThrottlerPublishReason().publishable() && o.data.getInstrument() == instrument;
    }

    @NotNull
    protected Predicate<Output<ClientPrice>> isThrottleReason(final Market market,
                                                              final ThrottlerPublishReason reason) {
        return o -> o.data.getMarket() == market
                && o.data.getThrottlerPublishReason() == reason & o.data.getInstrument() == Instrument.AUDUSD;
    }

    @NotNull
    protected Predicate<Output<ClientPrice>> isThrottleReason(final Market market,
                                                              final Instrument instrument,
                                                              final ThrottlerPublishReason reason) {
        return o -> o.data.getMarket() == market
                && o.data.getThrottlerPublishReason() == reason & o.data.getInstrument() == instrument;
    }

    @NotNull
    protected Predicate<Output<HedgeFirewallStatus>> isHedgeFirewallStatus(final HedgeFirewallType type,
                                                                           final HedgeFirewallStatus.Status status,
                                                                           final Portfolio portfolio) {
        return o -> o.data.getHedgeFirewallType() == type && o.data.getStatus() == status && o.data.getPortfolio() == portfolio;
    }

    @NotNull
    protected Predicate<Output<HedgeFirewallStatus>> isHedgeFirewallType(final HedgeFirewallType type,
                                                                         final Portfolio portfolio) {
        return o -> o.data.getHedgeFirewallType() == type && o.data.getPortfolio() == portfolio;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatus(final Portfolio portfolio) {
        return o -> o.data.getPortfolio() == portfolio;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatus(final Portfolio portfolio, final HedgePortfolioState state) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == state;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatusIsOn(final Portfolio portfolio) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == ENABLED;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatusIsOn(final Portfolio portfolio,
                                                             final HedgePortfolioStateTransition disabledReason) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == ENABLED && o.data.getReason() == disabledReason;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatusIsOff(final Portfolio portfolio) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == DISABLED;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatusIsOff(final Portfolio portfolio,
                                                              final HedgePortfolioStateTransition disabledReason) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == DISABLED && o.data.getReason() == disabledReason;
    }

    @NotNull
    protected Predicate<Output<HedgeStatus>> hedgeStatusIsPendingDisable(final Portfolio portfolio,
                                                                         final HedgePortfolioStateTransition disabledReason) {
        return o -> o.data.getPortfolio() == portfolio && o.data.getHedgePortfolioState() == PENDING_DISABLED && o.data.getReason() == disabledReason;
    }

    @NotNull
    protected Predicate<Output<HedgeDecision>> isHedgeTriggerType(final Instrument instrument,
                                                                  final HedgeTriggerType triggerType) {
        return o -> o.data.getInstrument() == instrument && o.data.getHedgeTriggerType() == triggerType;
    }

    @NotNull
    protected Predicate<Output<HedgeDecision>> isHedgeDecision(final Instrument instrument,
                                                               final HedgeTriggerType triggerType,
                                                               final HedgeTriggerState triggerState) {
        return o -> o.data.getInstrument() == instrument && o.data.getHedgeTriggerType() == triggerType &&
                o.data.getHedgeTriggerState() == triggerState;
    }

    @NotNull
    protected Predicate<Output<HedgePauseSignal>> isPauseHedgeTriggerType(final HedgePauseSignalSource source,
                                                                          final HedgeTriggerType triggerType,
                                                                          final HedgePauseState state) {
        return o -> o.data.getHedgeTriggerType() == triggerType && o.data.getState() == state &&
                o.data.getSource() == source;
    }

    @NotNull
    protected Predicate<Output<NewOrder>> isOrderInstrument(final Instrument instrument) {
        return o -> o.data.getInstrument() == instrument;
    }

    @NotNull
    protected Predicate<Output<NewOrder>> isOrderInstrument(final Instrument instrument, final Market market) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market;
    }

    @NotNull
    protected Predicate<Output<CancelOrder>> isCancelOrderInstrument(final Instrument instrument) {
        return o -> o.data.getInstrument() == instrument;
    }

    @NotNull
    protected Predicate<Output<CancelOrder>> isCancelOrderInstrument(final Instrument instrument, final Market market) {
        return o -> o.data.getInstrument() == instrument && o.data.getMarket() == market;
    }

    @NotNull
    protected Predicate<Output<NewOrder>> isOrderMarket(final Market market) {
        return o -> o.data.getMarket() == market;
    }

    @NotNull
    protected Predicate<Output<ProfitAndLoss>> isProfitAndLossPortfolio(final Portfolio portfolio) {
        return o -> o.data.getPortfolio() == portfolio;
    }

    @NotNull
    protected Predicate<Output<Positions>> isPosition1CurrencyPnl(final Currency currency, final double pnl) {
        return o -> o.data.getPosition1().getCcy() == currency && new IsRoundedTo(pnl).matches(o.data.getPosition1().getPnl());
    }

    @NotNull
    protected Predicate<Output<Positions>> isPosition2CurrencyPnl(final Currency currency, final double pnl) {
        return o -> o.data.getPosition2().getCcy() == currency && new IsRoundedTo(pnl).matches(o.data.getPosition2().getPnl());
    }

    @NotNull
    protected Predicate<Output<Positions>> isPosition1CurrencyPortfolioPnl(final Currency currency, final Portfolio portfolio, final double pnl) {
        return o -> o.data.getPosition1().getCcy() == currency && o.data.getPosition1().getPortfolio() == portfolio && new IsRoundedTo(pnl).matches(o.data.getPosition1().getPnl());
    }

    @NotNull
    protected Predicate<Output<Positions>> isPosition2CurrencyPortfolioPnl(final Currency currency, final Portfolio portfolio, final double pnl) {
        return o -> o.data.getPosition2().getCcy() == currency && o.data.getPosition2().getPortfolio() == portfolio && new IsRoundedTo(pnl).matches(o.data.getPosition2().getPnl());
    }

    @NotNull
    protected Predicate<Output<OptimalPositions>> isGradientPosition(final Instrument instrument, final double pos) {
        return o -> o.data.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == instrument).findFirst().get().getGradientPositionInNotional() == pos;
    }

    @NotNull
    protected Predicate<Output<OptimalPositions>> isGradientPositionSystembase(final Instrument instrument, final double pos) {
        return o -> o.data.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == instrument).findFirst().get().getGradientPositionInSystemBase() == pos;
    }

    @NotNull
    protected Predicate<Output<OptimalPositions>> isGradientPositionAbove(final Instrument instrument, final double pos) {
        return o -> abs(o.data.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == instrument).findFirst().get().getGradientPositionInNotional()) > pos;
    }

    @NotNull
    protected Predicate<Output<OptimalPositions>> isGradientPositionBelow(final Instrument instrument, final double pos) {
        return o -> abs(o.data.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == instrument).findFirst().get().getGradientPositionInNotional()) < pos;
    }

    @NotNull
    protected Predicate<Output<OptimalPositions>> isOptimalPositionType(final OptimalPositionType type) {
        return o -> o.data.getOptimalPositionType() == type;
    }

    protected Predicate<Output<Positions>> isPortfolio(final Portfolio portfolio) {
        return o -> o.data.getPortfolio() == portfolio;
    }

    @NotNull
    protected Predicate<Output<HedgeCurrencyControl>> isHedgingCcyUnpaused(final Currency ccy) {
        return o -> o.data.getCurrency() == ccy && !o.data.pauseHedging();
    }

    @NotNull
    protected Predicate<Output<SkewCurrencyControl>> isSkewCcyPaused(final Currency ccy, final boolean paused) {
        return o -> o.data.currency() == ccy && o.data.pauseSkewing() == paused;
    }

    protected Matcher<String> newOrderComment(final String comment) {
        return new RegExStringMatcher(".*NewOrder.*comment=.*" + comment + ".*");
    }

    protected Matcher<String> matches(final String regex) {
        return new RegExStringMatcher(regex);
    }

    protected AtLeastMessageCountPredicate atLeast(final int i) {
        return new AtLeastMessageCountPredicate(i);
    }

    protected ExactMessageCountPredicate exactly(final int i) {
        return new ExactMessageCountPredicate(i);
    }

    /**
     * Current time in ms from acceptance test timeSource. This timeSource is maintained by
     * ProphetServerEmbeddedImpl and is recreated when the prophet server is restarted
     */
    protected long now() {
        return prophet.now();
    }

    protected <T> List<T> union(List<T>... list) {
        List union = new ArrayList();
        for (List<T> l : list) {
            union.addAll(l);
        }
        return union;
    }

    public static void checkFirewallTriggered(final ClientPrice prices, final PricingFirewallType... firewallTypes) {
        assertThat(prices, new PricingFirewallTypeMatcher(OrderSide.BID,firewallTypes));
        assertThat(prices, new PricingFirewallTypeMatcher(OrderSide.OFFER,firewallTypes));
    }
}