package com.anz.markets.efx.fox.api.domain;

public interface SourceSequencer {
    int sourceId();
    long nextSequence();

    static SourceSequencer of(final int source) {
        return new DefaultSourceSequencer(source);
    }
}
