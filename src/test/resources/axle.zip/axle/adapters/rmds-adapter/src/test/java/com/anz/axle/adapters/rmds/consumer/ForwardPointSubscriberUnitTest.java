package com.anz.axle.adapters.rmds.consumer;

import com.anz.axle.adapters.rmds.ItemBuilder;
import com.anz.axle.adapters.rmds.consumer.filtering.MaturityFilter;
import com.anz.axle.common.domain.CurrencyBuilder;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.Decimal;
import com.anz.axle.common.domain.Tenor;
import com.anz.axle.datafabric.client.config.CurrencyPairService;
import com.anz.axle.datafabric.client.config.GeneralConfigDAO;
import com.anz.axle.datafabric.client.pricing.ForwardPointsQuotePageDAO;
import com.anz.axle.perf.PerformanceService;
import com.anz.axle.perf.StopWatch;
import com.anz.axle.pricing.ForwardPointsQuotePage;
import com.anz.axle.pricing.Quote;
import com.anz.axle.spdee.dealing.QuotePriceType;
import com.anz.markets.adapters.trep.Item;
import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.hamcrest.TypeSafeMatcher;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static com.google.common.collect.Iterables.find;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

@RunWith(MockitoJUnitRunner.class)
public class ForwardPointSubscriberUnitTest {

    private final DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMM yyyy");

    private ForwardPointSubscriber subscriber;
    private static final Function<ForwardPointsQuotePage, Tenor> FORWARD_POINTS_QUOTE_PAGE_TENOR_FUNCTION = new Function<ForwardPointsQuotePage, Tenor>() {
        @Override
        public Tenor apply(final ForwardPointsQuotePage forwardPointsQuotePage) {
            return forwardPointsQuotePage.getTenor();
        }
    };

    private Item createDummyItem(String name) {
        return new ItemBuilder(name)
            .withField(D3ForwardQuote.BID, "1.23")
            .withField(D3ForwardQuote.ASK, "1.25")
            .withField(D3ForwardQuote.MATURITY, "15 APR 2013")
            .withField(D3ForwardQuote.SPOT_DATE, "13 APR 2013")
            .withField(D3ForwardQuote.STATUS, D3ForwardQuote.TRADEABLE)
            .withField(D3ForwardQuote.INSTRUMENT, "AUDUSD")
            .build();
    }


    private ForwardPointsQuotePageFactory forwardPointsQuotePageFactory;

    @Mock
    private PerformanceService performanceService;

    @Mock
    private ForwardPointsQuotePageDAO forwardPointsQuotePageDAO;

    @Mock
    private CurrencyPairService currencyPairService;

    @Mock
    private GeneralConfigDAO generalConfigDAO;

    @Mock
    private StopWatch stopWatch;

    @Before
    public void setup() {
        forwardPointsQuotePageFactory = new ForwardPointsQuotePageFactory(currencyPairService);
        subscriber = new ForwardPointSubscriber();
        subscriber.setPerformanceService(performanceService);
        subscriber.setGeneralConfigDAO(generalConfigDAO);
        subscriber.setMaturityFilter(new MaturityFilter());
        subscriber.setForwardPointsQuotePageDAO(forwardPointsQuotePageDAO);
        subscriber.setForwardPointsQuotePageFactory(forwardPointsQuotePageFactory);

        when(performanceService.start()).thenReturn(stopWatch);
        configureToPublishTrepSpotForwardPoint(true);

        when(currencyPairService.findbySymbol("USD/KR1")).thenReturn(CurrencyPair.currencyPairFollowingConvention(CurrencyBuilder.USD, CurrencyBuilder.KR1));
        when(currencyPairService.findbySymbol("AUD/USD")).thenReturn(CurrencyPair.currencyPairFollowingConvention(CurrencyBuilder.AUD, CurrencyBuilder.USD));
    }

    @Test
    public void should_generate_non_zero_wholesaleSpot_when_processing_spot_update_for_non_deliverable_currency() {
        configureToPublishTrepSpotForwardPoint(true);

        final ItemBuilder spotBuilder = ItemBuilder.forSpot("KR1=D3", "USDKR1", "15 AUG 2013")
                .withField("BID","0.04")
                .withField("ASK", "0.05")
                .withField("GEN_TEXT16","LIVE")
                .withField("TIMACT","01:35");

        //when
        subscriber.onUpdate(spotBuilder.build());

        final ArgumentCaptor<ForwardPointsQuotePage> forwardPointsQuotePageArgumentCaptor = ArgumentCaptor.forClass(ForwardPointsQuotePage.class);
        verify(forwardPointsQuotePageDAO, times(1)).save(forwardPointsQuotePageArgumentCaptor.capture());


        final ForwardPointsQuotePage quotePage = forwardPointsQuotePageArgumentCaptor.getValue();
        assertThat(quotePage.getTenor(), equalTo(Tenor.SPOT));
        assertThat(quotePage.getQuotes().size(), equalTo(2));

        final Quote forwardPointQuote = find(quotePage.getQuotes(), byQuotePriceType(QuotePriceType.FORWARD_POINTS));
        assertThat(forwardPointQuote.getBidPrice(), equalTo(Decimal.ZERO));
        assertThat(forwardPointQuote.getAskPrice(), equalTo(Decimal.ZERO));


        final Quote wholesaleSpotQuote = find(quotePage.getQuotes(), byQuotePriceType(QuotePriceType.WHOLESALE_SPOT_PRICE));
        assertThat(wholesaleSpotQuote.getBidPrice(), equalTo(Decimal.valueOf("0.04")));
        assertThat(wholesaleSpotQuote.getAskPrice(), equalTo(Decimal.valueOf("0.05")));
    }

    @Test
    public void should_not_generate_wholesaleSpot_when_configured_not_to_publish_trep_spot_forward_point() {
        configureToPublishTrepSpotForwardPoint(false);

        // and receive non spot update
        final ItemBuilder spotBuilder = ItemBuilder.forSpot("KR1=D3", "USDKR1", "15 AUG 2013")
                .withField("BID","0.04")
                .withField("ASK", "0.05")
                .withField("GEN_TEXT16","LIVE")
                .withField("TIMACT","01:35");

        //when
        subscriber.onUpdate(spotBuilder.build());

        verify(forwardPointsQuotePageDAO, times(0)).save(org.mockito.Matchers.any(ForwardPointsQuotePage.class));
    }

    @Test
    public void should_not_generate_wholesaleSpot_when_processing_spot_update_for_deliverable_currency() {
        configureToPublishTrepSpotForwardPoint(true);

        // and receive non spot update
        final ItemBuilder spotBuilder = ItemBuilder.forSpot("AUD=D3", "AUDUSD", "15 AUG 2013")
                .withField("BID","0.04")
                .withField("ASK", "0.05")
                .withField("GEN_TEXT16","LIVE")
                .withField("TIMACT","01:35");

        // and we process the update
        subscriber.onUpdate(spotBuilder.build());

        final ArgumentCaptor<ForwardPointsQuotePage> forwardPointsQuotePageArgumentCaptor = ArgumentCaptor.forClass(ForwardPointsQuotePage.class);
        verify(forwardPointsQuotePageDAO, times(1)).save(forwardPointsQuotePageArgumentCaptor.capture());


        final ForwardPointsQuotePage quotePage = forwardPointsQuotePageArgumentCaptor.getValue();
        assertThat(quotePage.getTenor(), equalTo(Tenor.SPOT));
        assertThat(quotePage.getQuotes().size(), equalTo(1));

        final Quote forwardPointQuote = find(quotePage.getQuotes(), byQuotePriceType(QuotePriceType.FORWARD_POINTS));
        assertThat(forwardPointQuote.getBidPrice(), equalTo(Decimal.ZERO));
        assertThat(forwardPointQuote.getAskPrice(), equalTo(Decimal.ZERO));
    }

    @Test
    public void test_when_forwardPoints_and_zero_wholesaleSpot_should_be_generated() {
        configureToPublishTrepSpotForwardPoint(false);

        // and receive non spot update
        final ItemBuilder overnightBuilder = new ItemBuilder("KR11M=D3")
                .withField("GV1_DATE","10 AUG 2013")
                .withField("BID","0.04")
                .withField("GEN_TEXT16","LIVE")
                .withField("MATUR_DATE","15 AUG 2013")
                .withField("TIMACT","01:35")
                .withField("GV1_TEXT","USDKR1")
                .withField("ASK", "0.05");

        // and we process the update
        subscriber.onUpdate(overnightBuilder.build());

        // should save two forward point quote page
        final ArgumentCaptor<ForwardPointsQuotePage> forwardPointsQuotePageArgumentCaptor = ArgumentCaptor.forClass(ForwardPointsQuotePage.class);
        verify(forwardPointsQuotePageDAO, times(2)).save(forwardPointsQuotePageArgumentCaptor.capture());


        final List<ForwardPointsQuotePage> quotePages = forwardPointsQuotePageArgumentCaptor.getAllValues();
        {
            // the normal forward point quote page
            final ForwardPointsQuotePage quotePage = Iterables.find(quotePages, byTenor(Tenor.ONE_MONTH));
            assertThat(quotePage.getQuotes().size(), equalTo(1));
            assertThat(quotePage.getQuotes().get(0).getBidPrice(), equalTo(Decimal.valueOf("0.04")));
            assertThat(quotePage.getQuotes().get(0).getAskPrice(), equalTo(Decimal.valueOf("0.05")));
        }
        {
            // and the zero spot
            final ForwardPointsQuotePage quotePage = Iterables.find(quotePages, byTenor(Tenor.SPOT));
            assertThat(quotePage.getQuotes().size(), equalTo(1));
            assertThat(quotePage.getQuotes().get(0).getBidPrice(), equalTo(Decimal.ZERO));
            assertThat(quotePage.getQuotes().get(0).getAskPrice(), equalTo(Decimal.ZERO));
        }
    }

    @Test
    public void testMalformedCurrency() {
        final String itemName = "CADTN=D3";

        Item item = createDummyItem(itemName);
        item.getFields().put("GV1_TEXT", "0");
        subscriber.onUpdate(item);

        verify(forwardPointsQuotePageDAO, times(0)).save(org.mockito.Matchers.isA(ForwardPointsQuotePage.class));
        verify(stopWatch).stop("rmds.update.exception", itemName);
    }

    @Test
    public void testCreateCurveCache() {
        final String itemName = "AUD1M=D3";

        assertEquals(0, subscriber.getCurves().size());

        //when
        subscriber.onUpdate(createDummyItem(itemName));

        //then
        assertEquals(1, subscriber.getCurves().size());
        assertTrue(subscriber.getCurves().containsKey("AUD/USD"));

        final ArgumentCaptor<ForwardPointsQuotePage> forwardPointsQuotePageArgumentCaptor = ArgumentCaptor.forClass(ForwardPointsQuotePage.class);
        verify(forwardPointsQuotePageDAO, times(2)).save(forwardPointsQuotePageArgumentCaptor.capture());

        final List<Tenor> allSavedTenors = Lists.transform(forwardPointsQuotePageArgumentCaptor.getAllValues(), FORWARD_POINTS_QUOTE_PAGE_TENOR_FUNCTION);
        assertThat(allSavedTenors, Matchers.contains(Tenor.ONE_MONTH, Tenor.SPOT));
        verify(stopWatch).stop("rmds.update.success", itemName);
    }

    @Test
    public void testCalculatePreSpot() {
        configureToPublishTrepSpotForwardPoint(false);
        final ItemBuilder overnightBuilder = new ItemBuilder("EURON=D3")
                .withField("GV1_DATE","19 AUG 2013")
                .withField("BID","0.04")
                .withField("GEN_TEXT16","LIVE")
                .withField("MATUR_DATE","15 AUG 2013")
                .withField("TIMACT","01:35")
                .withField("GV1_TEXT","EURUSD")
                .withField("ASK", "0.05");
        Item ON = overnightBuilder.build();

        final ItemBuilder tomNextBuilder = new ItemBuilder("EURTN=D3")
                .withField("GV1_DATE","19 AUG 2013")
                .withField("BID","0.14")
                .withField("GEN_TEXT16","LIVE")
                .withField("MATUR_DATE","16 AUG 2013")
                .withField("TIMACT","01:20")
                .withField("GV1_TEXT","EURUSD")
                .withField("ASK", "0.15");

        Item TN = tomNextBuilder.build();

        subscriber.onUpdate(ON);
        subscriber.onUpdate(TN);

        // Bump the dates
        ON = overnightBuilder.withField("MATUR_DATE", "16 AUG 2013").build();
        TN = tomNextBuilder.withField("MATUR_DATE", "17 AUG 2013").build();

        subscriber.onUpdate(ON);
        subscriber.onUpdate(TN);


        final ArgumentCaptor<ForwardPointsQuotePage> forwardPointsQuotePageArgumentCaptor = ArgumentCaptor.forClass(ForwardPointsQuotePage.class);
        verify(forwardPointsQuotePageDAO, times(14)).save(forwardPointsQuotePageArgumentCaptor.capture());

        final List<ForwardPointsQuotePage> allSavedForwardPointQuotePage = forwardPointsQuotePageArgumentCaptor.getAllValues();
        final Matcher<Iterable<ForwardPointsQuotePage>> matcher = Matchers.hasItems(
                // save O/N
                TenorMaturityMatcher.matchesMaturity(Tenor.OVERNIGHT, formatter.parseLocalDate("15 AUG 2013")),
                // save spot
                TenorMaturityMatcher.matchesMaturity(Tenor.SPOT, formatter.parseLocalDate("19 AUG 2013")),

                // save T/N
                TenorMaturityMatcher.matchesMaturity(Tenor.TOM_NEXT, formatter.parseLocalDate("16 AUG 2013")),
                // save TODAY
                TenorMaturityMatcher.matchesMaturity(Tenor.TODAY, formatter.parseLocalDate("15 AUG 2013")),
                // save TOM
                TenorMaturityMatcher.matchesMaturity(Tenor.TOM, formatter.parseLocalDate("16 AUG 2013")),
                // save spot
                TenorMaturityMatcher.matchesMaturity(Tenor.SPOT, formatter.parseLocalDate("19 AUG 2013")),

                // save O/N
                TenorMaturityMatcher.matchesMaturity(Tenor.OVERNIGHT, formatter.parseLocalDate("16 AUG 2013")),
                // save SPOT
                TenorMaturityMatcher.matchesMaturity(Tenor.SPOT, formatter.parseLocalDate("19 AUG 2013")),
                // save TOM (with the previous date)
                TenorMaturityMatcher.matchesMaturity(Tenor.TOM, formatter.parseLocalDate("16 AUG 2013")),
                // save TODAY (with the new date)
                TenorMaturityMatcher.matchesMaturity(Tenor.TODAY, formatter.parseLocalDate("16 AUG 2013")),

                // save T/N
                TenorMaturityMatcher.matchesMaturity(Tenor.TOM_NEXT, formatter.parseLocalDate("17 AUG 2013")),
                // save spot
                TenorMaturityMatcher.matchesMaturity(Tenor.SPOT, formatter.parseLocalDate("19 AUG 2013")),
                // save TOM (with the previous date)
                TenorMaturityMatcher.matchesMaturity(Tenor.TOM, formatter.parseLocalDate("17 AUG 2013")),
                // save TODAY (with the new date)
                TenorMaturityMatcher.matchesMaturity(Tenor.TODAY, formatter.parseLocalDate("16 AUG 2013"))
        );
        assertThat(allSavedForwardPointQuotePage, matcher);
    }

    static class TenorMaturityMatcher extends TypeSafeMatcher<ForwardPointsQuotePage> {
        private final LocalDate maturity;
        private final Tenor tenor;
        public TenorMaturityMatcher(Tenor tenor, LocalDate maturity) {
            this.tenor = tenor;
            this.maturity = maturity;
        }

        @Factory
        public static <T> Matcher<ForwardPointsQuotePage> matchesMaturity(final Tenor tenor, final LocalDate maturity) {
            return new TenorMaturityMatcher(tenor, maturity);
        }

        @Override
        protected boolean matchesSafely(ForwardPointsQuotePage item) {
            return (item != null && item.getTenor() == tenor && item.getTenorDate().equals(maturity));
        }

        @Override
        public void describeTo(Description description) {
            description.appendText("matches tenor " + tenor + " and maturity " + maturity);
        }
    }


    private static Predicate<Quote> byQuotePriceType(final QuotePriceType quotePriceType) {
        return new Predicate<Quote>() {
            @Override
            public boolean apply(final Quote quote) {
                return quote.getQuotePriceType() == quotePriceType;
            }
        };
    }

    private static Predicate<ForwardPointsQuotePage> byTenor(final Tenor tenor) {
        return new Predicate<ForwardPointsQuotePage>() {
            @Override
            public boolean apply(final ForwardPointsQuotePage forwardPointsQuotePage) {
                return forwardPointsQuotePage.getTenor() == tenor;
            }
        };
    }

    private void configureToPublishTrepSpotForwardPoint(final boolean value) {
        when(generalConfigDAO.shouldPublishTrepSpotForwardPoint()).thenReturn(value);
    }
}


