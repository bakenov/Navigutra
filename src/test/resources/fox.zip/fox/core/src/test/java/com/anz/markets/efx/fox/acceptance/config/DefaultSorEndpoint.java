package com.anz.markets.efx.fox.acceptance.config;

import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Function;

import com.anz.markets.efx.fox.acceptance.api.SorEndpoint;
import com.anz.markets.efx.fox.codec.pojo.model.SorMessage;
import com.anz.markets.efx.trading.codec.pojo.model.Heartbeat;
import com.anz.markets.efx.trading.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.trading.codec.pojo.model.NewOrderSingle;
import com.anz.markets.efx.trading.codec.pojo.model.OrderCancelRequest;
import com.anz.markets.efx.trading.codec.pojo.model.TradingMessage;

public class DefaultSorEndpoint implements SorEndpoint {
    private final Function<String, Queue<TradingMessage>> tradingQueueLookup;
    private final Function<String, Queue<SorMessage>> sorQueueLookup;
    private final String tradingRequestTopicName;
    private final String tradingResponseTopicName;
    private final String configTopicName;
    private final int source;
    private final AtomicLong sequencer;

    public DefaultSorEndpoint(final Function<String, Queue<TradingMessage>> tradingQueueLookup,
                              final Function<String, Queue<SorMessage>> sorQueueLookup,
                              final String tradingRequestTopicName,
                              final String tradingResponseTopicName,
                              final String configTopicName,
                              final int source,
                              final long sequenceSeed) {
        this.tradingQueueLookup = Objects.requireNonNull(tradingQueueLookup);
        this.sorQueueLookup = Objects.requireNonNull(sorQueueLookup);
        this.tradingRequestTopicName = Objects.requireNonNull(tradingRequestTopicName);
        this.tradingResponseTopicName = Objects.requireNonNull(tradingResponseTopicName);
        this.configTopicName = Objects.requireNonNull(configTopicName);
        this.source = source;
        this.sequencer = new AtomicLong(sequenceSeed);
    }

    @Override
    public Queue<TradingMessage> tradingRequest() {
        return tradingQueueLookup.apply(tradingRequestTopicName);
    }

    @Override
    public Queue<TradingMessage> tradingResponse() {
        return tradingQueueLookup.apply(tradingResponseTopicName);
    }

    @Override
    public Queue<SorMessage> config() {
        return sorQueueLookup.apply(configTopicName);
    }

    @Override
    public NewOrderSingle createNewOrderSingle() {
        final NewOrderSingle newOrderSingle = new NewOrderSingle(new MessageHeader(source, sequencer.incrementAndGet()), new NewOrderSingle.Body());
        newOrderSingle.body.messageId = sequencer.get();
        newOrderSingle.body.marketId = "FOX";

        return newOrderSingle;
    }

    @Override
    public OrderCancelRequest createOrderCancelRequest() {
        final OrderCancelRequest orderCancelRequest = new OrderCancelRequest(new MessageHeader(source, sequencer.incrementAndGet()), new OrderCancelRequest.Body());
        orderCancelRequest.body.messageId = sequencer.get();
        orderCancelRequest.body.marketId = "FOX";
        return orderCancelRequest;
    }

    @Override
    public Heartbeat createHeartbeat() {
        final Heartbeat heartbeat = new Heartbeat(new MessageHeader(source, sequencer.incrementAndGet()), new Heartbeat.Body());
        heartbeat.body.messageId = sequencer.get();
        return heartbeat;
    }
}
