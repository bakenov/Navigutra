package com.anz.markets.prophet.chronicle.legacychronicle;

import com.anz.markets.prophet.chronicle.ChronicleObjectReader;
import com.anz.markets.prophet.chronicle.api.ProphetReader;
import com.anz.markets.prophet.chronicle.config.ReaderConfig;
import com.anz.markets.prophet.chronicle.config.StartAt;
import com.anz.markets.prophet.chronicle.config.WaitStrategy;
import com.anz.markets.prophet.status.Context;
import com.anz.markets.prophet.tools.ToolsCommon;
import com.anz.markets.efx.ngaro.core.GcFriendlyAssert;
import com.google.common.base.Throwables;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

/**
 * Coordinates multiple ChronicleReaders to read from multiple chronicles ensuring that only one is open
 * at a time, and we never re-read an event i.e. we read up to eventId X from chronicle N and then when
 * we switch to chronicle N+1, we start reading events from X+1
 **/
public class LegacyChronicleReaderMulti implements ProphetReader {
    protected static final Logger LOGGER = LogManager.getLogger(LegacyChronicleReaderMulti.class);
    private final String[] chronicleInPaths;
    private final ChronicleObjectReader objectReader;
    private final ReaderConfig baseConfig;
    private volatile LegacyChronicleReader activeLegacyChronicleReader;
    private volatile boolean closed = false;

    private LegacyChronicleReaderMulti(final String[] chronicleInPaths,
                                       final ChronicleObjectReader objectReader,
                                       final ReaderConfig baseConfig) {
        GcFriendlyAssert.isTrue(chronicleInPaths.length < 3, "needs more work for > 2");
        this.chronicleInPaths = chronicleInPaths;
        this.objectReader = objectReader;
        this.baseConfig = baseConfig;
    }

    @Override
    public void run() {
        try {
            final LegacyChronicleReaderConfigBuilder configReaderBuilder0 = new LegacyChronicleReaderConfigBuilder(new LegacyChronicleReaderConfig(baseConfig, chronicleInPaths[0])).
                    setWaitStrategy(WaitStrategy.STOP_ON_STALL);
            activeLegacyChronicleReader = new LegacyChronicleReader(objectReader, configReaderBuilder0.createChronicleConfigReader());
            activeLegacyChronicleReader.run();
            activeLegacyChronicleReader.close();
            activeLegacyChronicleReader = null;

            if (!closed) {
                final long lastEventId = Context.context().header().getEventId();
                final LegacyChronicleReaderConfigBuilder configReaderBuilder1 = new LegacyChronicleReaderConfigBuilder(new LegacyChronicleReaderConfig(baseConfig, chronicleInPaths[1])).
                        setWaitStrategy(WaitStrategy.LOG_START_MESSAGE).
                        // seek to same eventId that we are currently at then...
                                setStartAt(StartAt.EVENTID).
                                setStartPosition(lastEventId).
                        // ...set the filter to ignore that eventId and start at the next one. This ensures that we "hand off" at exactly the same eventid
                                setHeaderFilter(new ToolsCommon.EventIdPredicate(new ToolsCommon.Range(lastEventId), true, false));


                // can keep a single reader, will automatically switch from one rollover file to another under the hood. see: LegacyChronicleReader.
                activeLegacyChronicleReader = new LegacyChronicleReader(objectReader, configReaderBuilder1.createChronicleConfigReader());
                activeLegacyChronicleReader.run();
                activeLegacyChronicleReader.close();
                activeLegacyChronicleReader = null;
            }
        } catch (Throwable e) {
            LOGGER.error("Could not create LegacyChronicleReader", e);
            throw Throwables.propagate(e);
        }
    }

    @Override
    public void close() throws IOException {
        LOGGER.info("Closing");
        this.closed = true;
        if (activeLegacyChronicleReader != null) {
            activeLegacyChronicleReader.close();
        }
    }

    public static ProphetReader create(final String[] chronicleInPaths,
                                       final ChronicleObjectReader objectReader,
                                       final ReaderConfig baseConfig) throws IOException {
        if (chronicleInPaths.length == 1) {
            final LegacyChronicleReaderConfigBuilder configReaderBuilder = new LegacyChronicleReaderConfigBuilder(new LegacyChronicleReaderConfig(baseConfig, chronicleInPaths[0])).setWaitStrategy(WaitStrategy.LOG_START_MESSAGE);
            return new LegacyChronicleReader(objectReader, configReaderBuilder.createChronicleConfigReader());
        } else {
            return new LegacyChronicleReaderMulti(chronicleInPaths, objectReader, baseConfig);
        }
    }
}
