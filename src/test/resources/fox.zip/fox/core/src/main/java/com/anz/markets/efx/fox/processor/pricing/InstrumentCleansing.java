package com.anz.markets.efx.fox.processor.pricing;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.anz.markets.efx.fox.api.domain.Instrument;
import com.anz.markets.efx.fox.api.domain.VenueInstrument;

public class InstrumentCleansing implements Consumer<Instrument> {
    private static final Predicate<VenueInstrument> ALL = venueInstrument -> true;
    private final Consumer<VenueInstrument> cleansingRules;

    public InstrumentCleansing(final Consumer<VenueInstrument> cleansingRules) {
        this.cleansingRules = Objects.requireNonNull(cleansingRules);
    }

    @Override
    public void accept(final Instrument instrument) {
        instrument.forEach(ALL, cleansingRules);
    }
}
