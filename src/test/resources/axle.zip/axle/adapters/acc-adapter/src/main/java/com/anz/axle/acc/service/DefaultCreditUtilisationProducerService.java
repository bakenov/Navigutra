package com.anz.axle.acc.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anz.axle.acc.dao.CreditUtilisationDAO;
import com.anz.axle.common.dao.CounterpartyDAO;
import com.anz.axle.common.dao.CurrencyHibernateDAO;
import com.anz.axle.common.dao.CurrencyPairHibernateDAO;
import com.anz.axle.common.dao.VenueDao;
import com.anz.axle.common.domain.Counterparty;
import com.anz.axle.common.domain.CounterpartyCreditUtilisation;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;
import com.anz.axle.common.domain.CurrencyPair;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditState;
import com.anz.axle.common.domain.CurrentVenueCurrencyCreditStates;
import com.anz.axle.common.domain.Venue;
import com.anz.axle.datafabric.client.date.FXDateService;
import static com.anz.axle.common.util.LateFormatter.format;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * @author jonesr18
 */
@Transactional(readOnly = true)
@Service("defaultCreditUtilisationProducerService")
public class DefaultCreditUtilisationProducerService implements CreditUtilisationProducerService {

    private static final Logger LOG = Logger.getLogger(DefaultCreditUtilisationProducerService.class);

    @Autowired
    private CreditUtilisationDAO creditUtilisationDao = null;

    @Autowired
    private CounterpartyDAO counterpartyDao = null;

    @Autowired
    private FXDateService fxDateService = null;

    @Autowired
    private CurrencyPairHibernateDAO currencyPairDAO = null;

    @Autowired
    private CurrencyHibernateDAO currencyHibernateDAO = null;

    @Autowired
    private VenueDao venueDAO = null;

    /**
     * This method provides a summary view of CreditUtilisingTrade entities since the start date
     * parameter (representing the earliest spot date). It will summarise the utilisation in usd
     * for each spot date+counterparty credit pool in trades that it finds. It will only include
     * trades eligible for utilisation, ie actual trades that are completed. The underlying
     * view that this summary is drawn from must exclude generated trades that would otherwise
     * have eligible properties to be included here.
     *
     * @param startSpotDate - the earliest spot date.
     * @return CounterpartySpotDateCreditUtilisations for each spot date + credit pool where trades
     * are found.
     */
    public CounterpartyCreditUtilisations findCounterpartySpotDateCreditUtilisationsSince(LocalDate startSpotDate) {
        List<Counterparty> counterparties = counterpartyDao.findCreditLimitedCounterparties();
        return creditUtilisationDao.getCounterpartySpotDateCreditUtilisations(startSpotDate, counterparties);
    }

    /**
     * This method provides the caller with a list of CurrentVenueCurrencyCreditState objects. Each of these
     * represents a currency pair+venue+spot date with information on any current credit breach that may
     * have occurred for this venue, if at all. For instance, if Barclays has exceeded it's credit limit for a
     * particular spot date, this list would contain CurrentVenueCurrencyCreditState objects for each of the tradeable
     * currency pairs that would settle on that date if a trade were done during the current trade date on Barclays.
     *
     * The method returns a CurrentVenueCurrencyCreditState for each trading venue for each currency pair, as different
     * currency pairs will settle on different dates. Some of these may include breaches, some may not, depending
     * on the state of the venue for that currency's settlement date. The Trade Date used in determing the spot date
     * is based on now via new DateTime().
     *
     * These records are only generated for all trading venues.
     *
     * If a venue has had no trading, ie no current utilisation for a CCY pairs settlement date,
     * a CurrentVenueCurrencyCreditState is still provided. This could cause issues if the current
     * credit configuration is enabled, but has a zero credit limit. In such a case it is assumed that the
     * credit monitoring will instead be disabled.
     *
     * The parameter 'start' represents the date from which trades are to be included - based on their spot date.
     * ie it is the earliest spot date to be included for calculations. This value should be sufficiently
     * historic to cover the current trading date which may be -+1 day depending on the pair.
     *
     * This method is meant to inform the trading system of venue+currency pair status for current trading.
     */
    public CurrentVenueCurrencyCreditStates findCurrentVenueCurrencyCreditStatesSince(LocalDate startSpotDate) {
        CounterpartyCreditUtilisations utilisations = findCounterpartySpotDateCreditUtilisationsSince(startSpotDate);
        Collection<CurrencyPair> currencyPairs = currencyPairDAO.findAllAxleTraded();
        Collection<Venue> tradingVenues = venueDAO.findTradingVenues();

        Collection<CurrentVenueCurrencyCreditState> states = new ArrayList<CurrentVenueCurrencyCreditState>();

        for(CurrencyPair pair : currencyPairs) {
            LocalDate currentPairTradeDate = fxDateService.getTradeDate(pair, new DateTime());
            LocalDate currentPairSpotDate = fxDateService.getSpotDate(currentPairTradeDate, pair);
            LOG.debug(format("Currency Pair [%s][CURRENT TRADE DATE: %s][CURRENT SPOT DATE: %s]", pair.getSymbol(), currentPairTradeDate, currentPairSpotDate));

            for(Venue venue : tradingVenues) {
                CounterpartyCreditUtilisation utilisation = utilisations.findFor(currentPairSpotDate, venue);
                CurrentVenueCurrencyCreditState state = null;
                if(utilisation != null) {
                    Double utilisationPercentage = utilisation.getUtilisationPercentage();
                    state = new CurrentVenueCurrencyCreditState(utilisation.getCreditUtilisationIsBreached(), pair,
                                venue, currentPairTradeDate, currentPairSpotDate, utilisationPercentage);
                } else {
                    state = new CurrentVenueCurrencyCreditState(false, pair, venue,
                                currentPairTradeDate, currentPairSpotDate, 0.0d);
                }
                states.add(state);
            }
        }
        return new CurrentVenueCurrencyCreditStates(states);
    }

    public void setFxDateService(FXDateService fxDateService) {
        this.fxDateService = fxDateService;
    }

    public void setCurrencyPairDAO(CurrencyPairHibernateDAO currencyPairDAO) {
        this.currencyPairDAO = currencyPairDAO;
    }

    public void setCurrencyHibernateDAO(CurrencyHibernateDAO currencyHibernateDAO) {
        this.currencyHibernateDAO = currencyHibernateDAO;
    }

    public void setVenueDAO(VenueDao venueDAO) {
        this.venueDAO = venueDAO;
    }

    public void setCreditUtilisationDAO(CreditUtilisationDAO creditUtilisationDao) {
        this.creditUtilisationDao = creditUtilisationDao;
    }

    public void setCounterpartyDAO(CounterpartyDAO counterpartyDAO) {
        this.counterpartyDao = counterpartyDAO;
    }
}
