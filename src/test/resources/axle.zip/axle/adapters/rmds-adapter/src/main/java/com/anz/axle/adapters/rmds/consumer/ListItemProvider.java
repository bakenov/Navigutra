package com.anz.axle.adapters.rmds.consumer;

import java.util.ArrayList;
import java.util.List;

import com.anz.markets.adapters.trep.consumer.ItemNameProvider;

/**
 * {@link ItemProvider} implementation that just provides
 * a predefined list of items
 * @author winstonr
 *
 */
public class ListItemProvider implements ItemNameProvider {
    
    private List<String> items = new ArrayList<String>();

    public void setItems(List<String> items) {
        this.items = items;
    }
    
    @Override
    public List<String> getItems() {
        return items;
    }
}
