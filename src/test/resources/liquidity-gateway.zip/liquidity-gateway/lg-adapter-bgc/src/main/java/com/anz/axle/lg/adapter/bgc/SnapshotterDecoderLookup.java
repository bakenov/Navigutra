package com.anz.axle.lg.adapter.bgc;

import com.anz.markets.efx.pricing.codec.api.RefreshHandler;
import com.anz.markets.efx.pricing.codec.snapshot.state.RequestKey;

public interface SnapshotterDecoderLookup {

    SnapshotterDecoderSupplier lookup(RefreshHandler.Body body);
    SnapshotterDecoderSupplier lookup(RequestKey requestKey);
}
