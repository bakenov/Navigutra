package com.anz.axle.acc.job;

import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;
import org.joda.time.LocalDate;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

import com.anz.axle.acc.domain.BusinessLocalDate;
import com.anz.axle.acc.service.CreditUtilisationConsumerService;
import com.anz.axle.acc.service.CreditUtilisationProducerService;
import com.anz.axle.common.domain.CounterpartyCreditUtilisations;

/**
 * <p>Copyright (c) 2010, ANZ Banking Group Limited</p>
 *
 * <p>This job provides the consuming {@link com.anz.axle.acc.service.CreditUtilisationConsumerService} with a snapshot
 * view of counterparty credit utilisations over a range of spot dates. It will include credit
 * utilisations covering spot dates in the past and the future. These snapshots are only
 * provided for credit limited counterparties (venues).</p>
 *
 * These snapshots are generated to reflect the state of each {@link com.anz.axle.common.domain.CounterpartyCreditPool}
 * over a range of spot dates.
 *
 * <p>The {@link CurrentCounterpartyCreditUtilisationJobListener} allows for
 * {@link com.anz.axle.common.domain.CounterpartyCreditUtilisations} to be detected and used in
 * some way.</p>
 *
 * @author jonesr18
 */
@Component("currentCounterpartyCreditUtilisationJob")
public class CurrentCounterpartyCreditUtilisationJob extends AbstractRecoverableJob implements Runnable {

    private static final Logger LOG = Logger.getLogger(CurrentCounterpartyCreditUtilisationJob.class);

    @Autowired
    @Qualifier("defaultCreditUtilisationProducerService")
    private CreditUtilisationProducerService creditUtilisationProducerService = null;

    @Autowired
    @Qualifier("datafabricCreditUtilisationConsumerService")
    private CreditUtilisationConsumerService creditUtilisationConsumerService = null;

    @Autowired
    @Qualifier ("doNothingCurrentCounterpartyCreditUtilisationJobListener")
    private CurrentCounterpartyCreditUtilisationJobListener listener = null;

    @Autowired
    @Qualifier("scheduler")
    private SchedulerFactoryBean schedulerFactory = null;

    /**
     * This property represents the number of days back trades should be used for
     * spot date utilisation. It should be sufficiently historic to cover past spot
     * dates.
     */
    private volatile int businessDaysBack = 10;
    
    private static final String TRIGGER_NAME = "currentCounterpartyCreditUtilisationJobTrigger";

    private AtomicLong runCount = new AtomicLong(0l);

    @Override
    public void run() {
        if(runCount.incrementAndGet() % 30 == 0) {
            LOG.info("running...");
        }
        LocalDate sinceWhen = new BusinessLocalDate(new LocalDate()).rollBack(businessDaysBack).getDate();
        LOG.info("Start Current Counterparty Credit Utilisation job [since:" + sinceWhen + "]...");
        try {
            CounterpartyCreditUtilisations utilisations = creditUtilisationProducerService.findCounterpartySpotDateCreditUtilisationsSince(sinceWhen);
            if(creditUtilisationConsumerService.consume(utilisations)) {
                listener.listen(utilisations);
                awake();
            } else {
                sleep();
                LOG.error("Consumer service responded without success - no exception.");
            }
        } catch (Throwable th) {
            try {
                sleep();
            } catch (SchedulerException e) {
                LOG.error("There was a problem pausing the trigger after an exception", e);
            } finally {
                LOG.error("There was an issue sending data to the consumer service.", th);
            }
        } finally {
            LOG.info("Current Counterparty Credit Utilisation job completed");
        }
    }

    /**
     * For testing only.
     * @param creditUtilisationProducerService
     */
    protected void setCreditUtilisationProducerService(CreditUtilisationProducerService creditUtilisationProducerService) {
        this.creditUtilisationProducerService = creditUtilisationProducerService;
    }

    /**
     * For testing only.
     * @param listener
     */
    protected void setListener(CurrentCounterpartyCreditUtilisationJobListener listener) {
        this.listener = listener;
    }

    /**
     * For testing only.
     * @param consumerService
     */
    protected void setCreditUtilisationConsumerService(CreditUtilisationConsumerService consumerService) {
        this.creditUtilisationConsumerService = consumerService;
    }

    /**
     * For testing only.
     * @param schedulerFactory
     */
    protected void setSchedulerFactory(SchedulerFactoryBean schedulerFactory) {
        this.schedulerFactory = schedulerFactory;
    }

    public void setBusinessDaysBack(int businessDaysBack) {
        this.businessDaysBack = businessDaysBack;
    }

    @Override
    public String getTriggerName() {
        return TRIGGER_NAME;
    }

    @Override
    public Scheduler getScheduler() {
        return schedulerFactory.getScheduler();
    }
}
