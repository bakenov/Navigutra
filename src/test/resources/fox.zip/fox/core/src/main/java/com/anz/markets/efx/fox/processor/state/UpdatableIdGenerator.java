package com.anz.markets.efx.fox.processor.state;

import java.util.function.LongConsumer;
import java.util.function.LongSupplier;

import org.agrona.collections.MutableLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UpdatableIdGenerator implements LongSupplier, LongConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(UpdatableIdGenerator.class);

    final MutableLong currentId = new MutableLong(1);

    @Override
    public void accept(final long value) {
        currentId.set(value);
    }

    @Override
    public long getAsLong() {
        currentId.set(currentId.value + 1);
        return currentId.get();
    }
}
