package com.anz.markets.prophet.atest.pricing._3_spread;

import com.anz.markets.prophet.atest.framework.BaseAcceptanceSpecification;
import com.anz.markets.prophet.atest.framework.RelatedTest;
import com.anz.markets.prophet.atest.framework.Requirement;
import com.anz.markets.prophet.atest.framework.Requirement.Ref;
import com.anz.markets.prophet.atest.framework.RestartBeforeTest;
import com.anz.markets.prophet.atest.framework.matcher.WholesaleBookFactorsAssert;
import com.anz.markets.prophet.config.business.domain.indexed.KeyValueConfigType;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ClientSpreadConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.ConfigurationDataDefault;
import com.anz.markets.prophet.config.business.domain.tabular.impl.KeyValueConfigImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.MaxSkewQuantities;
import com.anz.markets.prophet.config.business.domain.tabular.impl.PricingModelImpl;
import com.anz.markets.prophet.config.business.domain.tabular.impl.RiskAdjustedFactor;
import com.anz.markets.prophet.config.business.domain.tabular.impl.VolumeSkewConfig;
import com.anz.markets.prophet.domain.Currency;
import com.anz.markets.prophet.domain.Instrument;
import com.anz.markets.prophet.domain.Level;
import com.anz.markets.prophet.domain.Market;
import com.anz.markets.prophet.domain.OptimalPositionType;
import com.anz.markets.prophet.domain.PositionType;
import com.anz.markets.prophet.domain.Region;
import com.anz.markets.prophet.domain.TradingTimeZone;
import com.anz.markets.prophet.domain.clientprice.ClientPrice;
import com.anz.markets.prophet.domain.clientprice.WholesaleBookFactors;
import com.anz.markets.prophet.domain.clientprice.impl.WholesaleBookFactorsImpl;
import com.anz.markets.prophet.domain.positionrisk.OptimalPosition;
import com.anz.markets.prophet.domain.positionrisk.OptimalPositions;
import com.anz.markets.prophet.pricer.pfp.FeatureStatus;
import com.anz.markets.prophet.pricer.pfp.FeatureTraceLine;
import com.anz.markets.prophet.pricer.wholesale.spreads.RiskAdjustedSpreadStrategy;
import com.anz.markets.prophet.pricer.wholesale.spreads.VolumeSkewStrategy;
import com.google.monitoring.runtime.instrumentation.common.com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 *  short notional equiv position means we skew(decrease) Bid model spread
 *  long notional equiv position means we skew(decrease) Offer model spread
 *  results in more attractive price
 *  pi* = notional equiv position * factor
 *  Adjust each band amount(except smallest band) by pi* where Band < min(current equiv pos, Vol Limit)
 *  Given adjusted band amount, interpolate for band's model spread
 */
@RestartBeforeTest(reason = "Widening has state.")
public class ModelSpread_Volume_Skew extends BaseAcceptanceSpecification {

    private Instrument driverPairA = Instrument.AUDUSD;
    private Instrument driverPairB = Instrument.USDJPY;

    private ConfigurationDataDefault setUpConfiguration() {

        ConfigurationDataDefault configuration = tdd.configuration_pricing_base()
                .setClientSpreadConfigs(Lists.newArrayList(
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.4),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 2.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.2),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 4.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairA, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),

                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_10M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_15M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.3),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_20M.getQty(), Region.GB).set(TradingTimeZone.LDN, 1.8),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_30M.getQty(), Region.GB).set(TradingTimeZone.LDN, 3.5),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_40M.getQty(), Region.GB).set(TradingTimeZone.LDN, 5.0),
                        new ClientSpreadConfigImpl(Market.WSP_A, driverPairB, Level.QTY_50M.getQty(), Region.GB).set(TradingTimeZone.LDN, 7.0)
                ))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.CALCULATION_DATA_COLLECTION_VERBOSE_INSTRUMENT_SET, new Instrument[] { Instrument.AUDUSD, Instrument.USDJPY}))
                .putKeyValueConfig(new KeyValueConfigImpl(KeyValueConfigType.RISK_PRICE_WIDENING_ENABLED, true))
                .setRiskAdjustedSpreadParams(Arrays.asList(
                        new RiskAdjustedFactor(0.0, 0.0),
                        new RiskAdjustedFactor(0.5, 1.25),
                        new RiskAdjustedFactor(1.0, 1.5),
                        new RiskAdjustedFactor(1.75, 2.0),
                        new RiskAdjustedFactor(2.0, 3.0),
                        new RiskAdjustedFactor(4.0, 5.0),
                        new RiskAdjustedFactor(10.0, 10.0)
                ))
                // disable Mid Skewing
                .setPricingModels(
                        Arrays.asList(
                                new PricingModelImpl().setMarket(Market.WSP_A).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_B).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_C).setStack("0.5m|0.5m|1m|1m|2m|5m|5m|5m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(0.5).setOverallMaxSkewAsProportionOfBaseSpread(0.5).setSkewPositionType(PositionType.EQUIVALENT_POSITION),
                                new PricingModelImpl().setMarket(Market.WSP_Z).setStack("1m|2m|2m|5m|5m|5m|10m|10m|10m").setSkewed(false).setMaxSkewAsProportionOfBaseSpread(Double.NaN).setOverallMaxSkewAsProportionOfBaseSpread(Double.NaN).setSkewPositionType(PositionType.NONE)
                        ));

        return configuration;
    }

    @Test
    @RelatedTest(ModelSpread_Risk_Adjusted_Spread_Factor_Test.class) //given_short_position_apply_risk_adjusted_spread_to_offer_side()
    @Requirement(value = {Ref.PRICING_AXPROPHET_1070, Requirement.Ref.PRICING_AXPROPHET_1134})
    public void short_pos_decrease_model_spread_bid_side() {
        Instrument driverPairA = Instrument.USDJPY;
        ConfigurationDataDefault configuration = setUpConfiguration();

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            configuration.setVolumeSkewConfigs(Arrays.asList(
                        new VolumeSkewConfig(Market.ANY, driverPairA, 5_001_000d, 10_000_000d, 0.15, 0.5, false)
                    ))
                    .setMaxSkewQuantities(Arrays.asList(
                            new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 7500000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7500000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.USD, 3000000.0)
                    ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.870, 0.003)); // no OP change as position=0

            prophet.clearOutputBuffer();
            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -7_700_000, 78.420)); // Trigger : position created
        }
        then:
        {
            // SHORT 5.08mio is bewteen (3.0mio MaxSkewQuantities * 1 RiskAdjustedFactor) band and
            // and (3.0mio MaxSkewQuantities * 1.75 RiskAdjustedFactor) bands.
            // Therefore apply factor(1.5) to USD base pairs
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = optimalPositionsUpdates.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == driverPairA).findFirst().get();
            assertThat(opPos.getPositionInNotional(), isRoundedTo(-5088108.5));
        }
        and:
        // Volume skew config disabled so do not apply any volume skew
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(-5088108.5));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.IMPOTENT_CONFIG_DISABLED));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.IMPOTENT_CONFIG_DISABLED));

            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_1M, 0.15, 0.225);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_3M, 0.25, 0.375);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_5M, 0.30, 0.450);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_10M, 0.4, 0.60);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_15M, 0.6, 0.90);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_20M, 0.8, 1.20);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_30M, 1.48, 2.22);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_40M, 2.08, 3.12);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_50M, 2.88, 4.32);

            assertThat(clientPrice.getBids().size(), Is.is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 103.868500, 103.872250));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 103.867000, 103.874500));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 103.866250, 103.875625));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 103.865000, 103.877500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 103.860000, 103.885000));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 103.856000, 103.891000));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 103.841600, 103.912600));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 103.831200, 103.928200));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 103.809200, 103.961200));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003));
            configuration.setVolumeSkewConfigs(Arrays.asList(
                    new VolumeSkewConfig(Market.WSP_A, driverPairA, 5_000_100d, 10_000_000d, 0.15, 0.5, true)
            ));

            prophet.receive(configuration);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.870, 0.003));
        }
        then:
        // Since USD/JPY notional equiv position is SHORT, apply skew on BID SIDE
        {
            // Notional Equiv Position = -5.0881085 mio
            // pi* = -5.0881085 * factor(0.15) =  -0.763216275 mio
            // Limit* = min(|equiv pos| 5.0881085 mio, Limit 5.0001mio) = Limit 5.0001 mio
            // Bands 3mio and 5mio adjusted by pi*(since these bands are < Limit*
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(-5088108.5));

            FeatureTraceLine ftlBid =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftlBid.bidStatus, Matchers.is(FeatureStatus.DEPTH_IMPACT));
            assertThat(ftlBid.offerStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlBid.data[0].var.toString(), is("volumeSkewBid"));
            assertThat(ftlBid.data[0].fx, is(5_000_000.0));

            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_1M, 0.15, 0.225);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_3M, 0.2118, 0.375);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_5M, 0.2809, 0.450);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_10M, 0.4, 0.60);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_15M, 0.6, 0.90);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_20M, 0.8, 1.20);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_30M, 1.48, 2.22);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_40M, 2.08, 3.12);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_50M, 2.88, 4.32);

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 103.868500, 103.872250));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 103.867572, 103.874500));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 103.866155, 103.875625));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 103.864809, 103.877500));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 103.860000, 103.885000));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 103.856000, 103.891000));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 103.841600, 103.912600));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 103.831200, 103.928200));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 103.809200, 103.961200));

            // active volume skew results in a DEPTH_IMPACT feature state, but dominant captures tob imapact - so DEPTH_IMPACT will never be registered as dominant
            assertThat(clientPrice.getDominantFeatureBid().toString(), is(WholesaleBookFactorsImpl.INIT_FEATURE_NAME));
            assertThat(clientPrice.getDominantFeatureOffer().toString(), is(RiskAdjustedSpreadStrategy.FEATURE_NAME));
        }
    }

    @Test
    @RelatedTest(ModelSpread_Risk_Adjusted_Spread_Factor_Test.class) //given_short_position_apply_risk_adjusted_spread_to_offer_side()
    @Requirement(Ref.PRICING_AXPROPHET_1070)
    public void skew_highest_band() {
        Instrument driverPairA = Instrument.USDJPY;
        ConfigurationDataDefault configuration = setUpConfiguration();

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            configuration
                    .setClientSpreadConfigs(Lists.newArrayList(
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.AUDUSD, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6),

                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_1M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.3),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_3M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.5),
                            new ClientSpreadConfigImpl(Market.WSP_A, Instrument.USDJPY, Level.QTY_5M.getQty(), Region.GB).set(TradingTimeZone.LDN, 0.6)
                    ))
                    .setVolumeSkewConfigs(Arrays.asList(
                            new VolumeSkewConfig(Market.WSP_A, driverPairA, 5_001_000d, 10_000_000d, 0.15, 0.5, true)
                    ))
                    .setMaxSkewQuantities(Arrays.asList(
                            new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 7500000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7500000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.USD, 3000000.0)
                    ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003)); // no OP change as position=0
            prophet.clearOutputBuffer();

            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, -7_700_000, 78.420)); // Trigger : position created
        }
        then:
        {
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = optimalPositionsUpdates.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == driverPairA).findFirst().get();
            assertThat(opPos.getPositionInNotional(), isRoundedTo(-5087828.7));
        }
        and:
        // Since USD/JPY notional equiv position is SHORT, apply skew on BID SIDE
        {
            // Notional Equiv Position = -5.0878287 mio
            // pi* = -5087828.7 * factor(0.15) =  -0.763174305 mio
            // Limit* = min(|equiv pos| 5.0878287 mio, Limit 5.0001mio) = Limit 5.0001 mio
            // Bands 3mio and 5mio adjusted by pi*(since these bands are < Limit*
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(-5087828.7));

            FeatureTraceLine ftlBid =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftlBid.bidStatus, Matchers.is(FeatureStatus.DEPTH_IMPACT));
            assertThat(ftlBid.offerStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlBid.data[0].var.toString(), is("volumeSkewBid"));
            assertThat(ftlBid.data[0].fx, is(5_000_000.0));

            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_1M, 0.15, 0.225);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_3M, 0.2118, 0.375);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_5M, 0.2809, 0.450);
        }
    }

    @Test
    @RelatedTest(ModelSpread_Risk_Adjusted_Spread_Factor_Test.class) // given_long_position_apply_risk_adjusted_spread_to_bid_side()
    @Requirement(value = {Ref.PRICING_AXPROPHET_1070, Ref.PRICING_AXPROPHET_1134})
    public void long_pos_decrease_model_spread_offer_side() {
        Instrument driverPairA = Instrument.AUDUSD;
        ConfigurationDataDefault configuration = setUpConfiguration();

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            configuration.setVolumeSkewConfigs(Arrays.asList(
                    new VolumeSkewConfig(Market.WSP_A, driverPairA, 7_000_000d, 5_000_100d, 0.15, 0.5, false)
            ))
                    .setMaxSkewQuantities(Arrays.asList(
                            new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 3000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.USD, 7000000.0)
                    ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003)); // no OP change as position=0

            // this test sets up a Biased position instead of a client trade:
            // prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 5_000_000, 78.420));
            prophet.receive(tdd.biasPosition(Currency.AUD, -4822047.7));
        }
        then:
        {
            // LONG 4.82mio is between (3.0mio MaxSkewQuantities * 1 RiskAdjustedFactor) band and
            // and (3.0mio MaxSkewQuantities * 1.75 RiskAdjustedFactor) bands.
            // Therefore apply factor(1.5) to AUD base pairs
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING_BIAS)).getLast();
            final OptimalPosition opPos = optimalPositionsUpdates.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == driverPairA).findFirst().get();
            assertThat(opPos.getPositionInNotional(), isRoundedTo(4822047.7));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75101, 0.00003));
        }
        then:
        // Volume skew config disabled so do not apply any Volume Skew
        {
            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(4822047.7));

            FeatureTraceLine ftl =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftl.bidStatus, Matchers.is(FeatureStatus.IMPOTENT_CONFIG_DISABLED));
            assertThat(ftl.offerStatus, Matchers.is(FeatureStatus.IMPOTENT_CONFIG_DISABLED));

            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_1M, 0.225, 0.15);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_3M, 0.375, 0.25);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_5M, 0.450, 0.30);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_10M, 0.60, 0.40);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_15M, 0.96, 0.64);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_20M, 1.32, 0.88);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_30M, 2.04, 1.36);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_40M, 2.52, 1.68);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_50M, 3.12, 2.08);

            assertThat(clientPrice.getBids().size(), Is.is(9));
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509875, 0.751025));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.750965, 0.751040));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.750954, 0.751048));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.750935, 0.751060));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.750842, 0.751122));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.750770, 0.751170));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.750662, 0.751242));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.750614, 0.751274));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.750458, 0.751378));
        }
        when:
        {
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003));
            configuration.setVolumeSkewConfigs(Arrays.asList(
                    new VolumeSkewConfig(Market.WSP_A, driverPairA, 7_000_000d, 5_000_100d, 0.15, 0.5, true),
                    new VolumeSkewConfig(Market.ANY, driverPairA, 7_000_000d, 5_000_100d, 0.25, 0.5, true)
            ));

            prophet.receive(configuration);
            prophet.clearOutputBuffer();
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75101, 0.00003));
        }
        then:
        // Since AUD/USD notional equiv position is LONG, apply skew on OFFER SIDE
        {
            // Notional Equiv Position = 4822047.7 mio
            // pi* = 4822047.7 mio * factor(0.15) =  0.723307155 mio
            // Limit* = min(equiv pos 4822047.7 mio, Limit 5.00001mio) = equiv pos 4822047.7 mio
            // Bands 3mio ONLY adjusted by pi*(since only this band is < Limit*)
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(4822047.7));

            FeatureTraceLine ftlOffer =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftlOffer.bidStatus, Matchers.is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlOffer.offerStatus, Matchers.is(FeatureStatus.DEPTH_IMPACT));
            assertThat(ftlOffer.data[0].var.toString(), is("volumeSkewOffer"));
            assertThat(ftlOffer.data[0].fx, is(3_000_000.0));

            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_1M, 0.225, 0.15);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_3M, 0.375, 0.21383);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_5M, 0.450, 0.30);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_10M, 0.60, 0.40);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_15M, 0.96, 0.64);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_20M, 1.32, 0.88);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_30M, 2.04, 1.36);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_40M, 2.52, 1.68);
            WholesaleBookFactorsAssert.assertSkewedModelSpreadAtLevel(wbf.getSpreadFactorsModel(), Level.QTY_50M, 3.12, 2.08);

            ClientPrice clientPrice = prophet.expect(ClientPrice.class, exactly(1), isClientPriceInstrument(driverPairA)).getLast();
            assertThat(clientPrice, isClientPricePoint(0, Level.QTY_1M, 0.7509875, 0.751025));
            assertThat(clientPrice, isClientPricePoint(1, Level.QTY_2M, 0.750965, 0.751035));
            assertThat(clientPrice, isClientPricePoint(2, Level.QTY_2M, 0.750954, 0.751053));
            assertThat(clientPrice, isClientPricePoint(3, Level.QTY_5M, 0.750935, 0.751060));
            assertThat(clientPrice, isClientPricePoint(4, Level.QTY_5M, 0.750842, 0.751122));
            assertThat(clientPrice, isClientPricePoint(5, Level.QTY_5M, 0.750770, 0.751170));
            assertThat(clientPrice, isClientPricePoint(6, Level.QTY_10M, 0.750662, 0.751242));
            assertThat(clientPrice, isClientPricePoint(7, Level.QTY_10M, 0.750614, 0.751274));
            assertThat(clientPrice, isClientPricePoint(8, Level.QTY_10M, 0.750458, 0.751378));
        }
    }

    @Test
    @RelatedTest(ModelSpread_Risk_Adjusted_Spread_Factor_Test.class) // given_long_position_apply_risk_adjusted_spread_to_bid_side()
    @Requirement(Ref.PRICING_AXPROPHET_1070)
    public void pos_too_small_no_skew() {
        Instrument driverPairA = Instrument.AUDUSD;
        ConfigurationDataDefault configuration = setUpConfiguration();

        given:
        {
            prophet.receive(TradingTimeZone.LDN);

            configuration.setVolumeSkewConfigs(Arrays.asList(
                    new VolumeSkewConfig(Market.WSP_A, driverPairA, 7_000_000d, 5_000_100d, 0.15, 0.5, true)
            ))
                    .setMaxSkewQuantities(Arrays.asList(
                            new MaxSkewQuantities(Market.WSP_A, Currency.AUD, 3000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.JPY, 7000000.0),
                            new MaxSkewQuantities(Market.WSP_A, Currency.USD, 7000000.0)
                    ));

            prophet.receive(configuration);
        }
        when:
        {
            prophet.receive(tdd.hourChime(13)); // Trigger : OP change new covar
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75100, 0.00003)); // no OP change as position=0
            prophet.receive(tdd.marketDataSnapshot(Instrument.USDJPY, 103.875, 0.003)); // no OP change as position=0

            prophet.receive(tdd.client_trade_001(Instrument.AUDJPY, 3_000_000, 78.420)); // Trigger : position created
        }
        then:
        {
            // LONG 4.82mio is between (3.0mio MaxSkewQuantities * 1 RiskAdjustedFactor) band and
            // and (3.0mio MaxSkewQuantities * 1.75 RiskAdjustedFactor) bands.
            // Therefore apply factor(1.5) to AUD base pairs
            final OptimalPositions optimalPositionsUpdates = prophet.expect(OptimalPositions.class, exactly(1), isOptimalPositionType(OptimalPositionType.PRICING)).getLast();
            final OptimalPosition opPos = optimalPositionsUpdates.ops.stream().filter(optimalPosition -> optimalPosition.getInstrument() == driverPairA).findFirst().get();
            assertThat(opPos.getPositionInNotional(), isRoundedTo(2893228.6));
        }
        when:
        {
            prophet.clearOutputBuffer();
            // trigger client price
            prophet.receive(tdd.marketDataSnapshot(Instrument.AUDUSD, 0.75101, 0.00003));
        }
        then:
        // AUD/USD notional equiv position is too small, do NOT apply skew on OFFER SIDE
        {
            // Notional Equiv Position = 2893228.6 mio
            // Limit* = min(equiv pos 2893228.6 mio, Limit 5.00001mio) = equiv pos 2893228.6 mio
            // No Bands(greater than 1mio) are < Limit*) so NO OFFER SKEW APPLIED
            WholesaleBookFactors wbf = prophet.expect(WholesaleBookFactors.class, exactly(1), isWholesaleBookFactors(driverPairA)).getLast();
            assertThat(wbf.getNotionalEquivPosition(), isRoundedTo(2893228.6));

            FeatureTraceLine ftlBid =  wbf.getPliableBookTrace().getFeatureTrace(VolumeSkewStrategy.FEATURE_NAME);
            assertThat(ftlBid.bidStatus, is(FeatureStatus.ACTIVE_NOIMPACT));
            assertThat(ftlBid.offerStatus, is(FeatureStatus.ACTIVE_NOIMPACT));
        }
    }
}
