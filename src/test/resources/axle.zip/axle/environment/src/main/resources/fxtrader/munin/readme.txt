# Attention Unix Admin
# --------------------
# 1. please make sure the section below found in $DEFAULTS_FILE looks like this:

[multi*]
	env.pidfiles /app/axle/apache-tomcat/conf/pid /app/axle/apache-tomcat-webreports/conf/pid /data/kdb/logs/pid/DS_RDB_FX.1.pid /data/kdb/logs/pid/DS_RDB_FX2.1.pid /data/kdb/logs/pid/ApamaDepthFeed_d.1.pid /data/kdb/logs/pid/DS_HDB_FX.1.pid /data/kdb/logs/pid/DS_HDB_FX2.1.pid /data/kdb/logs/pid/DS_LS_FX.1.pid /data/kdb/logs/pid/DS_RTE_CTP.1.pid /data/kdb/logs/pid/DS_RTE_CTP2.1.pid /data/kdb/logs/pid/DS_TP_FX.1.pid /data/kdb/logs/pid/FEED_FX_d.1.pid

# 2. please recreate the munin symlinks by running the following script as root:

create_munin_proxy_links.sh
