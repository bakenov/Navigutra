package com.anz.markets.efx.fox.acceptance.tests;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tools4j.spockito.Spockito;
import org.tools4j.spockito.Table;

import com.anz.axle.applicationboot.Application;
import com.anz.markets.efx.fox.acceptance.api.AcceptanceContext;
import com.anz.markets.efx.fox.acceptance.api.MarketDataFactory;
import com.anz.markets.efx.fox.acceptance.api.PricingClientEndpoint;
import com.anz.markets.efx.fox.acceptance.api.PropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.SystemPropertyApplier;
import com.anz.markets.efx.fox.acceptance.config.TestConfig;
import com.anz.markets.efx.matcher.Asserter;
import com.anz.markets.efx.ngaro.api.InstrumentKey;
import com.anz.markets.efx.ngaro.api.SecurityType;
import com.anz.markets.efx.ngaro.api.Tenor;
import com.anz.markets.efx.ngaro.api.Venue;
import com.anz.markets.efx.pricing.codec.api.EntryType;
import com.anz.markets.efx.pricing.codec.api.Flag;
import com.anz.markets.efx.pricing.codec.pojo.matcher.SnapshotFullRefreshMatcher;
import com.anz.markets.efx.pricing.codec.pojo.model.Hop;
import com.anz.markets.efx.pricing.codec.pojo.model.MessageHeader;
import com.anz.markets.efx.pricing.codec.pojo.model.PricingMessage;
import com.anz.markets.efx.pricing.codec.pojo.model.SnapshotFullRefresh;

@RunWith(Spockito.class)
public class PricingClientWithLimitedSnapshotTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(PricingClientWithLimitedSnapshotTest.class);
    @Rule
    public final TestName testName = new TestName();

    private Application application;
    private AcceptanceContext acceptanceContext;
    private PropertyApplier systemProperties = new SystemPropertyApplier();
    private MarketDataFactory marketDataFactory = new MarketDataFactory();


    @Before
    public void setup() {
        LOGGER.info("/---------------- TEST START: {}", testName.getMethodName());
        systemProperties.set("reset.all", "true");
        systemProperties.set("price.conflator.max.downstream.book.side.entries", "1");
        systemProperties.set("processor.finalisation.timeout.seconds", "2");

        application = new Application("fox", TestConfig.class);
        application.startAndAwaitStarted();
        acceptanceContext = application.getApplicationContext().getBean(AcceptanceContext.class);
        acceptanceContext.awaitInit();
    }

    @After
    public void afterEach() {
        application.stop();
        systemProperties.rollback();
        LOGGER.info("\\---------------- TEST END: {}", testName.getMethodName());
    }

    @Test
    public void should_produce_snapshot_when_polled() {
        final InstrumentKey instrumentKey = InstrumentKey.of("AUDUSD", SecurityType.FXSPOT, Tenor.SP);

        final Map<Venue, SnapshotFullRefresh> snapshots = marketDataFactory.createMarketData(instrumentKey,
                acceptanceContext.precisionClock().nanos(), LocalDate.now(), LocalDate.now(), EnumSet.noneOf(Flag.class),
                Table.parse(MarketDataFactory.MarketDataEntry.class, new String[] {
                        "| marketId | entryType    |   entryPx   | entrySize   |entryFlag   |",
                        "|==========|==============|=============|=============|============|",
                        "| FAST     |   OFFER      |   0.91673   |     2e6     |   []       |",
                        "| FAST     |   OFFER      |   0.91675   |     2e6     |   []       |",
                        "| FAST     |   OFFER      |   0.91676   |     2e6     |   []       |",
                        "| FAST     |   BID        |   1.23456   |     1e6     |   []       |",
                        "| FAST     |   BID        |   1.23455   |     1e6     |   []       |",
                }));

        snapshots.forEach((venue, snapshotFullRefresh) -> acceptanceContext.venueEndpointLookup().lookup(venue)
                .pricingQueue(instrumentKey.symbol(), instrumentKey.securityType()).offer(snapshotFullRefresh));

        final PricingClientEndpoint pricingClientEndpoint = acceptanceContext.pricingClientEndpoint();

        while(!pricingClientEndpoint.pollAll(instrumentKey.instrumentId())) {}

        Asserter.of(pricingClientEndpoint.polledSnapshots())
                .matching(SnapshotFullRefreshMatcher.build()
                        .body().matches(SnapshotFullRefreshMatcher.marketId().eq(Venue.FAST))
                        .body().matches(SnapshotFullRefreshMatcher.instrumentId().eq(instrumentKey.instrumentId()))
                        .entries().countEquals(2)
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.BID))
                        .entries().atIndex(0).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(1.23456))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryType().eq(EntryType.OFFER))
                        .entries().atIndex(1).matches(SnapshotFullRefreshMatcher.mdEntryPx().eq(0.91673)))
                .awaitMatchAndGetLast(10, TimeUnit.SECONDS);
    }
}
