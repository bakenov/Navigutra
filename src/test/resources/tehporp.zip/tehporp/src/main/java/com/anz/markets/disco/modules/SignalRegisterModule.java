package com.anz.markets.disco.modules;

import com.anz.markets.disco.MessageBus;
import com.anz.markets.disco.data.SignalRegisters;
import com.anz.markets.disco.data.Signals;

public class SignalRegisterModule extends AbstractModule {

    private final SignalRegisters signalRegisters;

    public SignalRegisterModule() {
        signalRegisters = new SignalRegisters();
    }

    public SignalRegisterModule(final SignalRegisters signalRegisters) {
        this.signalRegisters = signalRegisters;
    }

    @Override
    public void sub(MessageBus messageBus) {
        messageBus.sub(signals -> signalRegisters.addSignals(signals), Signals.class);
    }

    public SignalRegisters getSignalRegisters() {
        return signalRegisters;
    }
}
